# DeltaESC Tool Android v0.1

Android-Test- und Diagnose-App für **DeltaESC auf Ninebot G30D Gen1** über das **originale Dashboard-BLE**.

Datenweg:

`Android -> Nordic UART BLE -> Stock Dashboard -> gelbe Ninebot-UART-Leitung -> DeltaESC`

Es wird **kein ESP32/CYD** benötigt. Das originale Dashboard bleibt unverändert.

## v0.1 Funktionen

- BLE-Scan nach `MIScooter` / `Ninebot` / Nordic UART Service (NUS)
- direkte Verbindung zum Stock-Dashboard
- Ninebot `55 AA` Framing + CRC
- fragmentierte BLE-Notifications werden zu vollständigen Ninebot-Frames zusammengesetzt
- Stock-Firmware-Abfrage (`0x1A`) und Stock-Status (`0xB0`)
- DeltaESC v0.6 Diagnose-Register `0xD0..0xD9`
- Live-Polling für Status, ADC, Observer, Lock und Fault
- Kalibrierkommandos für Offsets, Phasenmapping, R, L und Flux
- Sensorless-Bench START mit einstellbarem Teststrom
- sofortiger STOP
- Schreiben von R/L/Flux/Phasenoffset/Teststrom
- Parameter-Commit
- Raw-Hex-Konsole für beliebige Ninebot-Frames
- kompletter TX/RX Bus-Log

## Sicherheit / Entwicklungsstand

**UNVALIDATED TEST TOOL.** Die Custom-Register sind der Vertrag für DeltaESC v0.6 und müssen auf der ESC-Seite noch implementiert werden.

Aktive Kalibrier- und Motorbefehle sind absichtlich mit Bestätigungsdialogen versehen. Sensorless-Tests zunächst ausschließlich mit:

- 10S
- frei drehendem Rad
- niedrigem Stromlimit
- ST-Link als Recovery-Weg
- keiner Person im Bereich des Rads

`STOP (0xE6)` ist absichtlich ohne Unlock-Magic ausführbar.

## Android

- minSdk 26
- targetSdk 35
- Java 17
- keine externen Runtime-Libraries
- Android 12+ nutzt `BLUETOOTH_SCAN` / `BLUETOOTH_CONNECT`
- ältere Android-Versionen nutzen die damalige Location-Berechtigung für BLE-Scan

## Build

Mit Android Studio öffnen und `app` als Debug APK bauen.

CLI mit Gradle 8.x:

```bash
gradle :app:assembleDebug
```

APK danach unter:

`app/build/outputs/apk/debug/app-debug.apk`

## BLE

Nordic UART Service:

- Service: `6e400001-b5a3-f393-e0a9-e50e24dcca9e`
- RX / Android -> Dashboard: `6e400002-b5a3-f393-e0a9-e50e24dcca9e`
- TX / Dashboard -> Android: `6e400003-b5a3-f393-e0a9-e50e24dcca9e`

Die App verändert die Firmware des Stock-Dashboards nicht.

Siehe `PROTOCOL.md` für das DeltaESC-v0.6-Registerformat.
