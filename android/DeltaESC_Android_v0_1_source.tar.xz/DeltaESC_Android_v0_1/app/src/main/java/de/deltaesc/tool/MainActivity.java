package de.deltaesc.tool;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity implements BleUartClient.Listener {
    private static final int REQ_PERMS = 100;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final NinebotProtocol.StreamParser parser = new NinebotProtocol.StreamParser();
    private final SimpleDateFormat timeFmt = new SimpleDateFormat("HH:mm:ss.SSS", Locale.GERMANY);

    private BleUartClient ble;
    private LinearLayout devicesBox;
    private TextView connectionText, liveText, calibrationText, logText;
    private Button scanButton, disconnectButton, liveButton, stopButton;
    private EditText rawHex, rField, lField, fluxField, phaseField, currentField;
    private boolean livePolling;
    private int pollIndex;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ble = new BleUartClient(this, this);
        setContentView(buildUi());
        ensurePermissions();
    }

    @Override protected void onDestroy() {
        livePolling = false;
        handler.removeCallbacksAndMessages(null);
        if (ble != null) ble.disconnect();
        super.onDestroy();
    }

    private View buildUi() {
        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(14), dp(14), dp(30));
        root.setBackgroundColor(Color.rgb(16,18,22));
        scroller.addView(root);

        TextView title = text("DeltaESC Tool", 28, true);
        root.addView(title);
        TextView sub = text("G30D Stock-Dashboard BLE • Ninebot/NUS • v0.1", 13, false);
        sub.setTextColor(Color.LTGRAY);
        root.addView(sub);

        root.addView(section("VERBINDUNG"));
        connectionText = text("Nicht verbunden", 16, true);
        root.addView(connectionText);
        LinearLayout row = row();
        scanButton = button("BLE scannen", v -> startScan());
        disconnectButton = button("Trennen", v -> ble.disconnect());
        row.addView(scanButton); row.addView(disconnectButton);
        root.addView(row);
        devicesBox = new LinearLayout(this);
        devicesBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(devicesBox);

        root.addView(section("LIVE / STATUS"));
        liveText = monospaced("Noch keine Daten.");
        root.addView(liveText);
        LinearLayout statusRow = row();
        statusRow.addView(button("Stock FW", v -> send(NinebotProtocol.read(0x1A, 2), "READ stock FW")));
        statusRow.addView(button("Stock Status", v -> send(NinebotProtocol.read(0xB0, 0x20), "READ stock status")));
        root.addView(statusRow);
        LinearLayout liveRow = row();
        liveButton = button("Live AUS", v -> toggleLive());
        liveRow.addView(liveButton);
        liveRow.addView(button("Delta Status", v -> requestDeltaSnapshot()));
        root.addView(liveRow);

        root.addView(section("KALIBRIERUNG"));
        calibrationText = monospaced("Nicht gestartet.");
        root.addView(calibrationText);
        addDangerButton(root, "1. Stromoffsets", "Nur im Stillstand. Gate-Ausgänge bleiben aus.", DeltaEscProtocol.ACT_CAL_OFFSET, false);
        addDangerButton(root, "2. Phasenmapping", "Kann den Motor mit sehr kleinen Testvektoren bestromen. Rad frei!", DeltaEscProtocol.ACT_CAL_PHASE, true);
        addDangerButton(root, "3. Motor-R messen", "Rotor still, 10S, Rad frei. Kurze Stromimpulse möglich.", DeltaEscProtocol.ACT_CAL_R, true);
        addDangerButton(root, "4. Motor-L messen", "Rotor still, 10S, Rad frei. Kurze Stromimpulse möglich.", DeltaEscProtocol.ACT_CAL_L, true);
        addDangerButton(root, "5. Flux messen", "Rad frei. Firmware kann Anschieben oder Niedrigenergie-Test anfordern.", DeltaEscProtocol.ACT_CAL_FLUX, true);

        root.addView(section("SENSORLESS BENCH"));
        currentField = numberField("Teststrom mA", "1000");
        root.addView(currentField);
        LinearLayout testRow = row();
        Button start = button("TEST START", v -> confirmStartTest());
        stopButton = button("STOP", v -> send(DeltaEscProtocol.action(DeltaEscProtocol.ACT_STOP), "EMERGENCY STOP"));
        stopButton.setTextColor(Color.WHITE);
        stopButton.setBackgroundColor(Color.rgb(170, 25, 25));
        testRow.addView(start); testRow.addView(stopButton);
        root.addView(testRow);

        root.addView(section("PARAMETER"));
        rField = numberField("R [mΩ]", "90");
        lField = numberField("L [µH]", "10");
        fluxField = numberField("Flux [mWb]", "1.800");
        phaseField = numberField("Phase offset [°]", "0");
        root.addView(rField); root.addView(lField); root.addView(fluxField); root.addView(phaseField);
        LinearLayout p1 = row();
        p1.addView(button("R schreiben", v -> writeR()));
        p1.addView(button("L schreiben", v -> writeL()));
        root.addView(p1);
        LinearLayout p2 = row();
        p2.addView(button("Flux schreiben", v -> writeFlux()));
        p2.addView(button("Offset schreiben", v -> writePhase()));
        root.addView(p2);
        LinearLayout p3 = row();
        p3.addView(button("Teststrom schreiben", v -> writeCurrent()));
        p3.addView(button("PARAMETER SPEICHERN", v -> confirmCommit()));
        root.addView(p3);

        root.addView(section("RAW NINEBOT"));
        rawHex = new EditText(this);
        rawHex.setTextColor(Color.WHITE);
        rawHex.setHintTextColor(Color.GRAY);
        rawHex.setHint("55 AA 03 20 01 1A 02 BF FF");
        rawHex.setSingleLine(false);
        rawHex.setMinLines(2);
        rawHex.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        root.addView(rawHex, full());
        LinearLayout rawRow = row();
        rawRow.addView(button("HEX senden", v -> sendRaw()));
        rawRow.addView(button("Log löschen", v -> logText.setText("")));
        root.addView(rawRow);

        root.addView(section("BUS LOG"));
        logText = monospaced("");
        logText.setTextIsSelectable(true);
        root.addView(logText);

        TextView foot = text("UNVALIDATED TEST TOOL. Aktive Motor-Kommandos nur mit frei drehendem Rad und 10S-Bench-Setup.", 12, true);
        foot.setTextColor(Color.rgb(255,130,120));
        foot.setPadding(0, dp(18), 0, 0);
        root.addView(foot);
        return scroller;
    }

    private void ensurePermissions() {
        if (!ble.bluetoothAvailable()) {
            connectionText.setText("Bluetooth LE nicht verfügbar"); return;
        }
        if (!ble.permissionsGranted()) requestPermissions(BleUartClient.runtimePermissions(), REQ_PERMS);
        if (!ble.bluetoothEnabled()) {
            connectionText.setText("Bluetooth ist aus");
            startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
        }
    }

    private void startScan() {
        ensurePermissions();
        if (!ble.permissionsGranted() || !ble.bluetoothEnabled()) return;
        devicesBox.removeAllViews();
        ble.startScan();
        connectionText.setText("Suche MIScooter/Ninebot/NUS …");
    }

    private void addDangerButton(LinearLayout root, String label, String warning, int cmd, boolean confirm) {
        Button b = button(label, v -> {
            if (!confirm) {
                send(DeltaEscProtocol.action(cmd), label);
            } else {
                new AlertDialog.Builder(this)
                        .setTitle(label)
                        .setMessage(warning + "\n\nFortfahren?")
                        .setNegativeButton("Abbrechen", null)
                        .setPositiveButton("Start", (d,w) -> send(DeltaEscProtocol.action(cmd), label))
                        .show();
            }
        });
        root.addView(b, full());
    }

    private void confirmStartTest() {
        int ma;
        try { ma = Integer.parseInt(currentField.getText().toString().trim()); }
        catch (Exception e) { toast("Ungültiger Teststrom"); return; }
        final int currentMa = Math.max(100, Math.min(5000, ma));
        new AlertDialog.Builder(this)
                .setTitle("Sensorless-Test starten")
                .setMessage("10S Bench. Rad vollständig frei. Niemand am Rad. ST-Link-Rettungsweg vorhanden.\n\nTeststrom: " + currentMa + " mA")
                .setNegativeButton("Abbrechen", null)
                .setPositiveButton("START", (d,w) -> send(DeltaEscProtocol.startTest(currentMa), "SENSORLESS START " + currentMa + "mA"))
                .show();
    }

    private void confirmCommit() {
        new AlertDialog.Builder(this)
                .setTitle("Parameter dauerhaft speichern")
                .setMessage("Schreibt die aktuell gesetzten Motorparameter in den DeltaESC-Konfigurationsspeicher.")
                .setNegativeButton("Abbrechen", null)
                .setPositiveButton("Speichern", (d,w) -> send(DeltaEscProtocol.commit(), "CFG COMMIT"))
                .show();
    }

    private void writeR() {
        try {
            double mOhm=Double.parseDouble(rField.getText().toString().trim().replace(',', '.'));
            send(DeltaEscProtocol.writeU32(DeltaEscProtocol.CFG_R_UOHM, Math.round(mOhm*1000.0)), "CFG R");
        } catch(Exception e){ toast("R ungültig"); }
    }
    private void writeL() {
        try {
            double uH=Double.parseDouble(lField.getText().toString().trim().replace(',', '.'));
            send(DeltaEscProtocol.writeU32(DeltaEscProtocol.CFG_L_NH, Math.round(uH*1000.0)), "CFG L");
        } catch(Exception e){ toast("L ungültig"); }
    }
    private void writeFlux() {
        try {
            double mWb=Double.parseDouble(fluxField.getText().toString().trim().replace(',', '.'));
            send(DeltaEscProtocol.writeU32(DeltaEscProtocol.CFG_FLUX_UWB, Math.round(mWb*1000.0)), "CFG FLUX");
        } catch(Exception e){ toast("Flux ungültig"); }
    }
    private void writePhase() {
        try {
            double deg=Double.parseDouble(phaseField.getText().toString().trim().replace(',', '.'));
            int angle=(int)Math.round(deg*65536.0/360.0);
            send(DeltaEscProtocol.writeI16(DeltaEscProtocol.CFG_PHASE_OFFSET, angle), "CFG PHASE");
        } catch(Exception e){ toast("Offset ungültig"); }
    }
    private void writeCurrent() {
        try {
            int ma=Integer.parseInt(currentField.getText().toString().trim());
            send(DeltaEscProtocol.writeI16(DeltaEscProtocol.CFG_TEST_CURRENT_MA, Math.max(0,Math.min(10000,ma))), "CFG TEST CURRENT");
        } catch(Exception e){ toast("Teststrom ungültig"); }
    }

    private void toggleLive() {
        livePolling = !livePolling;
        liveButton.setText(livePolling ? "Live AN" : "Live AUS");
        if (livePolling) handler.post(pollRunnable); else handler.removeCallbacks(pollRunnable);
    }

    private final Runnable pollRunnable = new Runnable() {
        @Override public void run() {
            if (!livePolling) return;
            int[] regs = {DeltaEscProtocol.REG_STATUS, DeltaEscProtocol.REG_ADC, DeltaEscProtocol.REG_OBSERVER, DeltaEscProtocol.REG_LOCK, DeltaEscProtocol.REG_FAULT};
            int[] sizes = {16, 16, 16, 12, 8};
            int i = pollIndex++ % regs.length;
            send(NinebotProtocol.read(regs[i], sizes[i]), String.format(Locale.US,"POLL 0x%02X",regs[i]));
            handler.postDelayed(this, 250);
        }
    };

    private void requestDeltaSnapshot() {
        int[] regs={0xD0,0xD1,0xD2,0xD3,0xD4,0xD5,0xD6,0xD7,0xD8,0xD9};
        int delay=0;
        for(int reg:regs){
            handler.postDelayed(() -> send(NinebotProtocol.read(reg, 0x20), String.format(Locale.US,"READ 0x%02X",reg)), delay);
            delay += 120;
        }
    }

    private void sendRaw() {
        try {
            byte[] b=Hex.parse(rawHex.getText().toString());
            if (b.length==0) return;
            send(b,"RAW");
        } catch(Exception e){ toast("Hex ungültig: " + e.getMessage()); }
    }

    private void send(byte[] data, String tag) {
        if (!ble.isReady()) { toast("Noch nicht mit Stock-Dash/NUS verbunden"); return; }
        if (ble.write(data)) appendLog("TX " + tag + "  " + Hex.of(data));
    }

    @Override public void onLog(String s) { runOnUiThread(() -> appendLog("BLE " + s)); }

    @Override public void onDevice(BluetoothDevice device, int rssi) {
        runOnUiThread(() -> {
            String name;
            try { name=device.getName(); } catch(SecurityException e){ name=null; }
            if(name==null) name="Unbenannt";
            Button b=button(name + "   " + rssi + " dBm\n" + device.getAddress(), v -> ble.connect(device));
            devicesBox.addView(b, full());
        });
    }

    @Override public void onConnection(boolean connected, String label) {
        runOnUiThread(() -> connectionText.setText(label));
    }

    @Override public void onReady(boolean ready) {
        runOnUiThread(() -> {
            if (ready) {
                appendLog("NUS bereit. Teste Stock-Firmware-Abfrage.");
                handler.postDelayed(() -> send(NinebotProtocol.read(0x1A,2), "READ stock FW"), 300);
            } else {
                livePolling=false;
                if(liveButton!=null) liveButton.setText("Live AUS");
            }
        });
    }

    @Override public void onBytes(byte[] data) {
        runOnUiThread(() -> {
            appendLog("RX BLE     " + Hex.of(data));
            List<NinebotProtocol.Frame> frames=parser.push(data);
            for(NinebotProtocol.Frame f:frames){
                String desc=DeltaEscProtocol.describe(f);
                appendLog(String.format(Locale.US,"RX FRAME  a=%02X t=%02X c=%02X  %s",f.address,f.type,f.command,desc));
                updatePanels(f,desc);
            }
        });
    }

    private void updatePanels(NinebotProtocol.Frame f, String desc) {
        if (f.command>=0xD0 && f.command<=0xD9) {
            String old=liveText.getText().toString();
            String key=String.format(Locale.US,"D%X",f.command-0xD0);
            liveText.setText(key + "  " + desc + "\n" + trimLines(old,10));
            if (f.command>=0xD1 && f.command<=0xD5) {
                calibrationText.setText(desc + "\n" + trimLines(calibrationText.getText().toString(),6));
            }
        } else if (f.command==0x1A || f.command==0xB0) {
            liveText.setText(desc + "\n" + trimLines(liveText.getText().toString(),10));
        }
    }

    private String trimLines(String s,int max) {
        String[] a=s.split("\\n");
        StringBuilder b=new StringBuilder();
        for(int i=0;i<Math.min(max,a.length);i++){ if(i>0)b.append('\n'); b.append(a[i]); }
        return b.toString();
    }

    private void appendLog(String s) {
        if(logText==null) return;
        String line=timeFmt.format(new Date()) + "  " + s + "\n";
        String old=logText.getText().toString();
        if(old.length()>24000) old=old.substring(old.length()-18000);
        logText.setText(old + line);
    }

    private TextView section(String s) {
        TextView v=text(s,13,true);
        v.setTextColor(Color.rgb(255,90,80));
        v.setPadding(0,dp(20),0,dp(6));
        return v;
    }
    private TextView text(String s,int sp,boolean bold) {
        TextView v=new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(Color.WHITE);
        if(bold) v.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return v;
    }
    private TextView monospaced(String s) {
        TextView v=text(s,13,false); v.setTypeface(android.graphics.Typeface.MONOSPACE); v.setTextIsSelectable(true);
        v.setPadding(dp(8),dp(8),dp(8),dp(8)); v.setBackgroundColor(Color.rgb(26,29,34)); return v;
    }
    private EditText numberField(String hint,String value) {
        EditText e=new EditText(this); e.setHint(hint); e.setText(value); e.setTextColor(Color.WHITE); e.setHintTextColor(Color.GRAY);
        e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED);
        return e;
    }
    private Button button(String label, View.OnClickListener l) {
        Button b=new Button(this); b.setText(label); b.setOnClickListener(l); b.setAllCaps(false); b.setMinHeight(dp(48));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f); lp.setMargins(dp(2),dp(3),dp(2),dp(3)); b.setLayoutParams(lp);
        return b;
    }
    private LinearLayout row() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout.LayoutParams full(){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT); p.setMargins(0,dp(3),0,dp(3)); return p; }
    private int dp(int x){ return Math.round(x*getResources().getDisplayMetrics().density); }
    private void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==REQ_PERMS && ble.permissionsGranted()) connectionText.setText("Bereit zum Scannen");
    }
}
