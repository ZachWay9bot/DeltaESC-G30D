package de.deltaesc.tool;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

final class NinebotProtocol {
    static final int MASTER_TO_ESC = 0x20;
    static final int ESC_TO_MASTER = 0x23;
    static final int READ = 0x01;
    static final int WRITE = 0x03;

    static final class Frame {
        final int address;
        final int type;
        final int command;
        final byte[] payload;
        final byte[] raw;

        Frame(int address, int type, int command, byte[] payload, byte[] raw) {
            this.address = address;
            this.type = type;
            this.command = command;
            this.payload = payload;
            this.raw = raw;
        }
    }

    static byte[] build(int address, int type, int command, byte[] payload) {
        if (payload == null) payload = new byte[0];
        int len = payload.length + 2;
        byte[] out = new byte[payload.length + 8];
        out[0] = 0x55;
        out[1] = (byte) 0xAA;
        out[2] = (byte) len;
        out[3] = (byte) address;
        out[4] = (byte) type;
        out[5] = (byte) command;
        System.arraycopy(payload, 0, out, 6, payload.length);
        int sum = 0;
        for (int i = 2; i < out.length - 2; i++) sum = (sum + (out[i] & 0xFF)) & 0xFFFF;
        int crc = sum ^ 0xFFFF;
        out[out.length - 2] = (byte) (crc & 0xFF);
        out[out.length - 1] = (byte) ((crc >>> 8) & 0xFF);
        return out;
    }

    static byte[] read(int command, int requestedBytes) {
        return build(MASTER_TO_ESC, READ, command, new byte[]{(byte) requestedBytes});
    }

    static byte[] write(int command, byte[] payload) {
        return build(MASTER_TO_ESC, WRITE, command, payload);
    }

    static boolean valid(byte[] frame) {
        if (frame == null || frame.length < 8 || frame[0] != 0x55 || (frame[1] & 0xFF) != 0xAA) return false;
        int len = frame[2] & 0xFF;
        if (frame.length != len + 6) return false;
        int sum = 0;
        for (int i = 2; i < frame.length - 2; i++) sum = (sum + (frame[i] & 0xFF)) & 0xFFFF;
        int crc = sum ^ 0xFFFF;
        int got = (frame[frame.length - 2] & 0xFF) | ((frame[frame.length - 1] & 0xFF) << 8);
        return crc == got;
    }

    static Frame decode(byte[] raw) {
        if (!valid(raw)) throw new IllegalArgumentException("Ungültiger Ninebot-Frame/CRC");
        int payloadLen = (raw[2] & 0xFF) - 2;
        byte[] payload = payloadLen > 0 ? Arrays.copyOfRange(raw, 6, 6 + payloadLen) : new byte[0];
        return new Frame(raw[3] & 0xFF, raw[4] & 0xFF, raw[5] & 0xFF, payload, raw);
    }

    static final class StreamParser {
        private final ByteArrayOutputStream buffer = new ByteArrayOutputStream();

        synchronized List<Frame> push(byte[] chunk) {
            try { buffer.write(chunk); } catch (Exception ignored) {}
            byte[] data = buffer.toByteArray();
            List<Frame> frames = new ArrayList<>();
            int p = 0;
            while (p + 3 <= data.length) {
                if (data[p] != 0x55 || (data[p + 1] & 0xFF) != 0xAA) { p++; continue; }
                int len = data[p + 2] & 0xFF;
                int total = len + 6;
                if (total < 8 || total > 70) { p++; continue; }
                if (p + total > data.length) break;
                byte[] candidate = Arrays.copyOfRange(data, p, p + total);
                if (valid(candidate)) {
                    frames.add(decode(candidate));
                    p += total;
                } else {
                    p++;
                }
            }
            buffer.reset();
            if (p < data.length) buffer.write(data, p, data.length - p);
            return frames;
        }
    }
}
