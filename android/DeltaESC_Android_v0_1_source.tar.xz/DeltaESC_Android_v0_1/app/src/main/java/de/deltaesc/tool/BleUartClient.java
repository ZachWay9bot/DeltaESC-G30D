package de.deltaesc.tool;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

final class BleUartClient {
    interface Listener {
        void onLog(String s);
        void onDevice(BluetoothDevice device, int rssi);
        void onConnection(boolean connected, String label);
        void onReady(boolean ready);
        void onBytes(byte[] data);
    }

    static final UUID NUS_SERVICE = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
    static final UUID NUS_RX = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e");
    static final UUID NUS_TX = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e");
    static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private final Activity activity;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic rx;
    private BluetoothGattCharacteristic tx;
    private boolean scanning;
    private boolean ready;
    private final Map<String, BluetoothDevice> seen = new LinkedHashMap<>();

    BleUartClient(Activity activity, Listener listener) {
        this.activity = activity;
        this.listener = listener;
        BluetoothManager bm = (BluetoothManager) activity.getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = bm != null ? bm.getAdapter() : null;
    }

    boolean bluetoothAvailable() { return adapter != null; }
    boolean bluetoothEnabled() { return adapter != null && adapter.isEnabled(); }
    boolean isReady() { return ready; }

    static String[] runtimePermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT};
        }
        return new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
    }

    boolean permissionsGranted() {
        for (String p : runtimePermissions()) {
            if (activity.checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) return false;
        }
        return true;
    }

    @SuppressLint("MissingPermission")
    void startScan() {
        if (!permissionsGranted() || adapter == null || !adapter.isEnabled()) return;
        stopScan();
        seen.clear();
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) return;
        scanning = true;
        listener.onLog("BLE Scan gestartet");
        scanner.startScan(scanCallback);
        main.postDelayed(this::stopScan, 12000);
    }

    @SuppressLint("MissingPermission")
    void stopScan() {
        if (scanning && scanner != null && permissionsGranted()) {
            try { scanner.stopScan(scanCallback); } catch (Exception ignored) {}
        }
        scanning = false;
    }

    @SuppressLint("MissingPermission")
    void connect(BluetoothDevice device) {
        stopScan();
        disconnect();
        listener.onConnection(false, "Verbinde mit " + safeName(device));
        gatt = device.connectGatt(activity, false, callback, BluetoothDevice.TRANSPORT_LE);
    }

    @SuppressLint("MissingPermission")
    void disconnect() {
        ready = false;
        listener.onReady(false);
        if (gatt != null) {
            try { gatt.disconnect(); } catch (Exception ignored) {}
            try { gatt.close(); } catch (Exception ignored) {}
        }
        gatt = null; rx = null; tx = null;
    }

    @SuppressLint("MissingPermission")
    boolean write(byte[] data) {
        if (!ready || gatt == null || rx == null) return false;
        int writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT;
        boolean ok;
        if (Build.VERSION.SDK_INT >= 33) {
            ok = gatt.writeCharacteristic(rx, data, writeType) == android.bluetooth.BluetoothStatusCodes.SUCCESS;
        } else {
            rx.setWriteType(writeType);
            rx.setValue(data);
            ok = gatt.writeCharacteristic(rx);
        }
        if (!ok) listener.onLog("BLE write konnte nicht gestartet werden");
        return ok;
    }

    @SuppressLint("MissingPermission")
    private String safeName(BluetoothDevice d) {
        try {
            String n = d.getName();
            return (n == null || n.isEmpty()) ? d.getAddress() : n + " (" + d.getAddress() + ")";
        } catch (SecurityException e) { return "BLE Gerät"; }
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice d = result.getDevice();
            String key = d.getAddress();
            if (seen.containsKey(key)) return;
            boolean interesting = false;
            String name = null;
            try { name = d.getName(); } catch (SecurityException ignored) {}
            if (name != null) {
                String low = name.toLowerCase();
                interesting = low.contains("miscooter") || low.contains("ninebot") || low.contains("scooter");
            }
            if (result.getScanRecord() != null && result.getScanRecord().getServiceUuids() != null) {
                for (ParcelUuid u : result.getScanRecord().getServiceUuids()) {
                    if (NUS_SERVICE.equals(u.getUuid())) { interesting = true; break; }
                }
            }
            if (interesting) {
                seen.put(key, d);
                listener.onDevice(d, result.getRssi());
            }
        }

        @Override public void onScanFailed(int errorCode) {
            listener.onLog("BLE Scanfehler: " + errorCode);
        }
    };

    private final BluetoothGattCallback callback = new BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                listener.onConnection(true, "BLE verbunden, suche NUS …");
                try { g.requestMtu(247); } catch (Exception ignored) {}
                g.discoverServices();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                ready = false;
                listener.onReady(false);
                listener.onConnection(false, "Getrennt");
                try { g.close(); } catch (Exception ignored) {}
                if (g == gatt) gatt = null;
            }
        }

        @SuppressLint("MissingPermission")
        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                listener.onLog("Service discovery fehlgeschlagen: " + status);
                return;
            }
            BluetoothGattService s = g.getService(NUS_SERVICE);
            if (s == null) {
                listener.onLog("Nordic UART Service nicht gefunden");
                return;
            }
            rx = s.getCharacteristic(NUS_RX);
            tx = s.getCharacteristic(NUS_TX);
            if (rx == null || tx == null) {
                listener.onLog("NUS RX/TX Characteristic fehlt");
                return;
            }
            g.setCharacteristicNotification(tx, true);
            BluetoothGattDescriptor cccd = tx.getDescriptor(CCCD);
            if (cccd == null) {
                listener.onLog("CCCD für Notifications fehlt");
                return;
            }
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeDescriptor(cccd, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            } else {
                cccd.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                g.writeDescriptor(cccd);
            }
        }

        @Override public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor descriptor, int status) {
            if (CCCD.equals(descriptor.getUuid()) && status == BluetoothGatt.GATT_SUCCESS) {
                ready = true;
                listener.onReady(true);
                listener.onConnection(true, "Stock-Dash BLE / NUS bereit");
            }
        }

        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic characteristic) {
            if (NUS_TX.equals(characteristic.getUuid())) {
                byte[] v = characteristic.getValue();
                if (v != null) listener.onBytes(v.clone());
            }
        }

        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic characteristic, byte[] value) {
            if (NUS_TX.equals(characteristic.getUuid()) && value != null) listener.onBytes(value.clone());
        }
    };
}
