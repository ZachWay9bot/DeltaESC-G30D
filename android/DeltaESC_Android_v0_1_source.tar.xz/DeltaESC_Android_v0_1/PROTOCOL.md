# DeltaESC G30D BLE / Ninebot protocol contract v0.1

Dieser Vertrag bindet die Android-App v0.1 an die geplante DeltaESC-Firmware v0.6.

## Transport

Original Ninebot frame:

```
55 AA L D T C [payload...] CK0 CK1
```

- `L = payload length + 2`
- Android -> ESC: `D=0x20`
- ESC -> Android: `D=0x23`
- read: `T=0x01`
- write: `T=0x03`
- checksum: Summe ab `L` bis letztes Payload-Byte, XOR `0xFFFF`, little-endian

Read requests use one payload byte containing the requested response size.

## Read registers

### 0xD0 STATUS

Suggested response payload:

| Offset | Type | Meaning |
|---|---|---|
| 0 | u8 | protocol major |
| 1 | u8 | protocol minor |
| 2 | u16 | firmware build/revision |
| 4 | u8 | control state: 0 STOP, 1 ALIGN, 2 OPEN, 3 HANDOVER, 4 CLOSED, 5 FAULT |
| 5 | u8 | flags |
| 6 | u16 | fault code |
| 8 | u16 | PWM Hz |
| 10 | u16 | control Hz |

### 0xD1 ADC / CURRENT OFFSETS

`u16 offsetA, offsetB, offsetC, rawA, rawB, rawC, vbusRaw`

### 0xD2 PHASE MAP

`u8 mapA, mapB, mapC, signBits, direction`

Mapping values: `0=A, 1=B, 2=C`. Direction `0=FWD, 1=REV`.

### 0xD3 MOTOR R

`u32 R_uOhm`

### 0xD4 MOTOR L

`u32 L_nH`

### 0xD5 FLUX

`u32 flux_uWb`

### 0xD6 OBSERVER

`u16 controlPhase, u16 observerPhase, i16 phaseErrorU16, i16 iq_mA, i16 id_mA [, u32 fluxSq]`

### 0xD7 LOCK

`u8 state, u8 valid, u16 lockCount, u16 lostCount, u16 confidencePermille`

### 0xD8 TIMING

`u32 lastCycles, u32 maxCycles, u32 budgetCycles`

### 0xD9 FAULT

`u16 faultCode, u16 flags [, u16 hardOcRaw]`

## Calibration / action writes

Dangerous actions carry unlock magic `0xC0DE` little-endian (`DE C0`).

- `0xE0` current offset calibration + magic
- `0xE1` phase mapping + magic
- `0xE2` R measurement + magic
- `0xE3` L measurement + magic
- `0xE4` flux measurement + magic
- `0xE5` sensorless bench start + magic + `u16 current_mA`
- `0xE6` STOP, no payload and no magic required

STOP must always win over any calibration/test state.

## Writable configuration

- `0xF0`: `u32 R_uOhm`
- `0xF1`: `u32 L_nH`
- `0xF2`: `u32 flux_uWb`
- `0xF3`: `i16 electrical phase offset`, full turn = 65536 counts
- `0xF4`: `u16 sensorless test current_mA`
- `0xF5`: commit current configuration, payload magic `DE C0`

Firmware should range-check all writes. Invalid values must be rejected without changing the active configuration.

## Compatibility

The app also understands two normal stock requests for link testing:

- `0x1A`, 2 bytes: firmware version
- `0xB0`, 0x20 bytes: status block

These are useful before DeltaESC custom registers are available because they verify Android -> BLE -> Stock Dash -> UART transport independently of the sensorless control code.
