# DeltaESC G30D XBOT Companion v0.10.0-rc1

Android-Begleitapp für den neu aufgebauten DeltaESC-G30D-Low-Level-Strang.

- verbindet über das originale Ninebot BLE/Dashboard mit Legacy-Crypto,
- erkennt ausschließlich die neue `DG10`/Protokoll-10-Firmware,
- liest F0/F7/F8 Diagnose, Qualifikation und passive BEMF,
- lädt Hardware-Evidenz nur RAM-basiert,
- aktive Befehle bleiben gesperrt, solange die Firmware `ACTIVE_READY=0` meldet,
- unterstützt Sensorless-Proof, R/L/Flux-Detect, STOP und kurze Bench-Leases.

Die App erteilt keine Straßen- oder Hardwarefreigabe. Der Firmware-Fail-Closed-Pfad ist autoritativ.
