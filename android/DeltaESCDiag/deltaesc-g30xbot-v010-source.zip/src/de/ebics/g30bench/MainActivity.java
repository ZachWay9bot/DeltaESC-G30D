// SPDX-License-Identifier: AGPL-3.0-or-later
package de.ebics.g30bench;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

/** Companion app for DeltaESC G30D/XBOT v0.10.0-rc1.
 * It intentionally separates passive qualification from torque-producing
 * commands. Firmware remains the final authority for every active request. */
public final class MainActivity extends Activity {
    private final Handler main=new Handler(Looper.getMainLooper());
    private BleClient ble; private boolean linked,known,activeReady,passivePolling,detectPolling,proofPolling;
    private TextView transport,summary,passiveText,qualText,detectText,trace;
    private LinearLayout devices; private final Set<String> seen=new HashSet<>();
    private Button scan,disconnect,refresh,passiveStart,passiveStop,passiveReset,qualUpload,proof,detect,stop,driveFixed,driveDash,export;
    private EditText currentSign,hardOc,currentScale,vbusScale,bemfScale,driveIq,driveMs;
    private CheckBox evPolarity,evScale,evPb12,evPwm;
    private final List<String> events=new ArrayList<>(); private final Map<String,Object> diag=new LinkedHashMap<>(),qual=new LinkedHashMap<>(),passive=new LinkedHashMap<>(),detectMap=new LinkedHashMap<>();
    private String pendingExport;
    private final int bg=Color.rgb(13,21,28),card=Color.rgb(26,40,51),ink=Color.rgb(230,240,248),accent=Color.rgb(140,207,244);

    @Override public void onCreate(Bundle b){super.onCreate(b);buildUi();
        ble=new BleClient(this,new BleClient.Listener(){
            public void status(String s){transport.setText(s);log(s);render();}
            public void device(BluetoothDevice d,String name,int rssi){String a=d.getAddress();if(!seen.add(a))return;Button x=button(name+"  •  "+rssi+" dBm\n"+a,devices);x.setOnClickListener(v->{if(!permissions()){askPermissions();return;}devices.removeAllViews();linked=known=activeReady=false;ble.connect(d,name);render();});}
            public void ready(String mode){linked=true;log("Transport bereit: "+mode);send(new Packet(0x3e,0x20,0xF0,0,new byte[0]));}
            public void packet(Packet p){onPacket(p);}
            public void disconnected(){linked=known=activeReady=passivePolling=detectPolling=proofPolling=false;render();}
            public void metadata(String k,Object v){}
        });
        scan.setOnClickListener(v->{if(!permissions()){askPermissions();return;}seen.clear();devices.removeAllViews();ble.scan();});
        disconnect.setOnClickListener(v->ble.disconnect()); refresh.setOnClickListener(v->refreshAll());
        passiveStart.setOnClickListener(v->{send(Packet.request(0x20,0xF8,3));send(Packet.request(0x20,0xF8,1));passivePolling=true;pollPassive();});
        passiveStop.setOnClickListener(v->{passivePolling=false;send(Packet.request(0x20,0xF8,2));});
        passiveReset.setOnClickListener(v->send(Packet.request(0x20,0xF8,3)));
        qualUpload.setOnClickListener(v->uploadQualification()); proof.setOnClickListener(v->{if(!requireReady())return;send(Packet.request(0x20,0xF2,0));proofPolling=true;pollProof();});
        detect.setOnClickListener(v->{if(!requireReady())return;send(Packet.request(0x20,0xF4,0));detectPolling=true;pollDetect();});
        stop.setOnClickListener(v->{passivePolling=detectPolling=proofPolling=false;send(Packet.request(0x20,0xF3,0));});
        driveFixed.setOnClickListener(v->startDrive(false));driveDash.setOnClickListener(v->startDrive(true));export.setOnClickListener(v->saveReport());
        transport.setText("Scooter einschalten, SHU schließen, dann suchen.");render();
    }

    private void onPacket(Packet p){
        log(String.format(Locale.ROOT,"RX %02x→%02x cmd=%02x arg=%02x len=%d",p.src,p.dst,p.cmd,p.arg,p.data.length));
        try{
            if(p.cmd==0xF0&&p.data.length==128){parseDiag(p.data);known=u32(p.data,0)==0x30314744L&&u16(p.data,4)==10;if(known)send(Packet.request(0x20,0xF7,0));}
            else if(p.cmd==0xF7&&p.data.length==64){parseQual(p.data);activeReady=(p.data[7]&255)!=0;}
            else if(p.cmd==0xF8&&p.data.length==40)parsePassive(p.data);
            else if(p.cmd==0xF5&&p.data.length==112)parseDetect(p.data);
            else if(p.cmd==0xF6&&p.data.length==32){log("Drive-Status: "+(p.data[4]&255));send(Packet.request(0x20,0xF0,0));}
            else if(p.cmd==0x0B){log("ACK Status="+p.arg);if(p.arg!=0){detectPolling=proofPolling=false;}send(Packet.request(0x20,0xF0,0));}
        }catch(RuntimeException ex){log("Decodefehler: "+ex.getMessage());}
        render();
    }
    private void parseDiag(byte[] d){diag.clear();diag.put("magic",String.format(Locale.ROOT,"0x%08x",u32(d,0)));diag.put("protocol",u16(d,4));diag.put("active_build",d[6]!=0);diag.put("timing_id",d[7]&255);diag.put("state",state(d[12]&255));diag.put("motor_fault",d[13]&255);diag.put("armed",d[14]!=0);diag.put("offsets_ok",d[16]!=0);diag.put("mode_switch_ok",d[17]!=0);diag.put("pb12_high",d[18]!=0);diag.put("recovery",d[19]!=0);diag.put("vbus_raw",u16(d,20));diag.put("offset_a",u16(d,22));diag.put("offset_b",u16(d,24));diag.put("offset_c",u16(d,26));diag.put("ia",s16(d,28));diag.put("ib",s16(d,30));diag.put("ic",s16(d,32));diag.put("bemf_a",u16(d,34));diag.put("bemf_b",u16(d,36));diag.put("bemf_c",u16(d,38));diag.put("bemf_span",u16(d,40));diag.put("direction",(int)d[43]);diag.put("open_step",u16(d,44));diag.put("observer_step",u16(d,46));diag.put("phase_error",s16(d,48));diag.put("peak_current",u16(d,54));diag.put("ccr1",u16(d,56));diag.put("ccr2",u16(d,58));diag.put("ccr3",u16(d,60));diag.put("global_fault",String.format(Locale.ROOT,"0x%08x",u32(d,62)));diag.put("adc_samples",u32(d,66));diag.put("control_cycles_max",u32(d,74));diag.put("overcurrent_trips",u32(d,78));diag.put("pb12_low_events",u32(d,82));diag.put("arr",u16(d,86));diag.put("ccr4",u16(d,88));diag.put("bdtr",String.format(Locale.ROOT,"0x%04x",u16(d,90)));diag.put("ccer",String.format(Locale.ROOT,"0x%04x",u16(d,92)));diag.put("qual_flags",String.format(Locale.ROOT,"0x%03x",u32(d,102)));diag.put("boot_compatible",d[126]!=0);diag.put("flash_kib",d[127]&255);}
    private void parseQual(byte[] d){qual.clear();qual.put("ready",d[7]!=0);qual.put("flags",String.format(Locale.ROOT,"0x%03x",u32(d,8)));qual.put("current_sign",(int)d[12]);qual.put("hard_oc_counts",u16(d,14));qual.put("current_uA_per_count",u32(d,16));qual.put("vbus_uV_per_count",u32(d,20));qual.put("bemf_uV_per_count",u32(d,24));qual.put("manual_evidence",String.format(Locale.ROOT,"0x%02x",u32(d,28)));qual.put("passive_samples",u32(d,32));qual.put("passive_transitions",u32(d,40));qual.put("passive_forward",u32(d,44));qual.put("passive_reverse",u32(d,48));qual.put("passive_bad",u32(d,52));qual.put("passive_span_max",u16(d,58));qual.put("passive_direction",d[60]&255);qual.put("passive_good",d[61]!=0);qual.put("timing_id",d[63]&255);}
    private void parsePassive(byte[] d){passive.clear();passive.put("enabled",d[5]!=0);passive.put("direction",d[6]&255);passive.put("good",d[7]!=0);passive.put("samples",u32(d,8));passive.put("valid",u32(d,12));passive.put("transitions",u32(d,16));passive.put("forward",u32(d,20));passive.put("reverse",u32(d,24));passive.put("bad",u32(d,28));passive.put("span_min",u16(d,32));passive.put("span_max",u16(d,34));passive.put("span_avg",u32(d,36));if(d[7]!=0){passivePolling=false;send(Packet.request(0x20,0xF8,2));send(Packet.request(0x20,0xF7,0));}}
    private void parseDetect(byte[] d){detectMap.clear();detectMap.put("state",pdState(d[4]&255));detectMap.put("error",d[5]&255);detectMap.put("ticks",u32(d,8));detectMap.put("L_mod",u16(d,12));detectMap.put("R_low_n",u32(d,20));detectMap.put("R_high_n",u32(d,36));detectMap.put("L_pos",u16(d,52));detectMap.put("L_neg",u16(d,54));detectMap.put("flux_bemf_n",u32(d,68));detectMap.put("flux_ctrl_n",u32(d,88));if((d[4]&255)==13||(d[4]&255)==14)detectPolling=false;}

    private void refreshAll(){if(!linked)return;send(Packet.request(0x20,0xF0,0));if(known){send(Packet.request(0x20,0xF7,0));send(Packet.request(0x20,0xF8,0));}}
    private void pollPassive(){if(!passivePolling||!linked)return;send(Packet.request(0x20,0xF8,0));main.postDelayed(this::pollPassive,450);}
    private void pollDetect(){if(!detectPolling||!linked)return;send(Packet.request(0x20,0xF5,0));main.postDelayed(this::pollDetect,300);}
    private void pollProof(){if(!proofPolling||!linked)return;send(Packet.request(0x20,0xF0,0));Object s=diag.get("state");if("DONE".equals(s)||"FAULT".equals(s)){proofPolling=false;return;}main.postDelayed(this::pollProof,350);}

    private void uploadQualification(){
        if(!known){toast("Firmware zuerst erkennen");return;}
        if(!(evPolarity.isChecked()&&evScale.isChecked()&&evPb12.isChecked()&&evPwm.isChecked())){toast("Alle vier real geprüften Evidenzen müssen bestätigt sein");return;}
        try{int sign=Integer.parseInt(currentSign.getText().toString().trim()),oc=Integer.parseInt(hardOc.getText().toString().trim());long cs=Long.parseLong(currentScale.getText().toString().trim()),vs=Long.parseLong(vbusScale.getText().toString().trim()),bs=Long.parseLong(bemfScale.getText().toString().trim());
            if((sign!=1&&sign!=-1)||oc<32||oc>400||cs<5000||cs>100000||vs<5000||vs>20000||bs<5000||bs>20000)throw new IllegalArgumentException("Werte außerhalb Firmwaregrenzen");
            ByteBuffer q=ByteBuffer.allocate(28).order(ByteOrder.LITTLE_ENDIAN);q.putInt(0x30314751).putShort((short)1).put((byte)sign).put((byte)0).putShort((short)oc).putShort((short)0).putInt((int)cs).putInt((int)vs).putInt((int)bs).putInt(15);
            send(new Packet(0x3e,0x20,0xF7,1,q.array()));
        }catch(Exception ex){toast("Qualifikation: "+ex.getMessage());}
    }
    private boolean requireReady(){if(!activeReady){toast("ACTIVE_READY ist nicht erfüllt. Kein Motorbefehl gesendet.");return false;}return true;}
    private void startDrive(boolean dash){if(!requireReady())return;try{int iq=Integer.parseInt(driveIq.getText().toString().trim()),ms=Integer.parseInt(driveMs.getText().toString().trim());if(iq<4||iq>28||ms<1||ms>5000)throw new IllegalArgumentException("Iq 4..28, Zeit 1..5000 ms");ByteBuffer b=ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);b.put(dash?new byte[]{'D','R','V','2'}:new byte[]{'D','R','V','1'}).putShort((short)iq).putShort((short)ms);send(new Packet(0x3e,0x20,0xF6,dash?2:1,b.array()));proofPolling=true;pollProof();}catch(Exception ex){toast(ex.getMessage());}}
    private void send(Packet p){try{ble.send(p,known);log(String.format(Locale.ROOT,"TX cmd=%02x arg=%02x len=%d",p.cmd,p.arg,p.data.length));}catch(Exception ex){log("TX blockiert: "+ex.getMessage());render();}}

    private void buildUi(){ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setBackgroundColor(bg);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(16),dp(16),dp(16),dp(28));sv.addView(root);setContentView(sv);
        text("DeltaESC G30D XBOT",28,true,root);text("v0.10.0-rc1 · DRV126-Hardware + XBOT-Sensorless",13,false,root);
        LinearLayout c=panel(root);text("Verbindung",20,true,c);transport=text("",14,true,c);LinearLayout rr=row(c);scan=button("Scooter suchen",rr);disconnect=button("Trennen",rr);devices=new LinearLayout(this);devices.setOrientation(LinearLayout.VERTICAL);c.addView(devices);refresh=button("Diagnose aktualisieren",c);summary=text("Noch nicht verbunden.",13,false,c);
        LinearLayout p=panel(root);text("1 · Passive BEMF-Qualifikation",20,true,p);text("Gates bleiben AUS. Rad von Hand in gewünschter Vorwärtsrichtung drehen. Erst ein stabiler Sektorverlauf setzt PASSIVE_GOOD.",14,false,p);LinearLayout pr=row(p);passiveStart=button("Start",pr);passiveStop=button("Stop",pr);passiveReset=button("Reset",pr);passiveText=text("Noch keine Daten.",13,false,p);
        LinearLayout q=panel(root);text("2 · G30D Hardware-Evidenz",20,true,q);text("Diese Werte werden nur in RAM geladen und verschwinden beim Reset. Nichts ankreuzen, was nicht real gemessen wurde.",14,false,q);currentSign=field("Current sign: -1 oder +1",q);hardOc=field("Hard OC in ADC counts: 32..400",q);currentScale=field("Current µA/count",q);vbusScale=field("VBUS µV/count",q);bemfScale=field("BEMF µV/count",q);evPolarity=check("Strompolarität real bestätigt",q);evScale=check("Stromskalierung real bestätigt",q);evPb12=check("PB12/AMP_LIM Verhalten real bestätigt",q);evPwm=check("PWM/Deadtime am Scope real bestätigt",q);qualUpload=button("RAM-Qualifikation laden",q);qualText=text("ACTIVE_READY: nein",13,false,q);
        LinearLayout m=panel(root);text("3 · Motor-Bench",20,true,m);text("Aktive Tasten bleiben aus, bis Firmware ACTIVE_READY meldet. Rad frei, strombegrenzter Aufbau. STOP schaltet MOE/CCER sofort ab.",14,false,m);LinearLayout mr=row(m);proof=button("Sensorless Proof",mr);detect=button("R/L/Flux Detect",mr);stop=button("STOP",mr);driveIq=field("Iq counts 4..28",m);driveMs=field("Lease ms, max 5000",m);LinearLayout dr=row(m);driveFixed=button("Fixed Bench",dr);driveDash=button("Dashboard Bench",dr);detectText=text("Kein Lauf.",13,false,m);
        LinearLayout e=panel(root);text("Bericht",20,true,e);export=button("JSON exportieren",e);trace=text("",11,false,e);}
    private void render(){boolean r=linked&&known;refresh.setEnabled(linked);disconnect.setEnabled(linked);passiveStart.setEnabled(r&&!Boolean.TRUE.equals(diag.get("armed")));passiveStop.setEnabled(r);passiveReset.setEnabled(r);qualUpload.setEnabled(r);proof.setEnabled(activeReady);detect.setEnabled(activeReady);driveFixed.setEnabled(activeReady);driveDash.setEnabled(activeReady);stop.setEnabled(r);export.setEnabled(!events.isEmpty());
        StringBuilder s=new StringBuilder();if(known){s.append("Firmware DG10 / Protokoll ").append(diag.get("protocol")).append("\nBuild: ").append(Boolean.TRUE.equals(diag.get("active_build"))?"ACTIVE_LOCKED":"SAFE").append(" · Timing ").append(diag.get("timing_id"));s.append("\nADC offset: ").append(diag.get("offsets_ok")).append(" · ModeSwitch: ").append(diag.get("mode_switch_ok")).append(" · PB12: ").append(diag.get("pb12_high"));s.append("\nBoot-IAP kompatibel: ").append(diag.get("boot_compatible")).append(" · Flash ").append(diag.get("flash_kib")).append(" KiB");s.append("\nState: ").append(diag.get("state")).append(" · Fault: ").append(diag.get("global_fault")).append(" · armed: ").append(diag.get("armed"));s.append("\nControl max: ").append(diag.get("control_cycles_max")).append(" cycles");}else s.append(linked?"Transport verbunden, Firmwarekennung fehlt.":"Noch nicht verbunden.");summary.setText(s.toString());
        passiveText.setText(mapText(passive));qualText.setText("ACTIVE_READY: "+(activeReady?"JA":"nein")+"\n"+mapText(qual));detectText.setText(mapText(detectMap));StringBuilder tr=new StringBuilder();int from=Math.max(0,events.size()-80);for(int i=from;i<events.size();i++)tr.append(events.get(i)).append('\n');trace.setText(tr.toString());}
    private String mapText(Map<String,Object> m){if(m.isEmpty())return "Noch keine Daten.";StringBuilder s=new StringBuilder();for(Map.Entry<String,Object> e:m.entrySet())s.append(e.getKey()).append(": ").append(e.getValue()).append('\n');return s.toString();}
    private String state(int s){String[] a={"OFF","ALIGN","OPEN","BLEND","CLOSED","DONE","FAULT"};return s<a.length?a[s]:"?"+s;}private String pdState(int s){String[] a={"IDLE","R_ALIGN","R_LOW_WAIT","R_LOW","R_HIGH_WAIT","R_HIGH","L_DECAY","L_REST+","L_PULSE+","L_REST-","L_PULSE-","FLUX_PREP","FLUX_RUN","DONE","FAULT"};return s<a.length?a[s]:"?"+s;}
    private static int u16(byte[]b,int o){return(b[o]&255)|((b[o+1]&255)<<8);}private static int s16(byte[]b,int o){return(short)u16(b,o);}private static long u32(byte[]b,int o){return Packet.u32(b,o);}
    private void log(String s){if(events.size()>500)events.remove(0);events.add(new SimpleDateFormat("HH:mm:ss.SSS",Locale.ROOT).format(new Date())+"  "+s);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();log(s);render();}
    private boolean permissions(){if(Build.VERSION.SDK_INT>=31)return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;}
    private void askPermissions(){requestPermissions(Build.VERSION.SDK_INT>=31?new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT}:new String[]{Manifest.permission.ACCESS_FINE_LOCATION},10);}
    @Override public void onRequestPermissionsResult(int c,String[]p,int[]r){super.onRequestPermissionsResult(c,p,r);if(c==10&&permissions())ble.scan();}
    private String json(){StringBuilder s=new StringBuilder();s.append("{\n  \"tool\":\"DeltaESC G30D XBOT v0.10.0-rc1\",\n  \"exported_at_utc\":\"").append(utc()).append("\",\n  \"diag\":").append(jsonMap(diag)).append(",\n  \"qualification\":").append(jsonMap(qual)).append(",\n  \"passive_bemf\":").append(jsonMap(passive)).append(",\n  \"param_detect\":").append(jsonMap(detectMap)).append(",\n  \"events\":[");for(int i=0;i<events.size();i++){if(i>0)s.append(',');s.append('"').append(esc(events.get(i))).append('"');}s.append("]\n}\n");return s.toString();}
    private String jsonMap(Map<String,Object>m){StringBuilder s=new StringBuilder("{");boolean first=true;for(Map.Entry<String,Object>e:m.entrySet()){if(!first)s.append(',');first=false;s.append('"').append(esc(e.getKey())).append("\":");Object v=e.getValue();if(v instanceof Number||v instanceof Boolean)s.append(v);else s.append('"').append(esc(String.valueOf(v))).append('"');}return s.append('}').toString();}
    private String esc(String x){return x.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n");}private String utc(){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'",Locale.ROOT);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date());}
    private void saveReport(){pendingExport=json();Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"DeltaESC_G30D_XBOT_"+utc().replace(":","")+".json");startActivityForResult(i,22);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==22&&res==RESULT_OK&&data!=null&&data.getData()!=null&&pendingExport!=null)try(OutputStream o=getContentResolver().openOutputStream(data.getData(),"wt")){o.write(pendingExport.getBytes(StandardCharsets.UTF_8));o.flush();toast("Bericht gespeichert");}catch(Exception ex){toast("Exportfehler: "+ex.getMessage());}}
    private TextView text(String s,int z,boolean bold,LinearLayout p){TextView v=new TextView(this);v.setText(s);v.setTextColor(ink);v.setTextSize(z);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setPadding(0,dp(4),0,dp(5));p.addView(v);return v;}
    private LinearLayout panel(LinearLayout p){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(dp(14),dp(12),dp(14),dp(12));GradientDrawable g=new GradientDrawable();g.setColor(card);g.setCornerRadius(dp(12));x.setBackground(g);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(12);p.addView(x,lp);return x;}
    private LinearLayout row(LinearLayout p){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);p.addView(r,new LinearLayout.LayoutParams(-1,-2));return r;}
    private Button button(String s,LinearLayout p){Button b=new Button(this);b.setText(s);b.setTextColor(Color.rgb(8,25,35));b.setBackgroundColor(accent);LinearLayout.LayoutParams lp=p.getOrientation()==LinearLayout.HORIZONTAL?new LinearLayout.LayoutParams(0,-2,1):new LinearLayout.LayoutParams(-1,-2);lp.setMargins(dp(3),dp(4),dp(3),dp(4));p.addView(b,lp);return b;}
    private EditText field(String hint,LinearLayout p){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(Color.rgb(135,155,165));e.setTextColor(ink);e.setSingleLine(true);p.addView(e,new LinearLayout.LayoutParams(-1,-2));return e;}
    private CheckBox check(String s,LinearLayout p){CheckBox c=new CheckBox(this);c.setText(s);c.setTextColor(ink);p.addView(c);return c;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    @Override protected void onStop(){passivePolling=detectPolling=proofPolling=false;main.removeCallbacksAndMessages(null);if(ble!=null)ble.disconnect();super.onStop();}
}
