// SPDX-License-Identifier: AGPL-3.0-or-later
package de.ebics.g30bench;

/** Transport-level allow-list. Active motor commands additionally require the
 * firmware's RAM qualification gate; the Android UI never treats this allow
 * list as a motor-safety decision. */
public final class CommandGate {
    private CommandGate(){}
    public static boolean allows(Packet p,boolean firmwareKnown){
        if(p==null||p.src!=0x3e)return false;
        if(p.dst==0x21){
            if(p.cmd==0x5b&&p.arg==0&&p.data.length==0)return true;
            if(p.cmd==0x5c&&p.arg==0&&p.data.length==16)return true;
            if(p.cmd==0x5d&&p.arg==0&&p.data.length==14)return true;
            return p.cmd==1&&p.arg==0x1a&&p.data.length==1&&p.data[0]==2;
        }
        if(p.dst!=0x20)return false;
        if(p.cmd==1&&p.data.length==1){int n=p.data[0]&255;
            return (p.arg==0x1a&&n==2)||(p.arg==0x10&&n==14)||
                   (p.arg>=0xd0&&p.arg<=0xd9&&n==2);
        }
        if(p.cmd==0xF0&&p.arg==0&&p.data.length==0)return true;
        if(!firmwareKnown)return false;
        if(p.cmd==0xF7)return (p.arg==0&&p.data.length==0)||(p.arg==1&&p.data.length==28);
        if(p.cmd==0xF8)return p.arg<=3&&p.data.length==0;
        if((p.cmd==0xF2||p.cmd==0xF3||p.cmd==0xF4||p.cmd==0xF5)&&p.data.length==0)return true;
        if(p.cmd==0xF6){
            if((p.arg==0||p.arg==3)&&p.data.length==0)return true;
            return (p.arg==1||p.arg==2)&&p.data.length==8;
        }
        return false;
    }
}
