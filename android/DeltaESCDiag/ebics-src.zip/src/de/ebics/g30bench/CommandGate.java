// SPDX-License-Identifier: AGPL-3.0-or-later
package de.ebics.g30bench;
public final class CommandGate {
    private CommandGate(){}
    public static boolean allows(Packet p,boolean firmwareKnown){
        if(p==null||p.src!=0x3e)return false;
        if(p.dst==0x21){
            if(p.cmd==0x5b&&p.arg==0&&p.data.length==0)return true;
            if(p.cmd==0x5c&&p.arg==0&&p.data.length==16)return true;
            if(p.cmd==0x5d&&p.arg==0&&p.data.length==14)return true;
            return p.cmd==1&&p.arg==0x1a&&p.data.length==1&&p.data[0]==2;
        }
        if(p.dst!=0x20)return false;
        if(p.cmd==0x78){
            if(p.arg==0&&p.data.length==0)return true;
            if(!firmwareKnown)return false;
            return p.arg==1?p.data.length==60:(p.arg>=2&&p.arg<=4&&p.data.length==0);
        }
        if(p.cmd==0x79){
            if((p.arg==0||p.arg==1)&&p.data.length==0)return true;
            if(!firmwareKnown)return false;
            if(p.arg==2)return p.data.length==MotorProfile.SIZE;
            if((p.arg==3||p.arg==5)&&p.data.length==4){long n=Packet.u32(p.data,0);return n>=1&&n<=(p.arg==3?5000:600000);}
            return p.arg==4&&p.data.length==0;
        }
        if(p.cmd==1&&p.data.length==1){int n=p.data[0]&255;
            if((p.arg==0x1a&&n==2)||(p.arg==0x10&&n==14)||(p.arg==0xd0&&(n==4||n==16))||(p.arg==0xe0&&n==32)||(p.arg==0xf0&&n==2)||((p.arg==0xf4||p.arg==0xf5||p.arg==0xf6)&&n==2))return true;
            if(p.arg>=0xd1&&p.arg<=0xd9)return n==DeltaEscReadOnly.requestedLength(p.arg);
            return false;}
        if(!firmwareKnown||p.data.length!=0)return false;
        return (p.cmd==0x7b&&p.arg<=2)||(p.cmd==0x7a&&p.arg<=30);
    }
}
