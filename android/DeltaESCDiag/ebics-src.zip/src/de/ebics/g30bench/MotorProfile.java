// SPDX-License-Identifier: AGPL-3.0-or-later
package de.ebics.g30bench;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.zip.CRC32;
public final class MotorProfile {
    public static final int SIZE=120,MAGIC=0x344d5047,ABI=2;
    public static final int E_PHASE_ORDER=1<<2,E_ADC_DWT=1<<5,E_MOTOR_PARAMETERS=1<<6,E_ALL=0x7f,E_BENCH=E_PHASE_ORDER|E_ADC_DWT|E_MOTOR_PARAMETERS;
    public static final int P_DETECT=1,P_NOMINAL=2,P_CALIBRATED=4;
    public static final String[] FLOATS={"r","l","flux","gain","kp","ki","max_iq","trip_current","current_ramp","bus_min","bus_max","min_speed","max_speed","lock_time","max_modulation","current_a_per_count","vbus_v_per_count","phase_v_per_count"};
    public static final String[] EVIDENCE={"gate_polarity","deadtime","phase_order","current_gain","bus_and_phase_gain","adc_baseline_dwt","motor_parameters"};
    private MotorProfile(){}
    public static byte[] encode(long[] uid,long cycles,int deadtime,float[] f,int evidence,int phaseSign,int profileFlags){
        if(uid==null||uid.length!=3||f==null||f.length!=18||evidence<0||(evidence&~E_ALL)!=0||cycles<1||cycles>11000||deadtime<64||deadtime>127||
           (phaseSign!=1&&phaseSign!=-1)||(profileFlags&~7)!=0||(profileFlags&P_DETECT)==0||(((profileFlags&P_NOMINAL)!=0)==((profileFlags&P_CALIBRATED)!=0)))
            throw new IllegalArgumentException("Unvollständiger Messnachweis/Profil");
        if((uid[0]|uid[1]|uid[2])==0)throw new IllegalArgumentException("MCU-UID fehlt");
        for(long x:uid)if(x<0||x>0xffffffffL)throw new IllegalArgumentException("MCU-UID ungültig");
        for(float x:f)if(!Float.isFinite(x)||x<=0)throw new IllegalArgumentException("Motorwert fehlt/ungültig");
        range(f[0],.02f,2);range(f[1],.00001f,.005f);range(f[2],.001f,.1f);range(f[3],.8f,128000000);range(f[4],.001f,20);range(f[5],.01f,40000);
        range(f[6],.1f,3);range(f[7],.5f,12);range(f[8],.1f,5);range(f[9],25,40);range(f[10],26,43);
        range(f[11],20,300);range(f[12],30,500);range(f[13],.3f,2);range(f[14],.1f,.6f);
        range(f[15],.005f,.1f);range(f[16],.005f,.02f);range(f[17],.005f,.02f);
        if(f[6]>=f[7]||f[9]>=f[10]||f[11]>=f[12]||f[16]*4000<f[10]||f[7]/f[15]<32||f[7]/f[15]>1000)
            throw new IllegalArgumentException("Profilgrenzen widersprechen sich");
        if((evidence&E_BENCH)!=E_BENCH)throw new IllegalArgumentException("Phase/ADC/Motorparameter fehlen");
        if(evidence!=E_ALL&&(f[6]>.75f||f[7]>2.5f||f[8]>1.5f||f[14]>.35f))throw new IllegalArgumentException("Benchprofil zu aggressiv");
        if(evidence==E_ALL&&(profileFlags&P_CALIBRATED)==0)throw new IllegalArgumentException("DRIVE-Profil braucht kalibrierte Messskalierung");
        ByteBuffer b=ByteBuffer.allocate(SIZE).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(MAGIC).putInt(ABI).putInt(SIZE).putInt(evidence);for(long u:uid)b.putInt((int)u);b.putInt((int)cycles);
        for(float x:f)b.putFloat(x);b.putInt(deadtime).putInt(phaseSign).putInt(profileFlags);
        CRC32 c=new CRC32();c.update(b.array(),0,SIZE-4);b.putInt((int)c.getValue());return b.array();
    }
    public static byte[] benchFromDetect(MotorData m,DetectData d){
        if(m==null||d==null||!d.completeForBench())throw new IllegalArgumentException("R/L/Flux/Phasenrichtung noch nicht vollständig gemessen");
        if(d.v[17]!=0||d.v[22]!=1)throw new IllegalArgumentException("Detect-Hardwarezustand nicht sauber");
        long cycles=d.v[18];if(cycles<1||cycles>11000)throw new IllegalArgumentException("ADC-DWT-Budget noch nicht qualifiziert: "+cycles);
        float r=d.value(10),l=d.value(11),flux=d.value(12);float bandwidth=500f;
        float[] f={r,l,flux,1e7f,l*bandwidth,r*bandwidth,.5f,2f,.5f,25f,43f,30f,350f,.5f,.3f,
                   3.3f/(4095*.002f*9),4620f/(4096*100),3.3f*12/4095};
        long[] uid={m.v[3],m.v[4],m.v[5]};return encode(uid,cycles,64,f,E_BENCH,d.phaseSign(),P_DETECT|P_NOMINAL);
    }
    public static int level(byte[] p){
        if(p==null||p.length!=SIZE)return 0;ByteBuffer b=ByteBuffer.wrap(p).order(ByteOrder.LITTLE_ENDIAN);
        if(b.getInt(0)!=MAGIC||b.getInt(4)!=ABI||b.getInt(8)!=SIZE)return 0;int evidence=b.getInt(12),flags=b.getInt(112);
        return evidence==E_ALL&&(flags&P_CALIBRATED)!=0?2:(evidence&E_BENCH)==E_BENCH?1:0;
    }
    public static long crc(byte[] p){return p!=null&&p.length==SIZE?Packet.u32(p,SIZE-4):0;}
    private static void range(float x,float lo,float hi){if(x<lo||x>hi)throw new IllegalArgumentException("Profilwert außerhalb des Testbereichs");}
}
