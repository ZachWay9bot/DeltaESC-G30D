// SPDX-License-Identifier: AGPL-3.0-or-later
package de.ebics.g30bench;
import java.util.Arrays;

public final class Packet {
    public final int src,dst,cmd,arg;
    public final byte[] data;
    public Packet(int src,int dst,int cmd,int arg,byte[] data) {
        if((src|dst|cmd|arg)<0 || src>255 || dst>255 || cmd>255 || arg>255 || data==null || data.length>128)
            throw new IllegalArgumentException("invalid packet");
        this.src=src;this.dst=dst;this.cmd=cmd;this.arg=arg;this.data=data.clone();
    }
    public static Packet request(int dst,int cmd,int arg,byte...data){return new Packet(0x3e,dst,cmd,arg,data);}
    public byte[] inner(){
        byte[] b=new byte[7+data.length];b[0]=0x5a;b[1]=(byte)0xa5;b[2]=(byte)data.length;
        b[3]=(byte)src;b[4]=(byte)dst;b[5]=(byte)cmd;b[6]=(byte)arg;
        System.arraycopy(data,0,b,7,data.length);return b;
    }
    public byte[] wire(){byte[] b=Arrays.copyOf(inner(),data.length+9);int c=checksum(b,2,b.length-2);
        b[b.length-2]=(byte)c;b[b.length-1]=(byte)(c>>>8);return b;}
    public static Packet parseInner(byte[] b){
        if(b==null||b.length<7||b[0]!=0x5a||(b[1]&255)!=0xa5||(b[2]&255)>128||b.length!=(b[2]&255)+7)return null;
        return new Packet(b[3]&255,b[4]&255,b[5]&255,b[6]&255,Arrays.copyOfRange(b,7,b.length));
    }
    public static Packet parseWire(byte[] b){
        if(b==null||b.length<9)return null;
        int c=(b[b.length-2]&255)|((b[b.length-1]&255)<<8);
        if(c!=checksum(b,2,b.length-2))return null;
        return parseInner(Arrays.copyOf(b,b.length-2));
    }
    public static int checksum(byte[] b,int start,int end){int sum=0;for(int i=start;i<end;i++)sum+=b[i]&255;return ~sum&65535;}
    public static String hex(byte[] b){StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format(java.util.Locale.ROOT,"%02x",x&255));return s.toString();}
    public static long u32(byte[] b,int offset){return (b[offset]&255L)|((b[offset+1]&255L)<<8)|((b[offset+2]&255L)<<16)|((b[offset+3]&255L)<<24);}
    public static int u16(byte[] b,int offset){return (b[offset]&255)|((b[offset+1]&255)<<8);}
}
