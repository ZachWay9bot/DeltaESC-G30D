// SPDX-License-Identifier: AGPL-3.0-or-later
// Java port of the NinebotCrypto/MiAuth first-generation packet algorithm.
// Original protocol implementation: majsi/ScooterHacking; MiAuth: Daljeet Nandha.
package de.ebics.g30bench;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public final class LegacyCrypto {
    private static final byte[] BASIC=bytes("97cfb802844143de56002b3b34780a5d");
    private final byte[] name;
    private byte[] key,ble=new byte[16],app;
    private long counter,lastRx=-1;
    private boolean haveBle;
    public LegacyCrypto(String name){
        if(name==null||name.length()==0||name.length()>16)throw new IllegalArgumentException("BLE name required, at most 16 ASCII characters");
        for(int i=0;i<name.length();i++)if(name.charAt(i)>127)throw new IllegalArgumentException("non-ASCII BLE name");
        this.name=Arrays.copyOf(name.getBytes(StandardCharsets.US_ASCII),16);key=derive(this.name,BASIC);
    }
    public void setAppRandom(byte[] value){if(value==null||value.length!=16)throw new IllegalArgumentException("16-byte app random required");app=value.clone();}
    public byte[] encrypt(Packet p){
        byte[] plain=p.inner(),body=Arrays.copyOfRange(plain,3,plain.length),out=Arrays.copyOf(plain,plain.length+6);
        long used=counter==0?0:counter+1;
        if(used>0xffffffffL)throw new IllegalStateException("crypto counter exhausted; reconnect");
        if(used!=0&&!haveBle)throw new IllegalStateException("BLE key not established");
        byte[] crypt=crypt(body,used),mac=mac(plain,used);
        System.arraycopy(crypt,0,out,3,crypt.length);System.arraycopy(mac,0,out,plain.length,4);
        out[out.length-2]=(byte)(used>>>8);out[out.length-1]=(byte)used;
        counter=used==0?1:used;return out;
    }
    public Packet decrypt(byte[] wire){
        if(wire==null||wire.length<13||wire[0]!=0x5a||(wire[1]&255)!=0xa5||(wire[2]&255)>128||wire.length!=(wire[2]&255)+13)return null;
        int low=((wire[wire.length-2]&255)<<8)|(wire[wire.length-1]&255);
        long used=(counter&0xffff0000L)|low;
        if(used+0x8000L<counter)used+=0x10000L;
        else if(used>counter+0x8000L&&used>=0x10000L)used-=0x10000L;
        if(used>0xffffffffL||(used==0&&haveBle)||(used!=0&&(!haveBle||used<=lastRx)))return null;
        byte[] plain=Arrays.copyOf(wire,wire.length-6),body=crypt(Arrays.copyOfRange(wire,3,wire.length-6),used);
        System.arraycopy(body,0,plain,3,body.length);
        byte[] expected=mac(plain,used);int mismatch=0;
        for(int i=0;i<4;i++)mismatch|=(expected[i]^wire[wire.length-6+i])&255;
        if(mismatch!=0)return null;
        Packet p=Packet.parseInner(plain);if(p==null)return null;
        // State changes only after integrity and exact packet shape are checked.
        if(used==0){
            if(p.src!=0x21||p.dst!=0x3e||p.cmd!=0x5b||p.arg>1||p.data.length!=30)return null;
            ble=Arrays.copyOf(p.data,16);key=derive(name,ble);haveBle=true;
        }else if(p.src==0x21&&p.dst==0x3e&&p.cmd==0x5c&&p.arg==1&&p.data.length==0){
            if(app==null)return null;key=derive(app,ble);
        }
        lastRx=used;counter=Math.max(counter,used);return p;
    }
    private byte[] crypt(byte[] data,long it){
        byte[] out=new byte[data.length],iv=iv(it,1,0);
        for(int pos=0,block=1;pos<data.length;pos+=16,block++){
            if(it!=0)iv[15]=(byte)block;
            byte[] stream=aes(it==0?BASIC:iv,key);
            for(int i=0;i<16&&pos+i<data.length;i++)out[pos+i]=(byte)(data[pos+i]^stream[i]);
        }return out;
    }
    private byte[] mac(byte[] plain,long it){
        if(it==0){int c=Packet.checksum(plain,3,plain.length);return new byte[]{0,0,(byte)c,(byte)(c>>>8)};}
        byte[] iv=iv(it,0x59,plain.length-3),chain=aes(iv,key),head=new byte[16];
        System.arraycopy(plain,0,head,0,3);chain=aes(xor(head,chain),key);
        for(int pos=3;pos<plain.length;pos+=16){byte[] block=new byte[16];
            System.arraycopy(plain,pos,block,0,Math.min(16,plain.length-pos));chain=aes(xor(block,chain),key);}
        iv[0]=1;iv[15]=0;byte[] finish=aes(iv,key),out=new byte[4];
        for(int i=0;i<4;i++)out[i]=(byte)(finish[i]^chain[i]);return out;
    }
    private byte[] iv(long it,int first,int last){byte[] b=new byte[16];b[0]=(byte)first;
        for(int i=0;i<4;i++)b[1+i]=(byte)(it>>>(24-8*i));System.arraycopy(ble,0,b,5,8);b[15]=(byte)last;return b;}
    private static byte[] derive(byte[] a,byte[] b){try{byte[] data=new byte[32];System.arraycopy(a,0,data,0,16);System.arraycopy(b,0,data,16,16);
        return Arrays.copyOf(MessageDigest.getInstance("SHA-1").digest(data),16);}catch(Exception e){throw new IllegalStateException(e);}}
    private static byte[] aes(byte[] data,byte[] key){try{Cipher c=Cipher.getInstance("AES/ECB/NoPadding");c.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(key,"AES"));return c.doFinal(data);}catch(Exception e){throw new IllegalStateException(e);}}
    private static byte[] xor(byte[] a,byte[] b){byte[] r=new byte[16];for(int i=0;i<16;i++)r[i]=(byte)(a[i]^b[i]);return r;}
    public static byte[] bytes(String hex){if(hex.length()%2!=0)throw new IllegalArgumentException();byte[] b=new byte[hex.length()/2];for(int i=0;i<b.length;i++)b[i]=(byte)Integer.parseInt(hex.substring(i*2,i*2+2),16);return b;}
}
