// SPDX-License-Identifier: AGPL-3.0-or-later
package de.ebics.g30bench;
import java.util.Arrays;
public final class WireDecoder {
    public interface Validator {Packet parse(byte[] wire);}
    public interface Receiver {void receive(Packet packet);}
    private byte[] buffer=new byte[0];private long last;
    public int badFrames,expiredFragments;
    public void reset(){buffer=new byte[0];last=0;}
    public void feed(byte[] chunk,long now,boolean encrypted,Validator validator,Receiver receiver){
        if(chunk==null||chunk.length==0)return;
        if(buffer.length>0&&now-last>500){buffer=new byte[0];expiredFragments++;}last=now;
        if(chunk.length>1024||buffer.length+chunk.length>1024){reset();badFrames++;return;}
        int old=buffer.length;buffer=Arrays.copyOf(buffer,old+chunk.length);System.arraycopy(chunk,0,buffer,old,chunk.length);
        while(buffer.length>0){
            int start=-1;for(int i=0;i+1<buffer.length;i++)if(buffer[i]==0x5a&&(buffer[i+1]&255)==0xa5){start=i;break;}
            if(start<0){buffer=buffer[buffer.length-1]==0x5a?new byte[]{0x5a}:new byte[0];return;}
            if(start>0)buffer=Arrays.copyOfRange(buffer,start,buffer.length);
            if(buffer.length<3)return;
            int len=buffer[2]&255,total=len+(encrypted?13:9);
            if(len>128){dropByte();badFrames++;continue;}if(buffer.length<total)return;
            Packet p=validator.parse(Arrays.copyOf(buffer,total));
            if(p==null){dropByte();badFrames++;continue;}
            buffer=Arrays.copyOfRange(buffer,total,buffer.length);receiver.receive(p);
        }
    }
    private void dropByte(){buffer=Arrays.copyOfRange(buffer,1,buffer.length);}
}
