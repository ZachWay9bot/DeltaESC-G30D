// SPDX-License-Identifier: AGPL-3.0-or-later
package de.ebics.g30bench;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Single-threaded transactions. The Android adapter dispatches on the main looper. */
public final class Session {
    public interface IO {void send(Packet p);void later(Runnable r,int milliseconds);long now();void changed();}
    private interface Reply {void accept(Packet p);}
    private interface Failure {void run();}
    private static final class Pending {
        final Packet request;final int source,command,argument,length;final Reply reply;final Failure failure;
        int retries;
        Pending(Packet p,int source,int command,int argument,int length,int retries,Reply reply,Failure failure){
            request=p;this.source=source;this.command=command;this.argument=argument;this.length=length;this.retries=retries;this.reply=reply;this.failure=failure;}
    }
    private final IO io;
    private Pending pending;
    private boolean linked,known,busy,cancelRequested,complete,motorKnown,motorSeen,ebicsRegisterIdentity;
    private int ebicsRevision=-1;
    public MotorData motor;
    public DetectData detect;
    private boolean detectKnown,detectSeen;
    public boolean canReadDetect(){return canReadMotor()&&motorKnown&&motor!=null&&motor.v[2]==MotorData.FW;}
    public boolean canLoadDetect(){return linked&&!busy&&detectKnown&&detect!=null&&!detect.running();}
    public boolean canStartDetectFlux(){return canLoadDetect()&&detect.v[19]==1&&detect.v[17]==0&&detect.v[22]==1&&(motor==null||!motor.active());}
    public boolean canStartDetectRL(){return canStartDetectFlux()&&benchmarkQualified();}
    public boolean canStartDetect(){return canStartDetectFlux();}
    public boolean canStopDetect(){return linked&&detectSeen;}
    private byte[] lastMotorProfile=new byte[0];
    private boolean deltaKnown,deltaComplete;
    private byte[] deltaIdentity=new byte[0];
    private final DeltaEscReadOnly delta=new DeltaEscReadOnly();
    private long pollUntil;
    private int operation;
    public String status="Noch nicht verbunden",lastError="";
    public BenchData summary;
    public final Map<String,Object> stock=new LinkedHashMap<>();
    public final List<Map<String,Object>> cases=new ArrayList<>();
    public final List<String> events=new ArrayList<>();
    public Session(IO io){this.io=io;}
    public boolean isKnown(){return known;}
    public int ebicsRevision(){return ebicsRevision;}
    public boolean isTransportKnown(){return known||motorKnown||motorSeen;}
    public boolean canStopMotor(){return linked&&motorSeen;}
    public boolean isMotorKnown(){return linked&&motorKnown;}
    public boolean canReadMotor(){return linked&&!busy&&ebicsRegisterIdentity;}
    public boolean canLoadMotor(){return isMotorKnown()&&!busy;}
    public boolean benchmarkQualified(){return summary!=null&&summary.qualifiedForMotor();}
    public boolean canArmMotor(){return canLoadMotor()&&benchmarkQualified()&&motor!=null&&motor.canArmBench();}
    public boolean canArmDrive(){return canLoadMotor()&&benchmarkQualified()&&motor!=null&&motor.canArmDrive();}
    public boolean isBusy(){return busy;}
    public boolean isLinked(){return linked;}
    public boolean canStart(){return linked&&known&&!busy&&lastError.isEmpty()&&summary!=null&&summary.canStart()&&(motor==null||!motor.active());}
    public boolean canCancel(){return linked&&known;}
    public boolean canIdentifyDelta(){return linked&&!busy;}
    public boolean canReadDelta(){return linked&&!busy&&deltaKnown;}
    public boolean isDeltaKnown(){return linked&&deltaKnown;}
    public void prepareConnection(){
        detect=null;detectKnown=false;detectSeen=false;
        disconnect();complete=false;summary=null;motor=null;lastMotorProfile=new byte[0];cases.clear();stock.clear();events.clear();lastError="";clearDelta();io.changed();
    }
    public void connected(String mode){
        prepareConnection();linked=true;stock.put("transport",mode);
        status="Bluetooth bereit; prüfe ESC-Antwort";probe();
    }
    public void disconnect(){operation++;pending=null;linked=false;known=false;motorKnown=false;motorSeen=false;detectKnown=false;detectSeen=false;ebicsRegisterIdentity=false;ebicsRevision=-1;deltaKnown=false;busy=false;cancelRequested=false;status="Verbindung getrennt; vorhandener Bericht bleibt erhalten";io.changed();}
    public void probe(){
        if(!linked||busy)return;
        detectKnown=false;
        operation++;known=false;motorKnown=false;motorSeen=false;ebicsRegisterIdentity=false;ebicsRevision=-1;busy=true;lastError="";complete=false;summary=null;cases.clear();
        clearDelta();
        Object transport=stock.get("transport");stock.clear();stock.put("transport",transport);
        stock.put("esc_read_route_confirmed",false);stock.put("benchmark_firmware_detected",false);
        stock.put("ebics_motor_rc_confirmed",false);
        status="Lese Controller-Version";readRegister(0x20,0x1a,2,p->{
            stock.put("esc_version_word_hex",String.format(java.util.Locale.ROOT,"0x%04x",Packet.u16(p.data,0)));
            status="Lese Controller-Seriennummer";readRegister(0x20,0x10,14,s->{
                stock.put("esc_serial_hex",Packet.hex(s.data));
                String text=new String(s.data,StandardCharsets.US_ASCII);boolean ascii=true;
                for(byte b:s.data)if((b&255)<32||(b&255)>126)ascii=false;
                stock.put("esc_serial_ascii",ascii?text:null);stock.put("esc_read_route_confirmed",true);
                status="Lese Dashboard-Version";readRegister(0x21,0x1a,2,b->{
                    stock.put("ble_version_word_hex",String.format(java.util.Locale.ROOT,"0x%04x",Packet.u16(b.data,0)));fingerprint();
                },()->{event("Dashboard-Version ohne Antwort; ESC-Leseroute wurde bestätigt");fingerprint();});
            },()->error("Controller-Seriennummer ohne Antwort. Bluetooth allein bestätigt die ESC-Leseroute nicht."));
        },()->error("Keine bestätigte ESC-Antwort. SHU schließen, Scooter wach halten und erneut verbinden."));
        io.changed();
    }
    private void fingerprint(){
        status="Prüfe EBiCS-D0-Kennung (nur Lesen)";
        readRegister(0x20,0xd0,4,p->{
            stock.put("ebics_d0_hex",Packet.hex(p.data));
            if(Packet.u16(p.data,0)!=0x4730||Packet.u16(p.data,2)!=4){notInstalled("D0-Signatur/Protokoll unbekannt");return;}
            ebicsRegisterIdentity=true;
            status="Prüfe Benchmark-Datensatz E0 (nur Lesen)";
            readRegister(0x20,0xe0,32,b->{
                byte[] d=b.data;
                stock.put("ebics_e0_hex",Packet.hex(d));
                long dataset=Packet.u16(d,14)|((long)Packet.u16(d,16)<<16);
                if(Packet.u16(d,4)!=496||dataset!=0xfe4a2ba2L||Packet.u16(d,26)!=0x302||Packet.u16(d,28)!=1||(Packet.u16(d,30)&7)!=7){
                    notInstalled("E0-Benchmarkdatensatz/ABI oder Ausgangssperre passen nicht");return;
                }
                status="Lese EBiCS-Firmware-Revision F0";
                readRegister(0x20,0xf0,2,r->{
                    ebicsRevision=Packet.u16(r.data,0);
                    stock.put("ebics_revision",ebicsRevision);
                    if(ebicsRevision!=0x0401){notInstalled(String.format(java.util.Locale.ROOT,"EBiCS-Revision 0x%04x ist nicht MOTOR-RC1",ebicsRevision));return;}
                    status="Prüfe MOTOR-RC Service-ABIs F4/F5/F6";
                    readRegister(0x20,0xf4,2,a4->{
                        int motorAbi=Packet.u16(a4.data,0);stock.put("motor_service_abi",motorAbi);
                        if(motorAbi!=2){notInstalled("F4 Motorservice-ABI ist nicht 2");return;}
                        readRegister(0x20,0xf5,2,a5->{
                            int profileAbi=Packet.u16(a5.data,0);stock.put("motor_profile_abi",profileAbi);
                            if(profileAbi!=2){notInstalled("F5 Motorprofil-ABI ist nicht 2");return;}
                            readRegister(0x20,0xf6,2,a6->{
                                int detectAbi=Packet.u16(a6.data,0);stock.put("motor_detect_abi",detectAbi);
                                if(detectAbi!=2){notInstalled("F6 Motor-Detect-ABI ist nicht 2");return;}
                                stock.put("ebics_motor_rc_confirmed",true);known=true;stock.put("benchmark_firmware_detected",true);
                                status="EBiCS v0.4 MOTOR-RC1 + Service-ABIs bestätigt; lese Hardware-Sperre";
                                readSummary(this::showSummary,()->error("MOTOR-RC1-Kennung passt, aber CMD7B erreicht die App nicht"));
                            },()->notInstalled("F6 Motor-Detect-ABI fehlt"));
                        },()->notInstalled("F5 Motorprofil-ABI fehlt"));
                    },()->notInstalled("F4 Motorservice-ABI fehlt"));
                },()->notInstalled("F0-Revisionsantwort fehlt; kein Benchmark-Start"));
            },()->notInstalled("E0-Datensatz nicht erreichbar"));
        },()->notInstalled("D0-Kennung nicht erreichbar"));
    }
    private void notInstalled(String reason){
        known=false;stock.put("benchmark_firmware_detected",false);
        finish("ESC-Leseroute bestätigt; "+reason+". Benchmark-Start gesperrt.");
    }
    private void clearDelta(){delta.reset();deltaKnown=false;deltaComplete=false;deltaIdentity=new byte[0];}
    public void identifyDelta(){
        if(!canIdentifyDelta())return;
        operation++;busy=true;lastError="";clearDelta();
        verifyDelta(()->finish("DeltaESC-Kennung bestätigt. D1–D9 können gelesen werden."));
        io.changed();
    }
    private void verifyDelta(Runnable accepted){
        status="Lese DeltaESC-Kennung D0 (nur Lesen)";
        // Stock and older diagnostic firmware may return a shorter payload.
        // That is an unknown identity, not a malformed Bluetooth connection.
        request(Packet.request(0x20,1,0xd0,(byte)16),0x20,4,0xd0,-1,2,p->{
            deltaIdentity=p.data.clone();
            deltaKnown=delta.accept(p.src,p.cmd,p.arg,p.data);
            if(!deltaKnown){deltaComplete=false;finish("D0 ohne unterstützte DESC-Kennung: D1–D9 bleiben gesperrt. Antwort im Bericht gespeichert.");return;}
            accepted.run();
        },()->{deltaKnown=false;deltaComplete=false;error("DeltaESC-D0 ohne Antwort. ESC-Verbindung und Firmwarekennung getrennt prüfen.");});
    }
    public void readDelta(){
        if(!canReadDelta())return;
        operation++;busy=true;lastError="";clearDelta();
        // A cached identity never authorizes a fresh telemetry collection.
        verifyDelta(()->collectDelta(0xd1));io.changed();
    }
    private void collectDelta(int reg){
        if(reg>0xd9){deltaComplete=true;finish("DeltaESC D0–D9 vollständig gelesen. Keine Motorfreigabe.");return;}
        status=String.format(java.util.Locale.ROOT,"Lese DeltaESC %02X (nur Lesen)",reg);
        readRegister(0x20,reg,DeltaEscReadOnly.requestedLength(reg),p->{
            if(!delta.accept(p.src,p.cmd,p.arg,p.data)){error("DeltaESC-Antwort passt nicht zum bestätigten Format");return;}
            collectDelta(reg+1);
        },()->error(String.format(java.util.Locale.ROOT,"DeltaESC %02X ohne Antwort; Diagnose unvollständig",reg)));
        io.changed();
    }
    public Map<String,Object> deltaReport(){
        Map<String,Object> result=new LinkedHashMap<>();
        result.put("identity_confirmed",deltaKnown);result.put("complete",deltaComplete);
        result.put("identity_payload_hex",Packet.hex(deltaIdentity));
        result.put("mode",delta.mode().name());result.put("build_word_hex",String.format(java.util.Locale.ROOT,"0x%04x",delta.build()));
        Map<String,Object> registers=new LinkedHashMap<>();
        for(Map.Entry<Integer,DeltaEscReadOnly.Answer> e:delta.snapshot().entrySet())registers.put(String.format(java.util.Locale.ROOT,"%02x",e.getKey()),Packet.hex(e.getValue().bytes));
        result.put("registers_hex",registers);result.put("values",delta.diagnosticSummary());
        return result;
    }
    public void read(){if(!linked||busy)return;if(!known){probe();return;}busy=true;complete=false;cases.clear();lastError="";operation++;readSummary(this::showSummary,()->error("Benchmark-Status ohne Antwort"));}
    public void start(){
        if(!canStart())return;
        busy=true;complete=false;cases.clear();lastError="";operation++;
        // Re-read immediately before mutation; never act on a stale UI value.
        readSummary(before->{
            if(!before.canStart()){summary=before;finish("Start verweigert: Status oder Ausgangssperre passt nicht.");return;}
            long generation=(before.values[3]+1)&0xffffffffL;pollUntil=io.now()+15000;
            request(Packet.request(0x20,0x7b,1),0x20,0x7b,-1,64,0,p->{
                BenchData data=parseSummary(p);if(data==null)return;
                if(data.values[3]!=generation){error("Unerwartete Startgeneration");return;}afterStart(data);
            },()->{
                event("Start-ACK verloren; kein erneuter Start, nur Generation lesen");
                readSummary(data->{if(data.values[3]!=generation){error("Start nicht bestätigt; kein Neustart gesendet");return;}afterStart(data);},()->error("Startausgang unbekannt. Status lesen; Start nicht wiederholen."));
            });
        },()->error("Status vor Start ohne Antwort"));io.changed();
    }
    private void afterStart(BenchData data){
        summary=data;
        if(cancelRequested){sendCancel();return;}
        if(data.values[2]==1){status="Benchmark: "+data.values[4]+" / 496";io.changed();
            int epoch=operation;io.later(()->{if(epoch!=operation||!busy||pending!=null)return;
                if(cancelRequested){sendCancel();return;}if(io.now()>pollUntil){error("Benchmark-Zeitlimit. Status lesen oder abbrechen; kein automatischer Neustart.");return;}
                readSummary(this::afterStart,()->error("Statusabfrage ohne Antwort; Status lesen oder abbrechen"));},150);
        }else showSummary(data);
    }
    public void cancel(){
        if(!canCancel())return;
        if(busy){cancelRequested=true;status="Abbruch vorgemerkt";io.changed();if(pending==null)sendCancel();}
        else {operation++;busy=true;cancelRequested=true;sendCancel();}
    }
    private void sendCancel(){
        if(pending!=null)return;cancelRequested=false;
        request(Packet.request(0x20,0x7b,2),0x20,0x7b,-1,64,0,p->{
            BenchData d=parseSummary(p);if(d==null)return;summary=d;complete=false;cases.clear();finish("Abbruch beantwortet; Controllerzustand "+state(d.values[2]));
        },()->error("Abbruch-ACK fehlt. Status lesen; Abbruch wurde nicht wiederholt."));
    }
    private void showSummary(BenchData data){
        summary=data;
        if(cancelRequested){sendCancel();return;}
        if(!data.inhibited()){known=false;error("Ausgangssperre nicht bestätigt. Kein weiterer Benchmark-Start.");return;}
        if(data.values[2]==2){
            if(data.values[4]!=496||data.values[13]!=496){error("Abschluss ohne 496 geprüfte Aufrufe");return;}
            cases.clear();collectCase(0,data.values[3]);
        }else finish("Benchmarkzustand: "+state(data.values[2])+"; "+data.values[4]+" / 496");
    }
    private void collectCase(int index,long generation){
        if(cancelRequested){sendCancel();return;}
        if(index==31){readSummary(finalData->{
            if(finalData.values[3]!=generation||finalData.values[2]!=2||finalData.values[4]!=496||finalData.values[13]!=496||!finalData.inhibited()){error("Ergebnisse während Auslesen geändert; Bericht unvollständig");return;}
            long maximum=0,errors=0;for(Map<String,Object> c:cases){maximum=Math.max(maximum,((Number)c.get("cycles_max")).longValue());errors|=((Number)c.get("error_flags")).longValue();}
            if(maximum!=finalData.values[6]||errors!=finalData.values[11]||((Number)cases.get((int)finalData.values[7]).get("cycles_max")).longValue()!=maximum){error("Fallmaximum/Fehler und Summary widersprechen sich");return;}
            summary=finalData;complete=true;finish("496 / 496 geprüft; 31 Fälle gelesen. "+(finalData.values[11]==0?"Kein Benchmarkfehler.":"Fehlerflags: "+finalData.values[11])+" Keine Motorfreigabe.");
        },()->error("Abschlussgeneration nicht bestätigt"));return;}
        status="Lese Fall "+(index+1)+" / 31";io.changed();
        request(Packet.request(0x20,0x7a,index),0x20,0x7a,-1,48,2,p->{
            try{BenchData c=new BenchData(p,false);long[] v=c.values;
                int expectedKind=index<12?index:(index==20?3:((index==16||index==22||index==27)?5:4));
                int expectedFault=index>=8&&index<=11?1<<(index-8):0;
                if(v[2]!=generation||v[3]!=index||v[6]!=16||v[4]!=expectedKind||v[5]!=(index<20?600:1800)||v[11]!=expectedFault)throw new IllegalArgumentException("case/dataset/generation mismatch");
                cases.add(c.asMap());collectCase(index+1,generation);
            }catch(IllegalArgumentException ex){error("Fall nicht konsistent: "+ex.getMessage());}
        },()->error("Fall "+index+" ohne Antwort"));
    }
    private void readSummary(java.util.function.Consumer<BenchData> next,Failure failure){
        request(Packet.request(0x20,0x7b,0),0x20,0x7b,-1,64,2,p->{BenchData d=parseSummary(p);if(d!=null)next.accept(d);},failure);
    }
    private BenchData parseSummary(Packet p){try{return new BenchData(p,true);}catch(IllegalArgumentException ex){known=false;error("Ungültige Benchmarkantwort: "+ex.getMessage());return null;}}
    private void readRegister(int dst,int reg,int length,Reply reply,Failure failure){request(Packet.request(dst,1,reg,(byte)length),dst,4,reg,length,2,reply,failure);}
    public void readMotor(){
        if(!canReadMotor())return;operation++;busy=true;lastError="";
        motorRead(1,()->finish(motorText()));io.changed();
    }
    private String motorText(){return motor==null?"Motorservice unbekannt":
        "Motorservice: "+MotorData.stateText(motor.v[9])+", Rest "+motor.v[10]+" ms, Profil-Level "+motor.v[23]+", Fehler "+motor.v[13]+". Kein Fahrnachweis.";}
    private void motorRead(int action,Runnable next){
        request(Packet.request(0x20,0x79,action),0x20,0x79,action,96,2,p->{
            if(!acceptMotor(p))return;next.run();
        },()->{motorKnown=false;error("Motorservice ohne Antwort. Zustand unbekannt; Gas weg/Bremse, keine automatische Freigabe.");});
    }
    private boolean acceptMotor(Packet p){
        try{motor=new MotorData(p);motorKnown=true;motorSeen=true;
            if(motor.v[8]!=0){error("Motorservice verweigert: "+motor.v[8]+" (1 Format, 2 Profil, 3 UID, 4 Stillstand/Gas/Bremse/Frische, 5 ADC/Fehler/Bus, 6 Dauer, 7 Qualifikation)");return false;}
            return true;
        }catch(IllegalArgumentException e){motorKnown=false;error(e.getMessage());return false;}
    }
    public void loadMotorProfile(byte[] bytes){
        if(!canLoadMotor())return;
        if(bytes==null||bytes.length!=MotorProfile.SIZE){error("Profil muss "+MotorProfile.SIZE+" Bytes enthalten");return;}
        for(int i=0;i<3;i++)if(Packet.u32(bytes,16+4*i)!=motor.v[3+i]){error("Messprofil gehört zu einer anderen MCU");return;}
        operation++;busy=true;lastError="";byte[] copy=bytes.clone();
        request(new Packet(0x3e,0x20,0x79,2,copy),0x20,0x79,2,96,0,p->{
            if(!acceptMotor(p))return;
            if(motor.v[23]<1||motor.v[12]!=MotorProfile.crc(copy)||motor.v[9]!=MotorData.STATE_OFF){error("Profilübernahme nicht bestätigt");return;}
            lastMotorProfile=copy;finish("Messprofil im ESC-RAM bestätigt (Level "+motor.v[23]+"). Nach Reset neu laden.");
        },()->{motorKnown=false;error("Profil-ACK fehlt. Status lesen; Profil nicht automatisch wiederholen.");});io.changed();
    }
    public void armMotor(int duration){
        if(!canArmMotor()||duration<1||duration>5000)return;
        operation++;busy=true;lastError="";
        motorRead(0,()->{
            if(!benchmarkQualified()){finish("MOTOR_BENCH verweigert: der aktuelle 496/496-Benchmark ist nicht fehlerfrei innerhalb des Zeitbudgets.");return;}
            if(!motor.canArmBench()){finish("MOTOR_BENCH verweigert: Gas null, Bremse, Stillstand oder Messdaten fehlen.");return;}
            final long seq=(motor.v[6]+1)&0xffffffffL,crc=motor.v[12];
            byte[] data=new byte[4];for(int i=0;i<4;i++)data[i]=(byte)(duration>>>(8*i));
            request(new Packet(0x3e,0x20,0x79,3,data),0x20,0x79,3,96,0,p->{
                if(!acceptMotor(p))return;
                if(motor.v[6]!=seq||motor.v[7]!=seq||motor.v[9]!=1||motor.v[11]!=crc||motor.v[10]==0){error("Testfreigabe nicht bestätigt; Gas weg/Bremse und Status lesen.");return;}
                status="MOTOR_BENCH aktiv: Bremse lösen, Gas zunächst null, Rad vorwärts anschieben. Maximal "+duration+" ms.";
                io.changed();motorPoll(operation);
            },()->{motorKnown=false;error("Start-ACK fehlt. Kein zweiter Start. Gas weg/Bremse, Status lesen.");});
        });io.changed();
    }
    public void armDrive(int duration){
        if(!canArmDrive()||duration<1||duration>600000)return;
        operation++;busy=true;lastError="";
        motorRead(0,()->{
            if(!benchmarkQualified()){finish("DRIVE-RC verweigert: der aktuelle 496/496-Benchmark ist nicht fehlerfrei innerhalb des Zeitbudgets.");return;}
            if(!motor.canArmDrive()){finish("DRIVE-RC verweigert: vollständige kalibrierte Evidenz und alle Interlocks erforderlich.");return;}
            final long seq=(motor.v[6]+1)&0xffffffffL,crc=motor.v[12];
            byte[] data=new byte[4];for(int i=0;i<4;i++)data[i]=(byte)(duration>>>(8*i));
            request(new Packet(0x3e,0x20,0x79,5,data),0x20,0x79,5,96,0,p->{
                if(!acceptMotor(p))return;
                if(motor.v[6]!=seq||motor.v[7]!=seq||motor.v[9]!=MotorData.STATE_DRIVE||motor.v[11]!=crc||motor.v[10]==0){error("DRIVE-RC-Freigabe nicht bestätigt; Gas weg/Bremse und Status lesen.");return;}
                status="DRIVE-RC aktiv für maximal "+duration+" ms. Weiterhin kein Straßen-/Fahrfreigabenachweis.";
                io.changed();motorPoll(operation);
            },()->{motorKnown=false;error("DRIVE-RC-ACK fehlt. Kein zweiter Start. Gas weg/Bremse, Status lesen.");});
        });io.changed();
    }
    private void motorPoll(int epoch){
        io.later(()->{if(epoch!=operation||!linked||!busy||pending!=null)return;
            motorRead(0,()->{status=motorText();io.changed();if(motor.active())motorPoll(epoch);else finish(status);});
        },250);
    }
    public void stopMotor(){
        if(!canStopMotor())return;
        operation++;pending=null;busy=true;lastError="";
        request(Packet.request(0x20,0x79,4),0x20,0x79,4,96,0,p->{
            if(!acceptMotor(p))return;
            if(motor.v[9]!=0||motor.v[10]!=0||motor.v[20]!=0){error("Abschaltung nicht bestätigt. Gas weg/Bremse.");return;}
            finish("ESC hat Motortest beendet; PWM-Freigabe aus.");
        },()->{motorKnown=false;error("STOP-ACK fehlt. Abschaltung über BLE unbestätigt; Gas weg/Bremse.");});io.changed();
    }
    private void request(Packet p,int src,int cmd,int arg,int len,int retries,Reply callback,Failure failure){
        if(!linked||pending!=null){error("Transaktion ohne Verbindung oder überlappend");return;}
        if(p.cmd==0x79&&!ebicsRegisterIdentity){error("Motorservice ohne bestätigte EBiCS-Registerkennung gesperrt");return;}
        if(p.cmd==0x78&&(!ebicsRegisterIdentity||motor==null||motor.v[2]!=MotorData.FW||
           (!(p.arg==4&&detectSeen)&&(!motorKnown||(p.arg!=0&&!detectKnown))))){error("Motor-Detect ohne bestätigte v0.4-Kennung gesperrt");return;}
        if(p.dst==0x20&&p.cmd==1&&p.arg>=0xd1&&p.arg<=0xd9&&!deltaKnown){error("DeltaESC-Telemetrie ohne bestätigte DESC-Kennung gesperrt");return;}
        if(p.cmd==0x79&&p.arg>=2&&!motorKnown&&!(p.arg==4&&motorSeen)){error("Motorbefehl ohne bestätigte Motorservice-Kennung gesperrt");return;}
        if(!CommandGate.allows(p,isTransportKnown())){error("Befehl durch feste App-Sperre abgewiesen");return;}
        pending=new Pending(p,src,cmd,arg,len,retries,callback,failure);transmit(pending);
    }
    private void transmit(Pending p){
        event(String.format(java.util.Locale.ROOT,"TX dst=%02x cmd=%02x arg=%02x len=%d",p.request.dst,p.request.cmd,p.request.arg,p.request.data.length));
        try{io.send(p.request);}catch(RuntimeException ex){error("Übertragung fehlgeschlagen: "+ex.getMessage());return;}
        io.later(()->{if(pending!=p)return;if(p.retries-->0){event("Nur Leseanfrage wird wiederholt");transmit(p);}else{pending=null;p.failure.run();io.changed();}},1600);
    }
    public void receive(Packet p){
        Pending wait=pending;if(wait==null||p.src!=wait.source||p.dst!=0x3e||p.cmd!=wait.command||(wait.argument>=0&&p.arg!=wait.argument))return;
        pending=null;event(String.format(java.util.Locale.ROOT,"RX src=%02x cmd=%02x arg=%02x len=%d",p.src,p.cmd,p.arg,p.data.length));
        if(wait.argument<0&&p.arg!=0){error("Benchmarkstatus "+p.arg+" (1 Format, 2 beschäftigt, 3 Sperre/Recovery, 4 DWT)");return;}
        if(wait.length>=0&&p.data.length!=wait.length){error("Antwortlänge passt nicht");return;}
        wait.reply.accept(p);io.changed();
    }
    public void event(String text){if(events.size()==240)events.remove(0);events.add(text);}
    private void error(String message){lastError=message;complete=false;motorKnown=false;deltaKnown=false;deltaComplete=false;finish(message);}
    private void finish(String message){pending=null;busy=false;cancelRequested=false;status=message;io.changed();}
    public void readDetect(){
        if(!canReadDetect())return;operation++;busy=true;lastError="";
        detectRequest(0,new byte[0],()->finish(detect.text()));io.changed();
    }
    private void detectRequest(int action,byte[] bytes,Runnable next){
        request(new Packet(0x3e,0x20,0x78,action,bytes),0x20,0x78,action,96,action==0?1:0,p->{
            try{detect=new DetectData(p);detectKnown=true;detectSeen=true;
                if(detect.v[3]!=0){error("Motor-Detect verweigert: "+detect.v[3]+" (2 Profil, 3 UID, 4 Stillstand/Bremse/Gas/Frische, 5 ADC/Bus/Fehler, 6 Zeit, 7 Signal, 8 Auswertung)");return;}
                next.run();
            }catch(IllegalArgumentException e){detectKnown=false;error(e.getMessage());}
        },()->{detectKnown=false;error("Motor-Detect ohne Antwort; Messfreigabe läuft ohne Statuskontakt spätestens nach 500 ms ab. Kein automatischer Neustart.");});
    }
    public void loadDetect(){
        if(!canLoadDetect())return;byte[] h=DetectData.stockHardware(motor);operation++;busy=true;lastError="";
        detectRequest(1,h,()->{
            if(detect.v[8]!=Packet.u32(h,56)||detect.v[19]!=1||detect.v[9]!=1||detect.v[4]!=0||(detect.v[23]&7)!=0){error("Hardwareprofil-Übernahme nicht bestätigt");return;}
            finish("DRV126-Hardwareprofil im RAM geladen. Nominale Messfaktoren; R/L/Flux werden erst gemessen.");
        });io.changed();
    }
    public void startDetect(boolean rl){
        if(rl?!canStartDetectRL():!canStartDetectFlux())return;operation++;busy=true;lastError="";int epoch=operation;
        detectRequest(0,new byte[0],()->{
            if(detect.running()||detect.v[19]!=1||detect.v[17]!=0||detect.v[22]!=1||(detect.v[23]&7)!=0){finish("Messstart verweigert: Hardware-/Ausgangszustand passt nicht.");return;}
            final long generation=(detect.v[5]+1)&0xffffffffL,crc=detect.v[8];
            detectRequest(rl?2:3,new byte[0],()->{
                if(detect.v[5]!=generation||detect.v[8]!=crc||detect.v[4]!=(rl?1:2)){error("Messstart nicht bestätigt; kein weiterer Start gesendet.");return;}
                status=rl?"R/L-Messung: Bremse halten, Gas null, Rad frei aufgebockt.":"Flux-Messung: Rad jetzt von Hand anschieben. Gates bleiben aus.";
                io.changed();detectPoll(epoch,generation);
            });
        });io.changed();
    }
    private void detectPoll(int epoch,long generation){
        io.later(()->{if(epoch!=operation||!linked||!busy||pending!=null)return;
            detectRequest(0,new byte[0],()->{
                if(detect.v[5]!=generation){error("Messgeneration geändert; Bericht nicht als aktuellen Abschluss verwenden.");return;}
                status=detect.text();io.changed();if(detect.running())detectPoll(epoch,generation);else finish(status);
            });
        },100);
    }
    public void stopDetect(){
        if(!canStopDetect())return;operation++;pending=null;busy=true;lastError="";
        detectRequest(4,new byte[0],()->{
            if(detect.v[4]!=5||(detect.v[23]&7)!=0){error("Messabschaltung nicht bestätigt.");return;}
            finish("Motor-Detect beendet; Ausgänge gesperrt. "+detect.text());
        });io.changed();
    }
    public Map<String,Object> report(){Map<String,Object> m=new LinkedHashMap<>();m.put("tool","G30 Motor BLE 0.2.0-rc1");m.put("stock",new LinkedHashMap<>(stock));m.put("summary",summary==null?null:summary.asMap());m.put("cases",new ArrayList<>(cases));m.put("deltaesc",deltaReport());
        m.put("motor_service",motor==null?null:motor.report());m.put("motor_identity_current",isMotorKnown());m.put("motor_profile_hex",Packet.hex(lastMotorProfile));
        m.put("motor_detect",detect==null?null:detect.report());
        m.put("connection_active",linked);m.put("suite_complete",complete);m.put("status",status);m.put("error",lastError);m.put("events",new ArrayList<>(events));m.put("motor_drive_qualified",false);
        m.put("interpretation","Core DWT intervals only. UART/SysTick preemption included; ADC/ISR/PWM adapter costs excluded. A clean in-budget run is only one RAM-only prerequisite for MOTOR_BENCH/DRIVE_RC, not road qualification.");return m;}
    private static String state(long s){return s==0?"idle":s==1?"running":s==2?"done":s==3?"canceled":"error";}
}
