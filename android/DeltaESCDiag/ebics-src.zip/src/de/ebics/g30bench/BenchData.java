// SPDX-License-Identifier: AGPL-3.0-or-later
package de.ebics.g30bench;
import java.util.LinkedHashMap;
import java.util.Map;
public final class BenchData {
    public final long[] values;
    private final boolean summary;
    public BenchData(Packet p,boolean summary){
        if(p.src!=0x20||p.dst!=0x3e||p.cmd!=(summary?0x7b:0x7a)||p.arg!=0||p.data.length!=(summary?64:48))throw new IllegalArgumentException("unexpected benchmark reply");
        values=new long[p.data.length/4];for(int i=0;i<values.length;i++)values[i]=Packet.u32(p.data,4*i);
        if(values[0]!=(summary?0x4d423347L:0x43423347L)||values[1]!=0x302)throw new IllegalArgumentException("unknown firmware/benchmark format");
        if(summary&&(values[2]>4||values[5]!=496||values[12]!=0xfe4a2ba2L||values[4]>496||values[13]>values[4]||values[7]>30||values[9]!=64000000||values[10]!=11000||(values[15]&6)!=6||(values[15]&~31L)!=0||(values[11]&~15L)!=0||((values[15]&16)!=0)!=((values[11]&8)!=0)||(values[2]==1&&(values[15]&8)==0)))
            throw new IllegalArgumentException("invalid benchmark summary or dataset");
        if(!summary&&(values[3]>30||values[4]>11||values[6]>16||values[7]>values[8]||values[9]<values[7]||values[9]>values[8]||(values[10]&~15L)!=0))throw new IllegalArgumentException("invalid benchmark case");
        this.summary=summary;
    }
    public boolean inhibited(){return summary&&(values[15]&1)!=0;}
    /** Mirrors the firmware RAM-only motor prerequisite: complete, verified, in budget, gates off. */
    public boolean qualifiedForMotor(){return summary&&inhibited()&&values[2]==2&&values[4]==values[5]&&values[13]==values[5]&&
        values[5]==496&&values[11]==0&&values[6]>0&&values[6]<=values[10];}
    public boolean canStart(){return inhibited()&&values[2]!=1&&(values[11]&7)==0;}
    public Map<String,Object> asMap(){
        String[] names=summary?new String[]{"signature","version","state","generation","completed","total","cycles_max","worst_case","overhead_min","configured_cpu_hz","whole_adc_handler_budget_cycles","error_flags","dataset_crc32","verified","elapsed_ms","flags"}:
            new String[]{"signature","version","generation","case_id","kind","synthetic_erpm","samples","cycles_min","cycles_max","cycles_last","error_flags","expected_model_faults"};
        Map<String,Object> m=new LinkedHashMap<>();for(int i=0;i<names.length;i++)m.put(names[i],values[i]);
        m.put("motor_drive_qualified",false);
        m.put("measurement_scope","isolated control core; UART/SysTick included; ADC/ISR/PWM adapter excluded");
        if(summary){m.put("outputs_inhibited",inhibited());m.put("core_only_scope",true);m.put("sampling_paused",(values[15]&8)!=0);
            m.put("motor_benchmark_qualified",qualifiedForMotor());m.put("raw_core_interval_us_nominal",values[6]/64.0);m.put("overhead_subtracted",false);}
        return m;
    }
}
