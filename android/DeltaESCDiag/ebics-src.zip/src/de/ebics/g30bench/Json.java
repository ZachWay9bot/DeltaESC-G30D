// SPDX-License-Identifier: AGPL-3.0-or-later
package de.ebics.g30bench;
import java.util.Map;
public final class Json {
    private Json(){}
    public static String write(Object value){StringBuilder s=new StringBuilder();append(s,value);return s.toString();}
    private static void append(StringBuilder s,Object v){
        if(v==null){s.append("null");return;}
        if(v instanceof Boolean||v instanceof Number){s.append(v.toString());return;}
        if(v instanceof Map){s.append('{');boolean comma=false;for(Object e:((Map<?,?>)v).entrySet()){
            Map.Entry<?,?> x=(Map.Entry<?,?>)e;if(comma)s.append(',');quote(s,String.valueOf(x.getKey()));s.append(':');append(s,x.getValue());comma=true;}s.append('}');return;}
        if(v instanceof Iterable){s.append('[');boolean comma=false;for(Object x:(Iterable<?>)v){if(comma)s.append(',');append(s,x);comma=true;}s.append(']');return;}
        quote(s,v.toString());
    }
    private static void quote(StringBuilder s,String text){s.append('"');for(int i=0;i<text.length();i++){
        char c=text.charAt(i);if(c=='"'||c=='\\'){s.append('\\').append(c);}else if(c<32){s.append(String.format(java.util.Locale.ROOT,"\\u%04x",(int)c));}else s.append(c);}s.append('"');}
}
