// SPDX-License-Identifier: AGPL-3.0-or-later
package de.ebics.g30bench;
import android.annotation.SuppressLint;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.*;

/** Only classic Nordic UART + first-generation Ninebot crypto. No updater. */
@SuppressLint("MissingPermission")
public final class BleClient {
    public interface Listener {
        void status(String text);void device(BluetoothDevice d,String name,int rssi);
        void ready(String mode);void packet(Packet p);void disconnected();void metadata(String key,Object value);
    }
    private static final UUID SERVICE=UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID TX=UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID RX=UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID CCCD=UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private final Context context;private final Listener listener;private final Handler main=new Handler(Looper.getMainLooper());
    private final BluetoothAdapter adapter;private BluetoothLeScanner scanner;private ScanCallback scanCallback;private BluetoothGatt gatt;
    private BluetoothGattCharacteristic tx,rx,nameChar;private BluetoothGattDescriptor descriptor;
    private final WireDecoder decoder=new WireDecoder();private LegacyCrypto crypto;
    private final ArrayDeque<byte[]> writes=new ArrayDeque<>();private byte[] inFlight;
    private int writeAttempts,writeType,epoch,pairAttempts;private String stage="off",deviceName="";
    private byte[] serial,appRandom;private boolean encrypted,ready;
    public BleClient(Context c,Listener l){context=c.getApplicationContext();listener=l;
        BluetoothManager m=(BluetoothManager)c.getSystemService(Context.BLUETOOTH_SERVICE);adapter=m==null?null:m.getAdapter();}
    public boolean isReady(){return ready;}
    public void scan(){
        disconnect();
        if(adapter==null||!adapter.isEnabled()){listener.status("Bluetooth einschalten und erneut suchen");return;}
        scanner=adapter.getBluetoothLeScanner();if(scanner==null){listener.status("BLE-Scanner fehlt");return;}
        stage="scan";scanCallback=newScanCallback(epoch);listener.status("Suche: deinen Scooter in der Liste auswählen");
        try{scanner.startScan(null,new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(),scanCallback);
            int token=epoch;main.postDelayed(()->{if(token==epoch&&scanner!=null){stopScan();stage="off";listener.status("Suche beendet; Scooter auswählen oder erneut suchen");}},10000);
        }catch(RuntimeException ex){fail("Scan fehlgeschlagen: "+ex.getMessage());}
    }
    private ScanCallback newScanCallback(final int token){return new ScanCallback(){
        @Override public void onScanResult(int type,ScanResult r){main.post(()->{
            if(token!=epoch||scanner==null||!stage.equals("scan"))return;
            String name=r.getScanRecord()==null?null:r.getScanRecord().getDeviceName();
            if(name==null)try{name=r.getDevice().getName();}catch(SecurityException ignored){}
            List<android.os.ParcelUuid> services=r.getScanRecord()==null?null:r.getScanRecord().getServiceUuids();
            String n=name==null?"":name.toLowerCase(Locale.ROOT);
            if(n.contains("nbscooter")||n.contains("ninebot")||n.contains("segway")||(services!=null&&services.contains(new android.os.ParcelUuid(SERVICE))))
                listener.device(r.getDevice(),name==null?"Ninebot UART":name,r.getRssi());
        });}
        @Override public void onScanFailed(int code){main.post(()->{
            if(token==epoch&&scanner!=null&&stage.equals("scan"))fail("BLE-Scanfehler "+code);
        });}
    };}
    public void connect(BluetoothDevice d,String name){
        disconnect();deviceName=name==null?"":name;listener.metadata("device_name",deviceName);
        listener.metadata("device_address",d.getAddress());stage="connect";listener.status("Verbinde "+deviceName);
        try{gatt=d.connectGatt(context,false,callback,BluetoothDevice.TRANSPORT_LE);if(gatt==null){fail("GATT-Verbindung konnte nicht starten");return;}timeout("connect",10000,"Verbindungszeitlimit");}
        catch(RuntimeException ex){fail("Verbindung fehlgeschlagen: "+ex.getMessage());}
    }
    public void disconnect(){
        epoch++;main.removeCallbacksAndMessages(null);stopScan();ready=false;stage="off";encrypted=false;writes.clear();inFlight=null;
        BluetoothGatt previous=gatt;gatt=null;tx=rx=nameChar=null;descriptor=null;crypto=null;serial=appRandom=null;decoder.reset();
        if(previous!=null){try{previous.disconnect();}catch(RuntimeException ignored){}try{previous.close();}catch(RuntimeException ignored){}}
        listener.disconnected();
    }
    private void stopScan(){BluetoothLeScanner s=scanner;ScanCallback c=scanCallback;scanner=null;scanCallback=null;
        if(s!=null&&c!=null)try{s.stopScan(c);}catch(RuntimeException ignored){}}
    private void fail(String text){disconnect();listener.status(text);}
    private void timeout(String expected,int ms,String text){int token=epoch;main.postDelayed(()->{if(token==epoch&&stage.equals(expected))fail(text);},ms);}
    private final BluetoothGattCallback callback=new BluetoothGattCallback(){
        @Override public void onConnectionStateChange(BluetoothGatt g,int status,int state){main.post(()->{
            if(g!=gatt)return;
            if(status!=BluetoothGatt.GATT_SUCCESS){fail("GATT-Fehler "+status);return;}
            if(state==BluetoothProfile.STATE_CONNECTED){stage="discover";listener.status("BLE verbunden; suche UART-Service");
                if(!g.discoverServices())fail("Service-Suche abgewiesen");else timeout("discover",8000,"Service-Suche ohne Antwort");}
            else if(state==BluetoothProfile.STATE_DISCONNECTED)fail("Bluetooth getrennt; kein automatischer Neustart");
        });}
        @Override public void onServicesDiscovered(BluetoothGatt g,int status){main.post(()->{
            if(g!=gatt||!stage.equals("discover"))return;
            List<String> uuids=new ArrayList<>();for(BluetoothGattService s:g.getServices())uuids.add(s.getUuid().toString());listener.metadata("gatt_services",uuids);
            if(status!=0){fail("Service-Suche Fehler "+status);return;}
            BluetoothGattService nus=g.getService(SERVICE);
            if(nus==null){fail("Classic Ninebot-UART-Service fehlt. Dieses BLE-Protokoll wird nicht unterstützt.");return;}
            tx=nus.getCharacteristic(TX);rx=nus.getCharacteristic(RX);
            if(tx==null||rx==null){fail("UART-Characteristics fehlen");return;}
            if((tx.getProperties()&BluetoothGattCharacteristic.PROPERTY_WRITE)!=0)writeType=BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT;
            else if((tx.getProperties()&BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)!=0)writeType=BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE;
            else{fail("UART-TX ist nicht schreibbar");return;}
            BluetoothGattService access=g.getService(UUID.fromString("00001800-0000-1000-8000-00805f9b34fb"));
            nameChar=access==null?null:access.getCharacteristic(UUID.fromString("00002a00-0000-1000-8000-00805f9b34fb"));
            if(nameChar!=null&&(nameChar.getProperties()&BluetoothGattCharacteristic.PROPERTY_READ)!=0){stage="name";
                if(!g.readCharacteristic(nameChar))enableNotifications();else timeout("name",5000,"GATT-Gerätename ohne Antwort; Verbindung bitte erneut versuchen");}
            else enableNotifications();
        });}
        @Override public void onCharacteristicRead(BluetoothGatt g,BluetoothGattCharacteristic c,int status){if(Build.VERSION.SDK_INT<33)handleName(g,c,c.getValue(),status);}
        @Override public void onCharacteristicRead(BluetoothGatt g,BluetoothGattCharacteristic c,byte[] value,int status){handleName(g,c,value,status);}
        @Override public void onDescriptorWrite(BluetoothGatt g,BluetoothGattDescriptor d,int status){main.post(()->{
            if(g!=gatt||d!=descriptor||!stage.equals("cccd"))return;
            if(status!=0){fail("Notification-Anmeldung Fehler "+status);return;}startHandshake();
        });}
        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c){if(Build.VERSION.SDK_INT<33)onChunk(g,c,c.getValue());}
        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c,byte[] value){onChunk(g,c,value);}
        @Override public void onCharacteristicWrite(BluetoothGatt g,BluetoothGattCharacteristic c,int status){main.post(()->{
            if(g!=gatt||c!=tx||inFlight==null)return;
            if(status!=0){fail("GATT-Schreibfehler "+status+"; Frame wird nicht blind wiederholt");return;}
            inFlight=null;writeNext();
        });}
    };
    private void handleName(BluetoothGatt g,BluetoothGattCharacteristic c,byte[] value,int status){byte[] copy=value==null?null:value.clone();main.post(()->{
        if(g!=gatt||c!=nameChar||!stage.equals("name"))return;
        if(status==0&&copy!=null){String text=new String(copy,StandardCharsets.UTF_8);int end=text.indexOf('\0');if(end>=0)text=text.substring(0,end);
            if(!text.isEmpty()){deviceName=text;listener.metadata("gatt_device_name",text);}}
        enableNotifications();
    });}
    private void enableNotifications(){
        if(gatt==null||rx==null)return;
        byte[] value;
        if((rx.getProperties()&BluetoothGattCharacteristic.PROPERTY_NOTIFY)!=0)value=BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE;
        else if((rx.getProperties()&BluetoothGattCharacteristic.PROPERTY_INDICATE)!=0)value=BluetoothGattDescriptor.ENABLE_INDICATION_VALUE;
        else{fail("UART-RX unterstützt keine Notifications/Indications");return;}
        descriptor=rx.getDescriptor(CCCD);if(descriptor==null||!gatt.setCharacteristicNotification(rx,true)){fail("Notifications nicht verfügbar");return;}
        stage="cccd";boolean accepted;
        if(Build.VERSION.SDK_INT>=33)accepted=gatt.writeDescriptor(descriptor,value)==0;
        else{descriptor.setValue(value);accepted=gatt.writeDescriptor(descriptor);}
        if(!accepted)fail("CCCD-Schreiben abgewiesen");else timeout("cccd",5000,"CCCD ohne Bestätigung");
    }
    private void startHandshake(){
        decoder.reset();ready=false;encrypted=true;stage="5b";
        try{crypto=new LegacyCrypto(deviceName);queue(crypto.encrypt(Packet.request(0x21,0x5b,0)));}
        catch(RuntimeException ex){fail("Crypto-Initialisierung fehlgeschlagen: "+ex.getMessage());return;}
        listener.status("Melde am Dashboard an");int token=epoch;
        main.postDelayed(()->{
            if(token!=epoch||!stage.equals("5b"))return;
            if(inFlight!=null||!writes.isEmpty()){fail("Initialer GATT-Transfer hängt; kein Protokollwechsel");return;}
            encrypted=false;crypto=null;decoder.reset();stage="plain";
            listener.status("Keine Crypto-Antwort; prüfe Klartext mit einem Versions-Leserequest");
            queue(Packet.request(0x20,1,0x1a,(byte)2).wire());timeout("plain",4000,"Keine bestätigte Legacy-Crypto- oder Klartext-Antwort. Kein Flash erforderlich für diesen Test.");
        },3000);
    }
    private void onChunk(BluetoothGatt g,BluetoothGattCharacteristic c,byte[] value){if(value==null)return;byte[] copy=value.clone();main.post(()->{
        if(g!=gatt||c!=rx)return;
        try{decoder.feed(copy,SystemClock.elapsedRealtime(),encrypted,wire->encrypted?crypto.decrypt(wire):Packet.parseWire(wire),this::handlePacket);
            listener.metadata("rx_bad_frames",decoder.badFrames);listener.metadata("rx_expired_fragments",decoder.expiredFragments);
        }catch(RuntimeException ex){fail("RX-Verarbeitung fehlgeschlagen: "+ex.getMessage());}
    });}
    private void handlePacket(Packet p){
        if(stage.equals("plain")){if(p.src==0x20&&p.dst==0x3e&&p.cmd==4&&p.arg==0x1a&&p.data.length==2)finishHandshake("legacy-plain (ESC checksum reply verified)");return;}
        if(p.src==0x21&&p.dst==0x3e&&!ready){
            if(stage.equals("5b")&&p.cmd==0x5b&&p.data.length==30){
                serial=Arrays.copyOfRange(p.data,16,30);appRandom=new byte[16];new SecureRandom().nextBytes(appRandom);crypto.setAppRandom(appRandom);
                pairAttempts=0;stage="5c";listener.status("Power-Taste am Scooter kurz drücken, um die Bluetooth-Anmeldung zu bestätigen");pairTick();return;
            }
            if(stage.equals("5c")&&p.cmd==0x5c&&p.arg==1&&p.data.length==0){stage="5d";pairAttempts=0;sendPairFinal();return;}
            if(stage.equals("5d")&&p.cmd==0x5d&&p.arg==1&&p.data.length==0){finishHandshake("legacy-crypto (MIC verified)");return;}
        }
        if(ready)listener.packet(p);
    }
    private void pairTick(){
        if(!stage.equals("5c")||gatt==null)return;
        if(pairAttempts++>=30){fail("Power-Bestätigung fehlt oder BLE-Version nicht kompatibel");return;}
        queue(crypto.encrypt(Packet.request(0x21,0x5c,0,appRandom)));int token=epoch;
        main.postDelayed(()->{if(token==epoch)pairTick();},1000);
    }
    private void sendPairFinal(){
        if(!stage.equals("5d")||gatt==null)return;
        if(pairAttempts++>=3){fail("Pairing-Abschluss ohne Bestätigung");return;}
        queue(crypto.encrypt(Packet.request(0x21,0x5d,0,serial)));int token=epoch;
        main.postDelayed(()->{if(token==epoch)sendPairFinal();},1800);
    }
    private void finishHandshake(String mode){stage="ready";ready=true;listener.status("Bluetooth-Protokoll bestätigt; noch kein Firmware- oder Flashnachweis");listener.ready(mode);}
    public void send(Packet p,boolean benchmarkKnown){
        if(!ready||!CommandGate.allows(p,benchmarkKnown))throw new IllegalStateException("transport not ready or command forbidden");
        queue(encrypted?crypto.encrypt(p):p.wire());
    }
    private void queue(byte[] wire){
        if(gatt==null||wire==null||wire.length>141){fail("Ungültiger GATT-Transfer");return;}
        // Fixed ATT payload 20; never interleave frames or drop a failed chunk.
        for(int i=0;i<wire.length;i+=20)writes.add(Arrays.copyOfRange(wire,i,Math.min(wire.length,i+20)));
        if(writes.size()>32){fail("GATT-Queue überfüllt");return;}writeNext();
    }
    private void writeNext(){
        if(gatt==null||tx==null||inFlight!=null)return;
        inFlight=writes.poll();if(inFlight==null)return;writeAttempts=0;tryWrite();
    }
    private void tryWrite(){
        if(gatt==null||inFlight==null)return;
        final byte[] chunk=inFlight;boolean accepted;
        if(Build.VERSION.SDK_INT>=33)accepted=gatt.writeCharacteristic(tx,chunk,writeType)==0;
        else{tx.setWriteType(writeType);tx.setValue(chunk);accepted=gatt.writeCharacteristic(tx);}
        if(!accepted){if(++writeAttempts>=5){fail("GATT nimmt denselben ausstehenden Chunk nicht an");return;}
            int token=epoch;main.postDelayed(()->{if(token==epoch&&inFlight==chunk)tryWrite();},50);return;}
        int token=epoch;main.postDelayed(()->{if(token==epoch&&inFlight==chunk)fail("GATT-Chunk ohne Bestätigung; kein automatisches Resenden");},3000);
    }
}
