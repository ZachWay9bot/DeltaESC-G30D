// SPDX-License-Identifier: AGPL-3.0-or-later
package de.ebics.g30bench;
import java.util.LinkedHashMap;
import java.util.Map;
/** EBiCS v0.4 MOTOR-RC motor-service ABI2. Packets prove transport, not physical qualification. */
public final class MotorData {
    public static final int FW=0x400;
    public static final int STATE_OFF=0,STATE_BENCH=1,STATE_DRIVE=2,STATE_EXPIRED=3,STATE_FAULT=4;
    public final long[] v=new long[24];
    public MotorData(Packet p){
        if(p.src!=0x20||p.dst!=0x3e||p.cmd!=0x79||p.data.length!=96)throw new IllegalArgumentException("Motor-Antwortformat");
        for(int i=0;i<24;i++)v[i]=Packet.u32(p.data,4*i);
        if(v[0]!=0x3353424dL||v[1]!=2||v[2]!=FW||!(v[3]!=0||v[4]!=0||v[5]!=0)||
           v[8]>7||v[9]>4||v[10]>600000||v[14]>2||v[23]>2)throw new IllegalArgumentException("Motor-Kennung/ABI");
        for(int i=16;i<=18;i++)if(!Float.isFinite(Float.intBitsToFloat((int)v[i])))throw new IllegalArgumentException("Motor-Messwert");
    }
    private boolean commonArm(){
        long guards=v[19];
        return v[9]!=STATE_BENCH&&v[9]!=STATE_DRIVE&&v[13]==0&&v[14]==1&&v[21]>=512&&v[22]==0&&
               (guards&255)<=45&&((guards>>>8)&255)>50&&(guards&0x1f0000)==0x1f0000&&v[20]==0;
    }
    public boolean canArmBench(){return commonArm()&&v[23]>=1;}
    public boolean canArmDrive(){return commonArm()&&v[23]>=2;}
    public boolean active(){return v[9]==STATE_BENCH||v[9]==STATE_DRIVE;}
    public int profileLevel(){return (int)v[23];}
    public String profileText(){return v[23]==2?"DRIVE-vollqualifiziertes Messprofil":v[23]==1?"BENCH-Profil":"kein gültiges Profil";}
    public Map<String,Object> report(){
        Map<String,Object> r=new LinkedHashMap<>();r.put("firmware_version",hex(v[2]));r.put("motor_service_abi",v[1]);
        r.put("uid_words_hex",java.util.Arrays.asList(hex(v[3]),hex(v[4]),hex(v[5])));
        r.put("request_sequence",v[6]);r.put("ack_sequence",v[7]);r.put("status",v[8]);r.put("state",v[9]);r.put("state_text",stateText(v[9]));
        r.put("remaining_ms",v[10]);r.put("applied_profile_crc32",hex(v[11]));r.put("slot_profile_crc32",hex(v[12]));
        r.put("faults",v[13]);r.put("calibrated",v[14]);r.put("adc_cycles_max",v[15]);
        r.put("vbus_V",Float.intBitsToFloat((int)v[16]));r.put("speed_rad_s",Float.intBitsToFloat((int)v[17]));r.put("iq_A",Float.intBitsToFloat((int)v[18]));
        r.put("throttle",v[19]&255);r.put("brake",(v[19]>>>8)&255);r.put("interlocks",v[19]>>>16);r.put("benchmark_qualified",(v[19]&(1L<<20))!=0);
        r.put("pwm_flags",v[20]);r.put("samples",v[21]);r.put("recovery_reason",v[22]);r.put("profile_level",v[23]);
        r.put("drive_profile_ready",v[23]==2);r.put("road_qualified",false);return r;
    }
    public static String stateText(long s){return s==0?"DIAG/OFF":s==1?"MOTOR_BENCH":s==2?"DRIVE_RC":s==3?"ABGELAUFEN":"FAULT_STOP";}
    private static String hex(long v){return String.format(java.util.Locale.ROOT,"0x%08x",v);}
}
