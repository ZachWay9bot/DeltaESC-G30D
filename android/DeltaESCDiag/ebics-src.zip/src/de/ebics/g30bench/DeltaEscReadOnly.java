// SPDX-License-Identifier: GPL-3.0-only
package de.ebics.g30bench;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Parse-only DeltaESC diagnostic extension integrated in G30 Bench BLE 0.1.1.
 * NO GATT, BLE, handshake, NinebotCrypto, flash or motor-control code lives here.
 * The existing working application's Packet/Session classes should perform the
 * actual framing and transmit only ESC read requests (cmd 0x01).
 *
 * DeltaESC identity is distinct from a stock ESC response to D0:
 *   D0 payload must contain ASCII DESC, protocol and build >= v0.6.3.
 * Reading subsequent DeltaESC registers is locked until this check passes.
 */
public final class DeltaEscReadOnly {
    public static final int ESC = 0x20;
    public static final int READ_REQUEST = 0x01;
    public static final int READ_REPLY = 0x04;
    public static final int REG_ID = 0xD0;
    public static final int MIN_BUILD = 0x0603;

    public enum Mode { UNCHECKED, STOCK_OR_UNKNOWN, DELTAESC_READ_ONLY }
    public static final class Answer {
        public final int register;
        public final byte[] bytes;
        public Answer(int register, byte[] bytes) {
            this.register = register & 255;
            this.bytes = bytes == null ? new byte[0] : bytes.clone();
        }
    }

    private final LinkedHashMap<Integer, Answer> snapshot = new LinkedHashMap<>();
    private Mode mode = Mode.UNCHECKED;
    private int build;
    private int flags;

    public synchronized Mode mode() { return mode; }
    public synchronized int build() { return build; }
    public synchronized int flags() { return flags; }

    public synchronized void reset() {
        snapshot.clear(); mode = Mode.UNCHECKED; build = 0; flags = 0;
    }

    public static int requestedLength(int register) {
        switch (register & 255) {
            case 0xD0: return 16;
            case 0xD1: return 14;
            case 0xD2: return 5;
            case 0xD3: case 0xD4: case 0xD5: return 4;
            case 0xD6: return 14;
            case 0xD7: return 8;
            case 0xD8: return 12;
            case 0xD9: return 6;
            default: throw new IllegalArgumentException("Unknown diagnostic register");
        }
    }

    /**
     * Wire command arguments for existing Session.readRegister(ESC, reg, len).
     * Only read command 0x01 is ever authorized, and no E/F config commands.
     */
    public synchronized int[] checkedRead(int register) {
        int r=register & 255;
        int len=requestedLength(r);
        if (r!=REG_ID && mode!=Mode.DELTAESC_READ_ONLY)
            throw new IllegalStateException("D0 DeltaESC signature not yet verified");
        return new int[]{ESC, READ_REQUEST, r, len};
    }

    /**
     * Called only after the original Session/BleClient verified BLE MIC and
     * the original Packet class parsed the inner checksum.
     */
    public synchronized boolean accept(int source, int command, int arg, byte[] payload) {
        int reg=arg & 255;
        if(source!=ESC || command!=READ_REPLY || payload==null) return false;
        if(reg<0xD0 || reg>0xD9) return false;
        if(reg==REG_ID) {
            boolean identified=payload.length==16 &&
              payload[0]=='D' && payload[1]=='E' && payload[2]=='S' && payload[3]=='C';
            int version=identified?u16(payload,6):0;
            if(!identified || version<MIN_BUILD) {
                reset();mode=Mode.STOCK_OR_UNKNOWN;return false;
            }
            reset();mode=Mode.DELTAESC_READ_ONLY;build=version;flags=u8(payload,9);
            snapshot.put(reg,new Answer(reg,payload));return true;
        }
        if(mode!=Mode.DELTAESC_READ_ONLY || payload.length!=requestedLength(reg))return false;
        snapshot.put(reg,new Answer(reg,payload));return true;
    }

    public synchronized Map<Integer, Answer> snapshot() {
        return new LinkedHashMap<>(snapshot);
    }

    public synchronized String status() {
        if(mode==Mode.UNCHECKED)return "D0 identity not read";
        if(mode==Mode.STOCK_OR_UNKNOWN)return "Stock/unknown firmware; DeltaESC registers locked";
        return String.format("DeltaESC build 0x%04X verified, read-only, %d registers",build,snapshot.size());
    }

    /** Useful telemetry summary. Raw values are not presumed calibrated. */
    public synchronized Map<String,String> diagnosticSummary() {
        LinkedHashMap<String,String> out=new LinkedHashMap<>();
        out.put("identity",status());
        if(mode!=Mode.DELTAESC_READ_ONLY)return out;
        Answer d1=snapshot.get(0xD1);
        if(d1!=null){
            for(int i=0;i<3;i++) out.put("ADC offset "+i,Integer.toString(u16(d1.bytes,i*2)));
            for(int i=0;i<4;i++) out.put("ADC raw "+i,Integer.toString(u16(d1.bytes,6+i*2)));
        }
        Answer d8=snapshot.get(0xD8);
        if(d8!=null){
            out.put("control cycles",Long.toString(u32(d8.bytes,0)));
            out.put("max control cycles",Long.toString(u32(d8.bytes,4)));
            out.put("budget cycles",Long.toString(u32(d8.bytes,8)));
        }
        Answer d9=snapshot.get(0xD9);
        if(d9!=null){
            out.put("fault",Integer.toString(u16(d9.bytes,0)));
            out.put("diagnostic flags",Integer.toString(u16(d9.bytes,2)));
            out.put("hard OC threshold counts",Integer.toString(u16(d9.bytes,4)));
        }
        return out;
    }

    private static int u8(byte[] b,int o){return b[o]&255;}
    private static int u16(byte[] b,int o){return u8(b,o)|(u8(b,o+1)<<8);}
    private static long u32(byte[] b,int o){return ((long)u16(b,o) | ((long)u16(b,o+2)<<16))&0xFFFFFFFFL;}
}
