// SPDX-License-Identifier: AGPL-3.0-or-later
package de.ebics.g30bench;
import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import org.json.JSONObject;
import org.json.JSONArray;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

public final class MainActivity extends Activity {
    private final Handler main=new Handler(Looper.getMainLooper());
    private Session session;private BleClient ble;
    private TextView transportStatus,operationStatus,results,trace,deltaStatus;
    private Button search,disconnect,probe,read,start,cancel,export,deltaIdentify,deltaRead;
    private Button motorRead,motorImport,motorLoad,motorStart,motorDrive,motorStop;
    private TextView motorStatus;
    private Button detectRead,detectLoad,detectRL,detectFlux,detectProfile,detectStop;
    private TextView detectStatus;
    private byte[] motorProfile;
    private LinearLayout deviceList;private CheckBox showTrace;
    private final Set<String> devices=new HashSet<>();
    private final Map<String,Object> metadata=new LinkedHashMap<>();
    private final List<String> transportEvents=new ArrayList<>();
    private String exportJson;
    private boolean stopped;
    private final int bg=Color.rgb(13,21,28),card=Color.rgb(26,40,51),ink=Color.rgb(230,240,248),accent=Color.rgb(140,207,244);
    @Override public void onCreate(Bundle state){
        super.onCreate(state);if(state!=null){exportJson=state.getString("export_json");motorProfile=state.getByteArray("motor_profile");}buildUI();
        session=new Session(new Session.IO(){
            public void send(Packet p){ble.send(p,session.isTransportKnown());}
            public void later(Runnable r,int ms){main.postDelayed(r,ms);}
            public long now(){return SystemClock.elapsedRealtime();}
            public void changed(){render();}
        });
        ble=new BleClient(this,new BleClient.Listener(){
            public void status(String text){transportStatus.setText(text);record(text);render();}
            public void device(BluetoothDevice device,String name,int rssi){
                String address=device.getAddress();if(!devices.add(address))return;
                Button b=button(name+"  •  "+rssi+" dBm\n"+address,deviceList);
                b.setOnClickListener(v->{if(!permissions()){askPermissions();return;}
                    deviceList.removeAllViews();metadata.clear();transportEvents.clear();session.prepareConnection();ble.connect(device,name);});
            }
            public void ready(String mode){session.connected(mode);}
            public void packet(Packet p){session.receive(p);}
            public void disconnected(){if(session!=null)session.disconnect();}
            public void metadata(String key,Object value){metadata.put(key,value);}
        });
        search.setOnClickListener(v->{if(!permissions()){askPermissions();return;}beginScan();});
        disconnect.setOnClickListener(v->{ble.disconnect();transportStatus.setText("Getrennt");render();});
        probe.setOnClickListener(v->session.probe());read.setOnClickListener(v->session.read());
        start.setOnClickListener(v->session.start());cancel.setOnClickListener(v->session.cancel());
        deltaIdentify.setOnClickListener(v->session.identifyDelta());deltaRead.setOnClickListener(v->session.readDelta());
        motorRead.setOnClickListener(v->session.readMotor());
        motorImport.setOnClickListener(v->{Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");
            try{startActivityForResult(intent,21);}catch(RuntimeException ex){motorStatus.setText("Dateiauswahl: "+ex.getMessage());}});
        motorLoad.setOnClickListener(v->session.loadMotorProfile(motorProfile));
        motorStart.setOnClickListener(v->session.armMotor(5000));motorDrive.setOnClickListener(v->session.armDrive(60000));motorStop.setOnClickListener(v->session.stopMotor());
        detectRead.setOnClickListener(v->session.readDetect());detectLoad.setOnClickListener(v->session.loadDetect());
        detectRL.setOnClickListener(v->session.startDetect(true));detectFlux.setOnClickListener(v->session.startDetect(false));
        detectProfile.setOnClickListener(v->{try{motorProfile=MotorProfile.benchFromDetect(session.motor,session.detect);transportStatus.setText("Konservatives BENCH-Profil aus R/L/Flux/Phasenrichtung erzeugt. Noch keine DRIVE-Freigabe.");render();}catch(Exception ex){transportStatus.setText("Benchprofil nicht erzeugt: "+ex.getMessage());}});
        detectStop.setOnClickListener(v->session.stopDetect());
        export.setOnClickListener(v->saveReport());showTrace.setOnCheckedChangeListener((v,checked)->render());
        transportStatus.setText("Scooter einschalten und SHU vollständig schließen. Dann suchen.");render();
    }
    private void beginScan(){stopped=false;devices.clear();deviceList.removeAllViews();metadata.clear();transportEvents.clear();session.prepareConnection();ble.scan();render();}
    private boolean permissions(){
        if(Build.VERSION.SDK_INT>=31)return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
    }
    private void askPermissions(){
        String[] p=Build.VERSION.SDK_INT>=31?new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT}:new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
        requestPermissions(p,10);
    }
    @Override public void onRequestPermissionsResult(int code,String[] p,int[] results){super.onRequestPermissionsResult(code,p,results);
        if(code==10){if(permissions())beginScan();else transportStatus.setText("Bluetooth-Berechtigung fehlt. Suche nach Freigabe erneut starten.");}}
    private void record(String message){if(transportEvents.size()==100)transportEvents.remove(0);transportEvents.add(message);}
    private void buildUI(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(bg);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(18),dp(18),dp(24));scroll.addView(root);
        scroll.setOnApplyWindowInsetsListener((v,insets)->{
            int top=insets.getSystemWindowInsetTop(),bottom=insets.getSystemWindowInsetBottom();
            scroll.setPadding(0,top,0,bottom);return insets;});setContentView(scroll);
        text("G30 Motor BLE",28,true,root);text("EBiCS MOTOR-RC  •  App v0.2.0-rc1",13,false,root);
        LinearLayout intro=panel(root);text("Zuerst die Verbindung prüfen",20,true,intro);
        text("Mit deiner vorhandenen Firmware werden nur Controller-Version und Seriennummer gelesen. Ein Firmware-Update führt diese App nicht aus.",15,false,intro);
        transportStatus=text("",15,true,intro);
        LinearLayout connections=row(intro);search=button("Scooter suchen",connections);disconnect=button("Trennen",connections);
        deviceList=new LinearLayout(this);deviceList.setOrientation(LinearLayout.VERTICAL);intro.addView(deviceList);
        probe=button("Verbindung erneut prüfen",intro);
        LinearLayout measurement=panel(root);text("Motor-Detect · EBiCS v0.4",20,true,measurement);
        text("Zuerst Motorservice erkennen, dann Detect lesen und das Hardwareprofil laden. R/L: Rad frei aufbocken, Stillstand, Bremse halten, Gas null. Flux: das Rad ausdrücklich VORWÄRTS von Hand drehen; Gates bleiben aus. Danach kann die App ein konservatives BENCH-Profil erzeugen.",15,false,measurement);
        detectRead=button("Motor-Detect erkennen / Status lesen",measurement);
        detectLoad=button("DRV126-Hardwareprofil laden",measurement);
        detectRL=button("R/L messen · Bremse halten",measurement);
        detectFlux=button("Flux + Phasenrichtung · VORWÄRTS drehen",measurement);
        detectProfile=button("BENCH-Profil aus Messung erzeugen",measurement);
        detectStop=button("Messung STOP",measurement);
        detectStatus=text("Noch keine Motorparameter gemessen.",14,false,measurement);
        LinearLayout motor=panel(root);text("EBiCS MOTOR_BENCH / DRIVE_RC",20,true,motor);
        text("MOTOR_BENCH ist auf 5 s und konservative Strom-/Modulationswerte begrenzt. DRIVE_RC erscheint nur mit vollständig kalibriertem Evidenzprofil. Beide starten nur bei Stillstand, Gas null und gezogener Bremse. Erst danach Bremse lösen, Rad vorwärts anschieben und Gas vorsichtig anlegen.",15,false,motor);
        motorRead=button("Motorservice erkennen / Status lesen",motor);
        motorImport=button("Messprofil JSON vom Handy laden",motor);
        motorLoad=button("Messprofil ans ESC senden",motor);
        motorStart=button("MOTOR_BENCH 5 s freigeben",motor);
        motorDrive=button("DRIVE_RC 60 s freigeben",motor);
        motorStop=button("Motor STOP",motor);
        motorStatus=text("Kein gemessenes Profil geladen.",14,false,motor);
        text("Gas weg / Bremse → Leistung aus. BLE-Verlust verlängert keine Lease. DRIVE_RC ist eine Entwicklungsstufe, keine Straßen- oder Fahrfreigabe; erster Lauf ausschließlich aufgebockt.",13,false,motor);
        LinearLayout deltaPanel=panel(root);text("DeltaESC-Diagnose",20,true,deltaPanel);
        text("D0 liest die Firmwarekennung. Mit bestätigter DESC-Kennung ab Build 0x0603 lässt sich D1–D9 auslesen. Die Diagnose verändert keine Controller-Einstellungen.",15,false,deltaPanel);
        deltaIdentify=button("DeltaESC D0 identifizieren",deltaPanel);
        deltaRead=button("DeltaESC D1–D9 lesen",deltaPanel);
        deltaStatus=text("",14,false,deltaPanel);
        LinearLayout bench=panel(root);text("Reglerkern-Benchmark",20,true,bench);
        text("Erkennt EBiCS v0.4 MOTOR-RC1 anhand D0, E0, F0 und CMD7B. Das Benchmark-ABI bleibt 0x0302. Der Benchmark selbst aktiviert keine Gates.",15,false,bench);
        operationStatus=text("",15,true,bench);read=button("Benchmark erkennen / Status lesen",bench);
        start=button("Benchmark starten",bench);cancel=button("Benchmark abbrechen",bench);
        LinearLayout data=panel(root);text("Ergebnis",20,true,data);results=text("",15,false,data);results.setTypeface(Typeface.MONOSPACE);
        export=button("Bericht als JSON speichern",data);
        text("Die Laufzeit betrifft den Reglerkern. ADC-Erfassung und PWM-Hardwareverwaltung sind darin nicht enthalten.",13,false,data);
        showTrace=new CheckBox(this);showTrace.setText("Protokoll anzeigen");showTrace.setTextColor(ink);root.addView(showTrace);
        trace=text("",12,false,root);trace.setTypeface(Typeface.MONOSPACE);trace.setTextIsSelectable(true);
        text("MOTOR-RC Entwicklungsbuild  •  keine Straßenfreigabe",13,true,root);
    }
    private LinearLayout panel(LinearLayout parent){LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(dp(14),dp(14),dp(14),dp(14));
        GradientDrawable d=new GradientDrawable();d.setColor(card);d.setCornerRadius(dp(16));p.setBackground(d);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(16);parent.addView(p,lp);return p;}
    private LinearLayout row(LinearLayout parent){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);parent.addView(r);return r;}
    private TextView text(String value,int size,boolean bold,LinearLayout parent){TextView v=new TextView(this);v.setText(value);v.setTextSize(size);v.setTextColor(ink);v.setPadding(0,dp(5),0,dp(8));
        if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);parent.addView(v,new LinearLayout.LayoutParams(-1,-2));return v;}
    private Button button(String label,LinearLayout parent){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(14);b.setTextColor(bg);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));
        LinearLayout.LayoutParams lp=parent.getOrientation()==LinearLayout.HORIZONTAL?new LinearLayout.LayoutParams(0,-2,1):new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(5);lp.bottomMargin=dp(4);lp.setMarginEnd(dp(3));parent.addView(b,lp);return b;}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private void render(){
        if(session==null)return;
        operationStatus.setText(session.status);probe.setEnabled(session.isLinked()&&!session.isBusy());read.setEnabled(session.isLinked()&&!session.isBusy());
        start.setEnabled(session.canStart());cancel.setEnabled(session.canCancel());export.setEnabled(!session.isBusy());
        deltaIdentify.setEnabled(session.canIdentifyDelta());deltaRead.setEnabled(session.canReadDelta());
        motorRead.setEnabled(session.canReadMotor());motorImport.setEnabled(!session.isBusy());
        motorLoad.setEnabled(motorProfile!=null&&session.canLoadMotor());motorStart.setEnabled(session.canArmMotor());motorDrive.setEnabled(session.canArmDrive());
        motorStop.setEnabled(session.canStopMotor());
        detectRead.setEnabled(session.canReadDetect());detectLoad.setEnabled(session.canLoadDetect());
        detectRL.setEnabled(session.canStartDetectRL());detectFlux.setEnabled(session.canStartDetectFlux());
        detectProfile.setEnabled(session.detect!=null&&session.detect.completeForBench()&&session.motor!=null&&!session.isBusy());
        detectStop.setEnabled(session.canStopDetect());
        detectStatus.setText(session.detect==null?"Noch keine Motorparameter gemessen.":session.detect.text());
        StringBuilder ms=new StringBuilder(motorProfile==null?"Messprofil fehlt.":("Lokales Profil Level "+MotorProfile.level(motorProfile)+" vorhanden; UID und CRC werden beim Laden geprüft."));
        if(session.motor!=null){long[] d=session.motor.v;
            ms.append("\nESC-Zustand: ").append(d[9]).append(" • Rest: ").append(d[10]).append(" ms");
            ms.append("\nProfil im RAM: Level ").append(d[23]).append(" • Fehler: ").append(d[13]);
            ms.append(String.format(Locale.ROOT,"\nBus %.2f V • Iq %.3f A • ω %.1f rad/s",Float.intBitsToFloat((int)d[16]),Float.intBitsToFloat((int)d[18]),Float.intBitsToFloat((int)d[17])));
            ms.append("\nADC-Maximum: ").append(d[15]).append(" DWT-Takte");
        }motorStatus.setText(ms.toString());
        deltaStatus.setText(session.isDeltaKnown()?"DESC-Kennung bestätigt; Diagnose kann gelesen werden.":"DESC (DeltaESC) nicht bestätigt; ist unabhängig von EBiCS MOTOR-RC.");
        disconnect.setEnabled(session.isLinked()||!metadata.isEmpty());
        if(!stopped&&session.isBusy())getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        StringBuilder result=new StringBuilder();
        result.append("ESC-Leseroute: ").append(Boolean.TRUE.equals(session.stock.get("esc_read_route_confirmed"))?"bestätigt":"noch nicht bestätigt");
        append(result,"DRV-Wort",session.stock.get("esc_version_word_hex"));append(result,"BLE-Wort",session.stock.get("ble_version_word_hex"));
        Object rev=session.stock.get("ebics_revision");append(result,"EBiCS Revision F0",rev instanceof Number?String.format(Locale.ROOT,"0x%04x",((Number)rev).intValue()):rev);append(result,"EBiCS MOTOR-RC1 bestätigt",session.stock.get("ebics_motor_rc_confirmed"));
        append(result,"Motorservice ABI",session.stock.get("motor_service_abi"));append(result,"Motorprofil ABI",session.stock.get("motor_profile_abi"));append(result,"Motor-Detect ABI",session.stock.get("motor_detect_abi"));
        append(result,"Benchmark-Protokoll",Boolean.TRUE.equals(session.stock.get("benchmark_firmware_detected"))?"ABI 0x0302, 496 Fälle":"nicht bestätigt");
        Object serial=session.stock.get("esc_serial_ascii");append(result,"Seriennummer",serial==null?session.stock.get("esc_serial_hex"):serial);
        Map<String,Object> delta=session.deltaReport();
        append(result,"DeltaESC-Kennung bestätigt",delta.get("identity_confirmed"));
        Object raw=delta.get("identity_payload_hex");if(raw!=null&&!raw.toString().isEmpty())append(result,"D0-Antwort (hex)",raw);
        if(Boolean.TRUE.equals(delta.get("identity_confirmed"))){
            append(result,"DeltaESC-Build",delta.get("build_word_hex"));append(result,"DeltaESC-Diagnose vollständig",delta.get("complete"));
            Map<?,?> values=(Map<?,?>)delta.get("values");
            for(Map.Entry<?,?> e:values.entrySet())if(!e.getKey().equals("identity"))append(result,e.getKey().toString(),e.getValue());
        }
        if(session.summary!=null){long[] d=session.summary.values;
            result.append("\n\nLaufgeneration: ").append(d[3]).append("\nGeprüft: ").append(d[13]).append(" / ").append(d[5]);
            result.append("\nKernmaximum: ").append(d[6]).append(" DWT-Takte");
            result.append(String.format(Locale.ROOT,"\nNominal bei 64 MHz: %.2f µs",d[6]/64.0));
            result.append("\nLangsamster Fall: ").append(d[7]).append("\nFehlerflags: ").append(d[11]);
            result.append("\nGates gesperrt: ").append(session.summary.inhibited()?"ja":"NICHT BESTÄTIGT");
            result.append("\nBenchmark-Motorvoraussetzung: ").append(session.summary.qualifiedForMotor()?"ERFÜLLT":"NICHT ERFÜLLT");
            result.append("\nEinzelfälle gelesen: ").append(session.cases.size()).append(" / 31");
        }results.setText(result.toString());
        trace.setVisibility(showTrace.isChecked()?View.VISIBLE:View.GONE);
        if(showTrace.isChecked()){StringBuilder s=new StringBuilder();for(String e:transportEvents)s.append(e).append('\n');for(String e:session.events)s.append(e).append('\n');trace.setText(s.toString());}
    }
    private void append(StringBuilder s,String label,Object value){if(value!=null)s.append('\n').append(label).append(": ").append(value);}
    private String report(){Map<String,Object> report=session.report();report.put("bluetooth",new LinkedHashMap<>(metadata));report.put("transport_events",new ArrayList<>(transportEvents));
        report.put("exported_at_utc",timestamp());report.put("physical_test_source","Android Bluetooth input; no simulated measurement injected by this APK");return Json.write(report)+"\n";}
    private String timestamp(){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'",Locale.ROOT);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date());}
    private void saveReport(){
        exportJson=report();Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE,"G30_BLE_Bericht_"+timestamp().replace(":","")+".json");
        try{startActivityForResult(intent,20);}catch(RuntimeException ex){transportStatus.setText("Dateiauswahl konnte nicht starten: "+ex.getMessage());}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
        if(request==21&&result==RESULT_OK&&data!=null&&data.getData()!=null){
            try(InputStream stream=getContentResolver().openInputStream(data.getData())){
                if(stream==null)throw new java.io.IOException("Kein Lesezugang");ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] block=new byte[1024];int n;
                while((n=stream.read(block))>=0){if(out.size()+n>32768)throw new java.io.IOException("Profil zu groß");out.write(block,0,n);}
                JSONObject j=new JSONObject(new String(out.toByteArray(),StandardCharsets.UTF_8));
                if(!"G30_MOTOR_PROFILE_ABI2".equals(j.getString("schema")))throw new IllegalArgumentException("Profilformat ABI2 erforderlich");
                JSONArray u=j.getJSONArray("uid");if(u.length()!=3)throw new IllegalArgumentException("UID braucht drei Wörter");long[] uid=new long[3];
                for(int i=0;i<3;i++){Object word=u.get(i);uid[i]=word instanceof String?Long.decode((String)word):u.getLong(i);}
                float[] values=new float[18];for(int i=0;i<18;i++)values[i]=(float)j.getDouble(MotorProfile.FLOATS[i]);
                JSONObject ev=j.getJSONObject("evidence");int flags=0;for(int i=0;i<7;i++)if(Boolean.TRUE.equals(ev.get(MotorProfile.EVIDENCE[i])))flags|=1<<i;
                String scale=j.getString("scale_kind");int pf=MotorProfile.P_DETECT+("calibrated".equals(scale)?MotorProfile.P_CALIBRATED:"nominal".equals(scale)?MotorProfile.P_NOMINAL:0);
                motorProfile=MotorProfile.encode(uid,j.getLong("adc_cycles_max"),j.getInt("deadtime_ticks"),values,flags,j.getInt("phase_sign"),pf);
                render();transportStatus.setText("Messprofil lokal geladen. Verbinden, Motorservice erkennen, dann ans ESC senden.");
            }catch(Exception ex){motorProfile=null;render();transportStatus.setText("Messprofil nicht geladen: "+ex.getMessage());}
        }
        if(request==20&&result==RESULT_OK&&data!=null&&data.getData()!=null&&exportJson!=null){
            try(OutputStream stream=getContentResolver().openOutputStream(data.getData(),"wt")){
                if(stream==null)throw new java.io.IOException("Kein Schreibzugang");stream.write(exportJson.getBytes(StandardCharsets.UTF_8));stream.flush();transportStatus.setText("Bericht gespeichert. Die Datei kannst du zur Auswertung senden.");
            }catch(Exception ex){transportStatus.setText("Bericht konnte nicht gespeichert werden: "+ex.getMessage());}
        }
    }
    @Override public void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);out.putString("export_json",exportJson);out.putByteArray("motor_profile",motorProfile);}
    @Override protected void onResume(){super.onResume();stopped=false;}
    @Override protected void onStop(){stopped=true;main.removeCallbacksAndMessages(null);if(ble!=null)ble.disconnect();super.onStop();}
    @Override protected void onDestroy(){main.removeCallbacksAndMessages(null);if(ble!=null)ble.disconnect();super.onDestroy();}
}
