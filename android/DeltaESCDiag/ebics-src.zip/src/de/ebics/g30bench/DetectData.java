// SPDX-License-Identifier: AGPL-3.0-or-later
package de.ebics.g30bench;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.CRC32;
/** EBiCS v0.4 motor-detect ABI2. R/L uses bounded excitation; flux+direction is passive. */
public final class DetectData {
 public static final int VALID_R=1,VALID_L=2,VALID_FLUX=4,VALID_DIR_POS=8,VALID_DIR_KNOWN=16;
 public final long[] v=new long[24];
 public DetectData(Packet p){
  if(p.src!=0x20||p.dst!=0x3e||p.cmd!=0x78||p.data.length!=96)throw new IllegalArgumentException("Motor-Detect-Antwortformat");
  for(int i=0;i<24;i++)v[i]=Packet.u32(p.data,4*i);
  if(v[0]!=0x34445447L||v[1]!=2||v[2]!=MotorData.FW||v[3]>8||v[4]>5||v[7]>31||v[9]>2||v[19]>1||v[20]>8||v[23]>15)
   throw new IllegalArgumentException("Motor-Detect-Kennung/ABI");
  for(int i=10;i<=16;i++)if(!Float.isFinite(Float.intBitsToFloat((int)v[i])))throw new IllegalArgumentException("Motor-Detect-Messwert");
  if(((v[7]&VALID_R)!=0&&!(value(10)>0))||((v[7]&VALID_L)!=0&&!(value(11)>0))||((v[7]&VALID_FLUX)!=0&&!(value(12)>0))||
     ((v[7]&VALID_DIR_POS)!=0&&(v[7]&VALID_DIR_KNOWN)==0)||((v[7]&VALID_FLUX)!=0&&(v[7]&VALID_DIR_KNOWN)==0))
   throw new IllegalArgumentException("Motor-Detect-Ergebnisflags");
 }
 public float value(int index){return Float.intBitsToFloat((int)v[index]);}
 public boolean running(){return v[4]==1||v[4]==2;}
 public boolean completeForBench(){return (v[7]&(VALID_R|VALID_L|VALID_FLUX|VALID_DIR_KNOWN))==(VALID_R|VALID_L|VALID_FLUX|VALID_DIR_KNOWN);}
 public int phaseSign(){if((v[7]&VALID_DIR_KNOWN)==0)throw new IllegalStateException("Phasenrichtung nicht gemessen");return (v[7]&VALID_DIR_POS)!=0?1:-1;}
 public static byte[] stockHardware(MotorData m){
  if(m==null||m.v[2]!=MotorData.FW)throw new IllegalArgumentException("EBiCS v0.4 erforderlich");
  ByteBuffer b=ByteBuffer.allocate(60).order(ByteOrder.LITTLE_ENDIAN);
  b.putInt(0x34485047).putInt(1).putInt(60).putInt(1);
  for(int i=3;i<6;i++)b.putInt((int)m.v[i]);b.putInt(9000);
  b.putFloat(3.3f/(4095*.002f*9)).putFloat(4620f/(4096*100)).putFloat(3.3f*12/4095);
  b.putFloat(25).putFloat(43).putInt(64);
  CRC32 crc=new CRC32();crc.update(b.array(),0,56);b.putInt((int)crc.getValue());return b.array();
 }
 public String text(){String dir=(v[7]&VALID_DIR_KNOWN)==0?"offen":phaseSign()>0?"+1 (ABC-logisch)":"-1 (ACB-logisch)";
  return String.format(java.util.Locale.ROOT,
  "Zustand %d · Status %d · Messpunkte %d\nR %.5f Ω · L %.1f µH · Flux %.5f Wb\nGültig: R %s / L %s / Flux %s · Phase %s\n%s · Keine automatische Fahrfreigabe",
  v[4],v[20],v[6],value(10),value(11)*1e6,value(12),(v[7]&1)!=0?"ja":"nein",(v[7]&2)!=0?"ja":"nein",(v[7]&4)!=0?"ja":"nein",dir,
  v[9]==1?"Nominale Messskalierung":v[9]==2?"Eingetragenes kalibriertes Hardwareprofil":"Hardwareprofil fehlt");}
 public Map<String,Object> report(){
  Map<String,Object> r=new LinkedHashMap<>();r.put("firmware_version","0x400");r.put("detect_abi",v[1]);r.put("state",v[4]);r.put("status",v[20]);
  r.put("generation",v[5]);r.put("samples",v[6]);r.put("valid_bits",v[7]);r.put("scale_kind",v[9]);
  r.put("R_effective_alpha_ohm",value(10));r.put("L_effective_alpha_H",value(11));r.put("flux_Wb",value(12));
  r.put("phase_direction_known",(v[7]&VALID_DIR_KNOWN)!=0);r.put("phase_sign",(v[7]&VALID_DIR_KNOWN)!=0?phaseSign():0);
  r.put("fit_residual_V",value(13));r.put("peak_current_A",value(14));r.put("peak_command_voltage_V",value(15));
  r.put("flux_electrical_turns",value(16));r.put("faults",v[17]);r.put("adc_cycles_max",v[18]);
  r.put("nominal_scale",v[9]==1);r.put("pwm_flags",v[23]);r.put("motor_drive_qualified",false);return r;
 }
}
