#pragma once
#include <stdint.h>

#define NINEBOT_MAX_PAYLOAD 56u
#define NINEBOT_READ  0x01u
#define NINEBOT_WRITE 0x03u

typedef struct {
    uint8_t address;
    uint8_t field4;
    uint8_t field5;
    uint8_t payload_len;
    uint8_t payload[NINEBOT_MAX_PAYLOAD];
} ninebot_frame_t;

void ninebot_link_init(void);
void ninebot_link_irq(void);
uint8_t ninebot_link_get_frame(ninebot_frame_t *out);
void ninebot_send_app_response(uint8_t type, uint8_t command, const uint8_t *payload, uint8_t payload_len);
void ninebot_send_dashboard_status(uint8_t mode, uint8_t battery, uint8_t light, uint8_t beep, uint8_t speed, uint8_t fault);
uint32_t ninebot_link_rx_overflows(void);
