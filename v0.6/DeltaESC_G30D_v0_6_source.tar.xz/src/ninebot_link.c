#include "ninebot_link.h"
#include "stm32f103_min.h"

#define RX_RING_SIZE 128u
#define RX_RING_MASK (RX_RING_SIZE - 1u)
#define USART2_IRQ 38u

static volatile uint8_t rx_ring[RX_RING_SIZE];
static volatile uint16_t rx_head;
static volatile uint16_t rx_tail;
static volatile uint32_t rx_overflow_count;

static void gpio_cfg_nibble_local(uint32_t base, unsigned pin, uint32_t nibble) {
    volatile uint32_t *reg = (volatile uint32_t *)((pin < 8u) ? (base + 0x00u) : (base + 0x04u));
    unsigned shift = (pin & 7u) * 4u;
    uint32_t v = *reg;
    v = (v & ~(0xFu << shift)) | ((nibble & 0xFu) << shift);
    *reg = v;
}

void ninebot_link_init(void) {
    RCC_APB2ENR |= (1u << 0) | (1u << 2); /* AFIO + GPIOA */
    RCC_APB1ENR |= (1u << 17);            /* USART2 */
    /* SmartESC G30P uses PA2 USART2 half duplex, AF open-drain. */
    gpio_cfg_nibble_local(GPIOA_BASE, 2, 0xEu);
    USART_CR1_REG(USART2_BASE) = 0u;
    USART_CR2_REG(USART2_BASE) = 0u;
    USART_CR3_REG(USART2_BASE) = USART_CR3_HDSEL;
    /* APB1 = 32 MHz, 115200 baud, oversampling 16: BRR ~= 277.78. */
    USART_BRR_REG(USART2_BASE) = 278u;
    USART_CR1_REG(USART2_BASE) = USART_CR1_UE | USART_CR1_RE | USART_CR1_RXNEIE;
    NVIC_IPR8(USART2_IRQ) = 0x80u; /* below ADC */
    NVIC_ISER1 = (1u << (USART2_IRQ - 32u));
}

void ninebot_link_irq(void) {
    uint32_t sr = USART_SR_REG(USART2_BASE);
    if (sr & (USART_SR_RXNE | USART_SR_ORE)) {
        uint8_t b = (uint8_t)USART_DR_REG(USART2_BASE); /* SR then DR clears RXNE/ORE */
        if (sr & USART_SR_RXNE) {
            uint16_t next = (uint16_t)((rx_head + 1u) & RX_RING_MASK);
            if (next == rx_tail) {
                rx_overflow_count++;
            } else {
                rx_ring[rx_head] = b;
                rx_head = next;
            }
        }
    }
}

static int rx_get(void) {
    if (rx_tail == rx_head) return -1;
    uint8_t b = rx_ring[rx_tail];
    rx_tail = (uint16_t)((rx_tail + 1u) & RX_RING_MASK);
    return (int)b;
}

static uint16_t checksum(const uint8_t *raw, uint8_t total) {
    uint16_t sum = 0u;
    for (uint8_t i = 2u; i < (uint8_t)(total - 2u); i++) sum = (uint16_t)(sum + raw[i]);
    return (uint16_t)(sum ^ 0xFFFFu);
}

uint8_t ninebot_link_get_frame(ninebot_frame_t *out) {
    static uint8_t raw[64];
    static uint8_t pos;
    static uint8_t expected;
    int ch;
    while ((ch = rx_get()) >= 0) {
        uint8_t b = (uint8_t)ch;
        if (pos == 0u) {
            if (b != 0x55u) continue;
            raw[pos++] = b;
            continue;
        }
        if (pos == 1u) {
            if (b == 0xAAu) raw[pos++] = b;
            else pos = (b == 0x55u) ? 1u : 0u;
            continue;
        }
        raw[pos++] = b;
        if (pos == 3u) {
            uint8_t len = raw[2];
            expected = (uint8_t)(len + 6u);
            if (len < 2u || expected > sizeof(raw)) { pos = 0u; expected = 0u; }
            continue;
        }
        if (expected != 0u && pos == expected) {
            uint16_t got = (uint16_t)raw[expected - 2u] | ((uint16_t)raw[expected - 1u] << 8);
            uint16_t want = checksum(raw, expected);
            if (got == want) {
                out->address = raw[3];
                out->field4 = raw[4];
                out->field5 = raw[5];
                out->payload_len = (uint8_t)(raw[2] - 2u);
                for (uint8_t i = 0u; i < out->payload_len; i++) out->payload[i] = raw[6u + i];
                pos = 0u; expected = 0u;
                return 1u;
            }
            pos = 0u; expected = 0u;
        }
    }
    return 0u;
}

static void send_raw(const uint8_t *raw, uint8_t total) {
    uint32_t cr1 = USART_CR1_REG(USART2_BASE);
    USART_CR1_REG(USART2_BASE) = cr1 & ~(USART_CR1_RXNEIE | USART_CR1_RE);
    USART_CR1_REG(USART2_BASE) |= USART_CR1_TE;
    for (uint8_t i = 0u; i < total; i++) {
        while (!(USART_SR_REG(USART2_BASE) & USART_SR_TXE)) {}
        USART_DR_REG(USART2_BASE) = raw[i];
    }
    while (!(USART_SR_REG(USART2_BASE) & USART_SR_TC)) {}
    USART_CR1_REG(USART2_BASE) &= ~USART_CR1_TE;
    USART_CR1_REG(USART2_BASE) |= USART_CR1_RE | USART_CR1_RXNEIE;
}

static void finalize_and_send(uint8_t *raw, uint8_t total) {
    uint16_t c = checksum(raw, total);
    raw[total - 2u] = (uint8_t)(c & 0xFFu);
    raw[total - 1u] = (uint8_t)(c >> 8);
    send_raw(raw, total);
}

void ninebot_send_app_response(uint8_t type, uint8_t command, const uint8_t *payload, uint8_t payload_len) {
    if (payload_len > 32u) payload_len = 32u;
    uint8_t raw[40];
    uint8_t total = (uint8_t)(payload_len + 8u);
    raw[0]=0x55u; raw[1]=0xAAu; raw[2]=(uint8_t)(payload_len + 2u);
    raw[3]=0x23u; raw[4]=type; raw[5]=command;
    for (uint8_t i=0u;i<payload_len;i++) raw[6u+i]=payload[i];
    finalize_and_send(raw,total);
}

void ninebot_send_dashboard_status(uint8_t mode, uint8_t battery, uint8_t light, uint8_t beep, uint8_t speed, uint8_t fault) {
    uint8_t raw[14] = {0x55u,0xAAu,0x08u,0x21u,0x64u,0x00u,mode,battery,light,beep,speed,fault,0u,0u};
    finalize_and_send(raw,(uint8_t)sizeof(raw));
}

uint32_t ninebot_link_rx_overflows(void) { return rx_overflow_count; }
