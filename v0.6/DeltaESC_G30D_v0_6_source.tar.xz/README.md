# DeltaESC G30D v0.6 Stock-Dash BLE diagnostic firmware

UNVALIDATED HARDWARE TEST BUILD for Ninebot G30D Gen1 STM32F103 3-cap ESC.

This v0.6 branch adds the stock-dashboard communication path required by the DeltaESC Android test app while preserving the v0.5 sensorless bring-up safety separation.

## Transport
- PA2 / USART2, 115200 baud, STM32 half-duplex, AF open-drain, matching the SmartESC G30P hardware configuration.
- Supports normal dashboard `0x64/0x65` traffic and Android/Ninebot `55 AA` app frames on the same wire.
- Android app custom registers: `D0..D9`, actions `E0..E6`, config `F0..F5`.
- Dangerous app actions require little-endian magic `DE C0`; `E6 STOP` never requires unlock.

## Build matrix
- `DeltaESC_G30D_v0_6_ble_syncsafe.bin`: BLE/link/ADC diagnostics only. Bridge arming compiled out.
- `DeltaESC_G30D_v0_6_ble_observer_zero_vector.bin`: E5 may arm equal-duty zero-vector PWM, but torque-producing sensorless run is compiled out.
- `DeltaESC_G30D_v0_6_ble_sensorless_bench.bin`: E5 may arm and request the low-current ALIGN -> OPEN -> HANDOVER -> CLOSED sequence.

## Implemented app functions
- D0 status / build / state / flags / fault / PWM and control rates
- D1 ADC offsets and raw IA/IB/IC/VBUS
- D2 phase map placeholder (`???` until active calibration is validated)
- D3/D4/D5 physical R/L/flux configuration values (RAM only in v0.6)
- D6 observer phase/error and Iq/Id telemetry
- D7 observer lock data
- D8 control timing
- D9 fault/diagnostic flags
- E0 non-powered 512-sample current-offset recalibration
- E5 zero-vector arm or sensorless bench start depending on build
- E6 unconditional STOP + full bridge disarm
- F0..F4 range-checked RAM settings
- F5 deliberately reports RAM-only, no flash persistence yet

## Deliberately locked in v0.6
E1 phase auto-map, E2 R identification, E3 L identification and E4 physical flux identification return UNSUPPORTED. They require intentional active-vector measurement and are not enabled before the zero-vector PWM/polarity bench check. The nonlinear observer still uses the provisional v0.5 fixed-point R/L/flux scaling; physical F0/F1/F2 values are not silently substituted into that scaling.

First hardware step: flash **syncsafe**, connect the stock dashboard and Android app, verify `Stock FW`, `Stock Status`, D0, D1, D8 and E0 with the wheel unloaded. Do not start with the bench image.
