#!/usr/bin/env bash
set -euo pipefail
exec bash "$(dirname "$0")/run_v098_tests.sh" "$@"
