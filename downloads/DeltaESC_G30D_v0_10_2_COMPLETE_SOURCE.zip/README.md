# DeltaESC G30D v0.8.5: ADC1/ADC2 injected simultaneous acquisition

**SOFTWARE-ONLY experimental firmware; gates compile-disabled. Do not flash to valuable stock DRV126 ESC. No road/motor-running approval.**

Changes relative to CI-green v0.8.4:

- Uses ADC1(master)+ADC2(slave) injected simultaneous sampling of two different phase-current channels, triggered by TIM1 CC4, JEOC interrupt on ADC1.
- Runtime phase pairs match the recovered DRV126 mapping: sector 1/6 CH4/5, 2/3 CH3/5, 4/5 CH3/4. A software pair rotator cycles 1,2,4 while gate-off so all three phase channels can be measured without output torque. No active SVM sector selection exists in this release.
- ADC1 startup boot calibration retains three-phase sequential injected CH3/CH4/CH5 measurement. ADC2 receives separate hardware calibration before dual injected operation.
- Explicit E0 offset calibration uses each channel's OWN 512 observations, not simply 512 IRQs. The requested offset is only applied once all three channel sample counters finish. E6 cancels.
- VBUS PA1 comes from a **separate nonblocking ADC1 regular conversion** every ~20ms, and is no longer read as ADC1 injected rank4. This must be confirmed on the real board.
- In each dual-ADC injected interrupt, the two raw samples are captured, signed three-phase values reconstructed from the stock sector mapping, and fed to the 4-kHz motor-control **mathematics only**. Physical gates cannot arm in this build.
- D0 build ID **0x0805**. Existing D1/DA-DF pages preserve their length/structure; ADC0-2 now show the latest *latched* phase raw samples from separate dual-ADC events, **not simultaneous 3-phase samples**. DA-DF include ADC1 JSQR snapshots.
- New **E8 read-only 16-byte** status: [0-1] ADC1 injected JDR1, [2-3] ADC2 injected JDR1, [4-5] VBUS ADC1 regular raw, [6-7] VBUS sample age ms, [8] just sampled SVM calibration-sector, [9] ADC1 CH, [10] ADC2 CH, [11] offset-cal active bit0/valid bit1/regular pending bit2, [12-13] VBUS timeout count, [14-15] ADC2 JSQR low16.
- Includes existing v0.8.4 transactional F0-F5 and E7 configuration status, commissioning blocker mask, DashBLE motor diagnostics and stock dashboard PA2/NinebotCrypto.

## Safety and caveats

- All six complementary bridge pins stay configured as safe inputs. POWER_STAGE_ARM_ALLOWED/SENSORLESS_RUN_ALLOWED are both **0**, and an attempted build with either enabled is rejected at compile time.
- v0.8.5's software current-sector/ADC paths are **not validated** for the real ESC's analog chain, trigger timing, ADC2/ADC1 regular converter interaction, current gain/polarity or FOC sign.
- The STM32 clock, injected trigger handling and alternate injected/regular conversion may behave differently on a physical board than in our Unicorn simulation. Simulation does not synthesize real ADC conversions or establish FOC deadlines.
- E0 / E8 changes are not tested on a physical scooter. ADC1 PA1 voltage divider/14S support is unverified.
- DashBLE Transaction v0.3.2 intentionally writes only to build **0x0804**, **not 0x0805**. The v0.3.0 motor-diagnostics app can read D0, DA-DF from builds >=0x0702 but does not yet decode E8. A matching parameter App for 0x0805 is a separate work item.
- IAP recovery on this read-protected stock DRV126 remains unresolved; ST-Link only for emergency recovery, NEVER read/unprotect erase without an independent complete backup/reflash route.

Only tested SOURCE code may be exported. No BIN/SHU release.
