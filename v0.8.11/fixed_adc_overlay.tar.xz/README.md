# DeltaESC G30D v0.8.11: fixed two-rank ADC1/ADC2 injected diagnostics

**SOFTWARE-TESTED SOURCE ONLY. NEVER FLASH ON THE VALUABLE ORIGINAL CONTROLLER. NO MOTOR GATE ENABLED.**

## Why this is needed

The previous v0.8.10 four-kHz FOC diagnostics rewrote ADC1_JSQR and ADC2_JSQR at the end of every 16-kHz injected ADC interrupt to rotate CH4/5, CH3/5, CH3/4. This mixed channel selection, physical sample instants and SVM-sector assumptions and relied on unverified reconfiguration behavior in the STM32F103 dual injected-simultaneous mode. The hardware mode 0101 fixed in v0.8.10 remains.

This v0.8.11 diagnostic variant programs the two JSQR registers **exactly once at startup** and does not rewrite them from the ADC interrupt. STM32F103 RM0008 documents JL=01 (two injected ranks) as JSQ3 then JSQ4, with results JDR1 and JDR2. The STM32F103 ADC1 remains master using TIM1_CC4 injected trigger and ADC2 remains slave; sampling times match across both ADCs.

| Fixed rank | ADC1 | ADC2 |
|---|---|---|
| 1 | CH3 (provisionally phase A) | CH5 (provisionally phase C) |
| 2 | CH4 (provisionally phase B) | CH5 again (diagnostic duplicate) |

`G30_FIXED_JSQR_A = (1<<20)|(3<<10)|(4<<15)`; `G30_FIXED_JSQR_B = (1<<20)|(5<<10)|(5<<15)`.

**Crucial**: ranks 1 and 2 are sequential. Although each ADC1/ADC2 rank pair is simultaneous, CH3 and CH4 are NOT sampled simultaneously. These readings are useful to validate raw offsets and channel identification on a non-driving bench; they do not qualify sensorless FOC torque current-feedback. The physical controller still requires validated shunt polarity/gain and a PWM-dependent current sampling strategy before motor power can be enabled. The motor-core math is still compiled, but is called with forced `power_armed=0`.

## New diagnostics

D0 `DESC` build is `0x080B`. EF (`0xEF`) is a **READ-only 16-byte** little-endian page:

- bytes 0..5: raw CH3, CH4, CH5 (three uint16)
- bytes 6..11: offset CH3, CH4, CH5 (three uint16)
- bytes 12..13: second CH5 rank (uint16)
- byte 14: quality flags: `0x01` bad DUALMOD/SCAN; `0x02` wrong fixed JSQR; `0x04` sample outside 12 bit; `0x08` duplicate CH5 differs >128 counts (information only); `0x10` ADC1 or ADC2 JEOC absent
- byte 15: bit0 offset calibration running, bit1 offset valid

E0 triggers 512 correct full-scan samples per offset; any fatal ADC mismatch aborts calibration, latches an error, and forces gates OFF. The previous E8..EE register layouts are still available for historical diagnostics, **but ED/E8 sector labels have changed** because there is no longer a switching sector. A correct `0x080B` phone decoder must use **EF** rather than interpreting old 0x080A multi-page pairs as synchronized FOC currents. No existing v0.3.4 APK supports EF or build 0x080B; Bluetooth communication/crypto source is untouched.

## Software validation

The source overlay is applied to the frozen v0.8.10 source; negative power-stage build refuses compile and the Cortex-M3 safe-only target builds with all gate channels disabled. The host sanitizer exercises JL=01 rank encoding, all three raw channels, E0 offset averaging after exactly 512 samples, raw and JSQR corruption rejection, missing JEOC and duplicate channel-difference flags. Full encrypted Ninebot UART/IAP regressions are retained. A green CI is not real controller validation or stock rollback proof.

## Remaining hardware work

Use a recoverable spare controller and scope to measure TIM1_CC4 / ADC1+ADC2 injected trigger/JEOC and both injected ranks with bridge physically disabled. Determine shunt channel mapping, amplifier gain/sign, safe low-side PWM sampling windows, ADC sample timing, VBUS scale, motor R/L/Flux. Confirm original DRV126 bootloader/recovery before writing any new image. ST-Link for recovery only; phone/dashboard BLE normal diagnostics. 14s remains unsupported.
