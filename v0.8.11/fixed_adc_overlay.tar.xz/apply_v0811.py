#!/usr/bin/env python3
"""Replace dangerous per-sector JSQR rewrites with fixed 2-rank passive scan.
Mandatory GATE OFF. This does NOT qualify synchronous FOC sampling."""
from pathlib import Path
import shutil,sys
r=Path(sys.argv[1]).resolve();src=Path(__file__).resolve().parent
for f in ('g30_fixed_scan.c','g30_fixed_scan.h'):
    shutil.copy2(src/'src'/f,r/'src'/f)
shutil.copy2(src/'tools/test_g30_fixed_scan.c',r/'tools/test_g30_fixed_scan.c')
p=r/'src/stm32f103_min.h';s=p.read_text()
assert 'ADC2_JDR2' not in s
s=s.replace('#define ADC2_JDR1       REG32(ADC2_BASE + 0x3Cu)',
            '#define ADC2_JDR1       REG32(ADC2_BASE + 0x3Cu)\n#define ADC2_JDR2       REG32(ADC2_BASE + 0x40u)')
p.write_text(s)
p=r/'src/main.c';s=p.read_text()
def one(a,b):
    global s
    if s.count(a)!=1:raise RuntimeError(f'Expected unique source anchor ({s.count(a)}): {a[:140]}')
    s=s.replace(a,b,1)
one('#include "stock_adc_mode_guard.h"', '#include "stock_adc_mode_guard.h"\n#include "g30_fixed_scan.h"')
one('#define FW_BUILD 0x080Au','#define FW_BUILD 0x080Bu')
one('#error "v0.8.10 corrected ADC DUALMOD and missing ADC2 JEOC must NEVER arm a physical power stage"',
    '#error "v0.8.11 fixed two-rank diagnostic ADC plan: motor power ALWAYS disabled"')
one('static g30_adc_mode_guard_t g_adc_mode_guard;',
    'static g30_adc_mode_guard_t g_adc_mode_guard;\nstatic g30_fixed_scan_t g_fixed_scan;')
one('    stock_dual_adc_runtime_init(&g_dual_adc,offsets);\n    stock_dual_adc_plan_t plan=stock_dual_adc_plan_init(g_dual_adc.sector);',
    '    stock_dual_adc_runtime_init(&g_dual_adc,offsets);\n    g30_fixed_scan_init(&g_fixed_scan,offsets);')
one('    ADC_CR1=STOCK_ADC_MODE_REG_INJEC_SIMULT|ADC_CR1_JEOCIE;\n    ADC2_CR1=0u;\n    ADC_JSQR=plan.adc1_jsqr;\n    ADC2_JSQR=plan.adc2_jsqr;',
    '    ADC_CR1=STOCK_ADC_MODE_REG_INJEC_SIMULT|ADC_CR1_SCAN|ADC_CR1_JEOCIE;\n    ADC2_CR1=ADC_CR1_SCAN;\n    ADC_JSQR=G30_FIXED_JSQR_A;\n    ADC2_JSQR=G30_FIXED_JSQR_B;')
start=s.index('void ADC1_2_IRQHandler(void) {')
end=s.index('\nstatic void put_u16(',start)
irq=r'''void ADC1_2_IRQHandler(void) {
    const uint32_t t0=DWT_CYCCNT;
    const uint32_t sr1=ADC_SR,sr2=ADC2_SR;
    if(!(sr1&ADC_SR_JEOC))return;
    const uint32_t cr1=ADC_CR1,cr2=ADC2_CR1;
    const uint32_t jsqr1=ADC_JSQR,jsqr2=ADC2_JSQR;
    const uint8_t modefault=g30_adc_mode_capture(&g_adc_mode_guard,
                                     cr1,cr2,ADC_CR2,sr2);
    stock_adc_timing_capture(&g_timer_evidence,
        (uint16_t)TIM_CNT(TIM1_BASE),(uint16_t)TIM_CCR4(TIM1_BASE),
        (uint16_t)TIM_ARR(TIM1_BASE),(uint16_t)TIM_CR1(TIM1_BASE),
        (uint16_t)TIM_CCER(TIM1_BASE),(uint16_t)TIM_BDTR(TIM1_BASE),
        (uint16_t)TIM_SR(TIM1_BASE),t0);
    if(g_timer_evidence.config_flags&ADC_TIMING_GATE_ENABLED){
        if(!g_safety_latched)g_safety_latched=0xA006u;
        power_stage_force_disarm();
    }
    /* Two ranks are converted per ADC after ONE injected timer trigger.
       CH3 (A) and CH5 (C) share rank 1; CH4 (B) and CH5 again share
       rank 2. Rank 2 is deliberately NOT simultaneous with rank 1. */
    const uint16_t a=(uint16_t)ADC_JDR1,b=(uint16_t)ADC_JDR2;
    /* ADC2 JDRx must NEVER be treated as fresh without ADC2 JEOC. */
    const uint16_t c=(modefault&G30_ADCMODE_ADC2_NOT_READY)?0xffffu:(uint16_t)ADC2_JDR1;
    const uint16_t c2=(modefault&G30_ADCMODE_ADC2_NOT_READY)?0xffffu:(uint16_t)ADC2_JDR2;
    ADC_SR&=~ADC_SR_JEOC;ADC2_SR&=~ADC_SR_JEOC;
    const uint8_t q=g30_fixed_scan_capture(&g_fixed_scan,jsqr1,jsqr2,
                           cr1,cr2,(uint16_t)sr1,(uint16_t)sr2,a,b,c,c2);
    /* In this build these are passive observations, NOT FOC phase
       currents qualified for motor torque, nor a SVM sector. */
    stock_adc_snapshot_capture(&g_pair_snapshot,0u,a,c,jsqr1,jsqr2,
                                (uint16_t)sr1,(uint16_t)sr2,g_ms);
    stock_adc_correlated_capture(&g_correlated_evidence,&g_pair_snapshot,
            &g_timer_evidence,(q&G30_SCAN_FATAL_MASK)?ADCQ_RAW_INVALID:0u);
    g_last_adc1_pair=a;g_last_adc2_pair=c;g_last_pair_sector=0u;
    if(g_adc_samples){
        const uint32_t dt=t0-g_last_sample_cycle;
        if(dt<g_sample_interval_min)g_sample_interval_min=dt;
        if(dt>g_sample_interval_max)g_sample_interval_max=dt;
    }
    g_last_sample_cycle=t0;g_adc_last_ms=g_ms;
    g_adc_quality.total_checked++;
    g_adc_quality.last_flags=(q&G30_SCAN_FATAL_MASK)?ADCQ_RAW_INVALID:0u;
    if(q&G30_SCAN_FATAL_MASK){
        if(g_adc_quality.invalid_raw_events!=65535u)g_adc_quality.invalid_raw_events++;
        g_adc_quality.fault_latched=1u;
        if(!g_safety_latched)g_safety_latched=(modefault&G30_ADCMODE_ADC2_NOT_READY)?
           0xA007u:modefault?0xA008u:(q&G30_SCAN_BAD_JSQR)?0xA009u:0xA004u;
        power_stage_force_disarm();
        g_offset_cal_active=0u;g_offset_cal_valid=0u;
        g_adc_samples++;
        return;
    }
    for(unsigned i=0u;i<3u;i++)g_adc_raw[i]=g_fixed_scan.raw[i];
    if(g_offset_cal_active && g_fixed_scan.offset_valid){
        for(unsigned i=0u;i<3u;i++)g_adc_offset[i]=g_fixed_scan.offsets[i];
        g_offset_cal_active=0u;g_offset_cal_valid=1u;
        g_last_action_status=ACT_OK;
    }
    /* Uncalibrated mapping/sign! Never feed these measurements into an
       enabled power stage without separate physical validation. */
    const int32_t ia=(int32_t)a-g_adc_offset[0];
    const int32_t ib=(int32_t)b-g_adc_offset[1];
    const int32_t ic=(int32_t)c-g_adc_offset[2];
    uint16_t peak=abs16s(ia),z=abs16s(ib);
    if(z>peak)peak=z;z=abs16s(ic);if(z>peak)peak=z;
    g_last_abs_current=peak;
    if(peak>g_peak_abs_current)g_peak_abs_current=peak;
    if(++g_control_div4>=4u){
        g_control_div4=0u;
        phase_current_counts_t current={(int16_t)ia,(int16_t)ib,(int16_t)ic};
        const uint32_t c0=DWT_CYCCNT;
        sensorless_control_step(&ctrl,current,g_adc_raw[3],PWM_ARR,0u);
        const uint32_t used=DWT_CYCCNT-c0;
        g_last_control_cycles=used;
        if(used>g_max_control_cycles)g_max_control_cycles=used;
        if(used>CONTROL_HARD_CYCLES)g_control_hard_overruns++;
        g_control_ticks++;
    }
    /* NO JSQR WRITES HERE. Channel selection is frozen at boot. */
    motor_probe_capture(g_adc_raw[0],g_adc_raw[1],g_adc_raw[2],g_adc_raw[3],
                        g_adc_offset,g_ms,g_sample_interval_min,g_sample_interval_max,
                        g_max_control_cycles,0u,jsqr1,ADC_CR2,
                        TIM_CCER(TIM1_BASE),TIM_BDTR(TIM1_BASE));
    g_adc_samples++;
    if((g_adc_samples&0x3Fu)==0u)(void)gate_safety_check();
    const uint32_t cycles=DWT_CYCCNT-t0;
    g_last_isr_cycles=cycles;
    if(cycles>g_max_isr_cycles)g_max_isr_cycles=cycles;
}
'''
s=s[:start]+irq+s[end:]
one('    stock_dual_adc_runtime_begin_offset(&g_dual_adc);',
    '    g30_fixed_scan_start_offsets(&g_fixed_scan);')
one('g_offset_cal_active=0u;stock_dual_adc_runtime_abort_offset(&g_dual_adc);g_offset_cal_valid=0u;action_ack(f,cmd,ACT_OK);',
    'g_offset_cal_active=0u;g30_fixed_scan_abort(&g_fixed_scan);g_offset_cal_valid=0u;action_ack(f,cmd,ACT_OK);')
one('g_offset_cal_active=0u;stock_dual_adc_runtime_abort_offset(&g_dual_adc);g_offset_cal_valid=0u;}',
    'g_offset_cal_active=0u;g30_fixed_scan_abort(&g_fixed_scan);g_offset_cal_valid=0u;}')
one('            const stock_adc_pair_t active=stock_current_pair_for_sector(g_last_pair_sector);\n            p[9]=active.adc1_channel;p[10]=active.adc2_channel;',
    '            p[9]=3u;p[10]=5u; /* fixed rank 1; sector=0 (not SVM) */')
one('    case 0xEEu: /* read-only ADC operating mode and ADC2 JEOC qualification */',
    '    case 0xEFu: /* fixed two-rank raw triple, offsets, duplicate CH5 */\n        irq_disable();\n        g30_fixed_scan_encode_ef(&g_fixed_scan,p);\n        irq_enable();\n        n=16u;break;\n    case 0xEEu: /* read-only ADC operating mode and ADC2 JEOC qualification */')
one('DeltaESC G30D v0.8.10 ADC DUALMOD 0101 + ADC2 JEOC GUARD EE. GATES OFF.',
    'DeltaESC G30D v0.8.11 STATIC 2-RANK ADC1/ADC2 INJECTED SCAN EF, GATES OFF.')
assert s.count('ADC_JSQR=')==2,[(i,line) for i,line in enumerate(s.splitlines()) if 'ADC_JSQR=' in line]
assert s.count('ADC2_JSQR=')==1
assert '#define FW_BUILD 0x080Bu' in s
assert '#if POWER_STAGE_ARM_ALLOWED || SENSORLESS_RUN_ALLOWED' in s
assert '#define COMM_ADC_TIMING_HW_VALID 0u' in s
assert 'g30_fixed_scan_capture' in s
p.write_text(s)
p=r/'Makefile';s=p.read_text().replace('src/stock_adc_mode_guard.c','src/stock_adc_mode_guard.c src/g30_fixed_scan.c').replace('v0_8_10','v0_8_11');p.write_text(s)
print('PASS patch 0811 fixed JSQR, two-rank capture, E0 offset, EF diagnostics, compile-locked gate OFF')
