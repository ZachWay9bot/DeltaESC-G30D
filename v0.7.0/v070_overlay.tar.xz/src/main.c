#include <stdint.h>
#include "stm32f103_min.h"
#include "sensorless_control.h"
#include "ninebot_link.h"
#include "iap_update.h"
#include "dashboard_runtime.h"

#ifndef POWER_STAGE_ARM_ALLOWED
#define POWER_STAGE_ARM_ALLOWED 0
#endif
#ifndef SENSORLESS_RUN_ALLOWED
#define SENSORLESS_RUN_ALLOWED 0
#endif

#define SYSCLK_HZ                  64000000u
#define PWM_HZ                     16000u
#define CONTROL_HZ                  4000u
#define PWM_ARR                     1999u
#define PWM_ZERO_CCR               ((PWM_ARR + 1u) / 2u)
#define ADC_TRIGGER_CCR             1800u
#define CONTROL_BUDGET_CYCLES      (SYSCLK_HZ / CONTROL_HZ)
#define CONTROL_WARN_CYCLES         12000u
#define CONTROL_HARD_CYCLES         15000u
#define PWM_SAMPLE_EXPECT_CYCLES    (SYSCLK_HZ / PWM_HZ)
#define DEADTIME_DTG                  64u
#define ARM_BOOT_DELAY_MS            3000u
#define ARM_MIN_ADC_SAMPLES          2000u
#define ARM_IDLE_CURRENT_COUNTS       120u
#ifndef MOTOR_VOLTAGE_BENCH
#define MOTOR_VOLTAGE_BENCH 0
#endif
#if MOTOR_VOLTAGE_BENCH
#define HARD_OC_COUNTS                250u
#else
#define HARD_OC_COUNTS                700u
#endif
#define ADC_STALE_MS                    5u
#define IRQ_ADC1_2 18u
#define IRQ_USART2 38u
#define GATE_CCER_MASK (TIM_CCER_CC1E | TIM_CCER_CC1NE | TIM_CCER_CC2E | TIM_CCER_CC2NE | TIM_CCER_CC3E | TIM_CCER_CC3NE)
#define ADC_CCER_MASK TIM_CCER_CC4E
#define MAGIC_UNLOCK 0xC0DEu
#define PROTO_MAJOR 0u
#define PROTO_MINOR 2u
#define FW_BUILD 0x0700u
#define OFFSET_CAL_SAMPLES 512u

#define ACT_OK 0u
#define ACT_BUSY 1u
#define ACT_UNSAFE 2u
#define ACT_BAD_MAGIC 3u
#define ACT_UNSUPPORTED 4u
#define ACT_BAD_RANGE 5u
#define ACT_RAM_ONLY 6u

volatile uint32_t g_ms;
volatile uint32_t g_adc_samples;
volatile uint32_t g_control_ticks;
volatile uint32_t g_control_hard_overruns;
volatile uint32_t g_safety_latched;
volatile uint32_t g_overcurrent_trips;
volatile uint32_t g_adc_last_ms;
volatile uint32_t g_last_sample_cycle;
volatile uint32_t g_sample_interval_min = 0xFFFFFFFFu;
volatile uint32_t g_sample_interval_max;
volatile uint32_t g_last_isr_cycles;
volatile uint32_t g_max_isr_cycles;
volatile uint32_t g_last_control_cycles;
volatile uint32_t g_max_control_cycles;
volatile uint16_t g_adc_raw[4];
volatile uint16_t g_adc_offset[3];
volatile uint16_t g_last_abs_current;
volatile uint16_t g_peak_abs_current;
volatile uint8_t  g_power_armed;
volatile uint8_t  g_control_div4;

static sensorless_control_t ctrl;
static volatile uint8_t g_offset_cal_active;
static volatile uint16_t g_offset_cal_count;
static volatile uint32_t g_offset_cal_sum[3];
static volatile uint8_t g_last_action_status;
static volatile uint8_t g_dash_seen;
static volatile uint8_t g_dash_throttle;
static volatile uint8_t g_dash_brake;
static volatile uint32_t g_dash_frames;
static volatile uint32_t g_dash_last_ms;
static uint32_t g_cfg_r_uohm;
static uint32_t g_cfg_l_nh;
static uint32_t g_cfg_flux_uwb;
static int16_t g_cfg_phase_offset;
static uint16_t g_cfg_test_current_ma = 500u;
static uint8_t g_cfg_dirty;
static uint8_t g_phase_map_valid;
static uint8_t g_phase_map[3] = {0xFFu,0xFFu,0xFFu};
static uint8_t g_phase_signs;
static uint8_t g_phase_direction;
static volatile uint8_t g_shu_handoff_refused;

extern uint32_t _estack, _sidata, _sdata, _edata, _sbss, _ebss;
int main(void);
void Reset_Handler(void);
void Default_Handler(void);
void SysTick_Handler(void);
void ADC1_2_IRQHandler(void);
void USART2_IRQHandler(void);
static void power_stage_force_disarm(void);

__attribute__((section(".isr_vector"), used))
void (* const vectors[16u + IRQ_USART2 + 1u])(void) = {
    [0] = (void (*)(void))(&_estack),
    [1] = Reset_Handler,
    [2] = Default_Handler, [3] = Default_Handler, [4] = Default_Handler,
    [5] = Default_Handler, [6] = Default_Handler, [7] = Default_Handler,
    [8] = Default_Handler, [9] = Default_Handler, [10] = Default_Handler,
    [11] = Default_Handler, [12] = Default_Handler, [13] = Default_Handler,
    [14] = Default_Handler, [15] = SysTick_Handler,
    [16u + IRQ_ADC1_2] = ADC1_2_IRQHandler,
    [16u + IRQ_USART2] = USART2_IRQHandler
};

static void gpio_cfg_nibble(uint32_t base, unsigned pin, uint32_t nibble) {
    volatile uint32_t *reg = (volatile uint32_t *)((pin < 8u) ? (base + 0x00u) : (base + 0x04u));
    unsigned shift = (pin & 7u) * 4u;
    uint32_t v = *reg;
    v = (v & ~(0xFu << shift)) | ((nibble & 0xFu) << shift);
    *reg = v;
}

static uint32_t gate_pin_mode_word_a(void) { return (GPIO_CRH(GPIOA_BASE) >> 0) & 0xFFFu; }
static uint32_t gate_pin_mode_word_b(void) { return (GPIO_CRH(GPIOB_BASE) >> 20) & 0xFFFu; }

static void clock_64mhz_hsi(void) {
    RCC_CR |= (1u << 0); while (!(RCC_CR & (1u << 1))) {}
    FLASH_ACR = (1u << 4) | 2u;
    uint32_t cfgr = 0u;
    cfgr |= (4u << 8); cfgr |= (2u << 14); cfgr |= (14u << 18);
    RCC_CFGR = cfgr;
    RCC_CR |= (1u << 24); while (!(RCC_CR & (1u << 25))) {}
    RCC_CFGR = (RCC_CFGR & ~3u) | 2u;
    while (((RCC_CFGR >> 2) & 3u) != 2u) {}
}

static void dwt_init(void) { COREDEBUG_DEMCR |= (1u << 24); DWT_CYCCNT = 0u; DWT_CTRL |= 1u; }
static void systick_init(void) { SYST_RVR = (SYSCLK_HZ / 1000u) - 1u; SYST_CVR = 0u; SYST_CSR = 7u; }

#if POWER_STAGE_ARM_ALLOWED
static void delay_cycles(uint32_t cycles) { uint32_t s=DWT_CYCCNT; while ((uint32_t)(DWT_CYCCNT-s)<cycles) {} }
#endif

static void power_hold_init(void) {
    RCC_APB2ENR |= (1u << 0) | (1u << 2) | (1u << 3) | (1u << 4);
    gpio_cfg_nibble(GPIOA_BASE, 11, 0x2u); GPIO_BSRR(GPIOA_BASE) = (1u << 11);
}
static void gate_pins_to_safe_inputs(void) {
    gpio_cfg_nibble(GPIOA_BASE,8,0x8u); gpio_cfg_nibble(GPIOA_BASE,9,0x8u); gpio_cfg_nibble(GPIOA_BASE,10,0x8u);
    gpio_cfg_nibble(GPIOB_BASE,13,0x8u); gpio_cfg_nibble(GPIOB_BASE,14,0x8u); gpio_cfg_nibble(GPIOB_BASE,15,0x8u);
    GPIO_BRR(GPIOA_BASE)=(1u<<8)|(1u<<9)|(1u<<10); GPIO_BRR(GPIOB_BASE)=(1u<<13)|(1u<<14)|(1u<<15);
}
#if POWER_STAGE_ARM_ALLOWED
static void gate_pins_to_tim1_af(void) {
    gpio_cfg_nibble(GPIOA_BASE,8,0xBu); gpio_cfg_nibble(GPIOA_BASE,9,0xBu); gpio_cfg_nibble(GPIOA_BASE,10,0xBu);
    gpio_cfg_nibble(GPIOB_BASE,13,0xBu); gpio_cfg_nibble(GPIOB_BASE,14,0xBu); gpio_cfg_nibble(GPIOB_BASE,15,0xBu);
}
#endif
static void gate_enable_gpio_init(void) { gpio_cfg_nibble(GPIOB_BASE,1,0x2u); GPIO_BRR(GPIOB_BASE)=(1u<<1); }

static void power_stage_force_disarm(void) {
    GPIO_BRR(GPIOB_BASE)=(1u<<1); TIM_CCER(TIM1_BASE)&=~GATE_CCER_MASK; gate_pins_to_safe_inputs();
    g_power_armed=0u; sensorless_control_stop(&ctrl);
}

static uint32_t gate_safety_check(void) {
    uint32_t ccer=TIM_CCER(TIM1_BASE), ok=1u;
    if (!(ccer&ADC_CCER_MASK)) ok=0u;
    if (!(TIM_BDTR(TIM1_BASE)&TIM_BDTR_MOE)) ok=0u;
    if (g_power_armed) {
        if (!(GPIO_ODR(GPIOB_BASE)&(1u<<1))) ok=0u;
        if ((ccer&GATE_CCER_MASK)!=GATE_CCER_MASK) ok=0u;
        if (gate_pin_mode_word_a()!=0xBBBu || gate_pin_mode_word_b()!=0xBBBu) ok=0u;
    } else {
        if (GPIO_ODR(GPIOB_BASE)&(1u<<1)) ok=0u;
        if (ccer&GATE_CCER_MASK) ok=0u;
        if (gate_pin_mode_word_a()!=0x888u || gate_pin_mode_word_b()!=0x888u) ok=0u;
    }
    if (!ok) { g_safety_latched=1u; power_stage_force_disarm(); }
    return ok;
}

static void uart1_debug_init(void) {
    RCC_APB2ENR |= (1u<<14)|(1u<<3); gpio_cfg_nibble(GPIOB_BASE,6,0xBu); gpio_cfg_nibble(GPIOB_BASE,7,0x4u);
    USART_BRR=556u; USART_CR1=USART_CR1_UE|USART_CR1_TE|USART_CR1_RE;
}
static void uart_putc(char c) { while (!(USART_SR&USART_SR_TXE)) {} USART_DR=(uint32_t)(uint8_t)c; }
static void uart_puts(const char *s) { while (*s) uart_putc(*s++); }
static void uart_u32(uint32_t v) { char b[10]; unsigned n=0u; if(!v){uart_putc('0');return;} while(v&&n<sizeof b){b[n++]=(char)('0'+(v%10u));v/=10u;} while(n)uart_putc(b[--n]); }
static int uart_getc_nonblock(void) { if(!(USART_SR&USART_SR_RXNE))return -1; return (int)(USART_DR&0xFFu); }
static uint16_t abs16s(int32_t x) { if(x<0)x=-x; if(x>65535)x=65535; return (uint16_t)x; }

static void adc1_calibrate_injected_offsets(void) {
    uint32_t sum0=0u,sum1=0u,sum2=0u;
    ADC_CR1&=~ADC_CR1_JEOCIE;
    ADC_CR2=(ADC_CR2&~ADC_CR2_JEXTSEL_MASK)|ADC_CR2_JEXTSEL_JSWSTART|ADC_CR2_JEXTTRIG|ADC_CR2_ADON;
    for(unsigned k=0u;k<256u;k++){
        ADC_SR&=~ADC_SR_JEOC; ADC_CR2|=ADC_CR2_JSWSTART; uint32_t start=DWT_CYCCNT;
        while(!(ADC_SR&ADC_SR_JEOC)){if((uint32_t)(DWT_CYCCNT-start)>20000u){g_safety_latched=0xA001u;return;}}
        sum0+=(uint16_t)ADC_JDR1; sum1+=(uint16_t)ADC_JDR2; sum2+=(uint16_t)ADC_JDR3;
    }
    g_adc_offset[0]=(uint16_t)(sum0>>8); g_adc_offset[1]=(uint16_t)(sum1>>8); g_adc_offset[2]=(uint16_t)(sum2>>8);
    ADC_SR&=~ADC_SR_JEOC;
}

static void adc1_injected_init(void) {
    RCC_APB2ENR|=(1u<<9)|(1u<<2);
    gpio_cfg_nibble(GPIOA_BASE,1,0x0u); gpio_cfg_nibble(GPIOA_BASE,3,0x0u); gpio_cfg_nibble(GPIOA_BASE,4,0x0u); gpio_cfg_nibble(GPIOA_BASE,5,0x0u);
    ADC_CR1=ADC_CR1_SCAN; ADC_SMPR2=(5u<<(1*3))|(2u<<(3*3))|(2u<<(4*3))|(2u<<(5*3));
    ADC_JSQR=(3u<<20)|(3u<<0)|(4u<<5)|(5u<<10)|(1u<<15); ADC_CR2=ADC_CR2_ADON;
    for(volatile unsigned i=0u;i<1000u;i++)nop();
    ADC_CR2|=ADC_CR2_RSTCAL;while(ADC_CR2&ADC_CR2_RSTCAL){} ADC_CR2|=ADC_CR2_CAL;while(ADC_CR2&ADC_CR2_CAL){}
    adc1_calibrate_injected_offsets();
    ADC_CR2=(ADC_CR2&~ADC_CR2_JEXTSEL_MASK)|ADC_CR2_JEXTSEL_TIM1_CC4|ADC_CR2_JEXTTRIG|ADC_CR2_ADON;
    ADC_CR1|=ADC_CR1_JEOCIE; ADC_SR&=~ADC_SR_JEOC; NVIC_IPR8(IRQ_ADC1_2)=0x20u; NVIC_ISER0=(1u<<IRQ_ADC1_2);
}

static void tim1_pwm_and_adc_trigger_init(void) {
    RCC_APB2ENR|=(1u<<11); TIM_CR1(TIM1_BASE)=0u; TIM_CR2(TIM1_BASE)=0u; TIM_PSC(TIM1_BASE)=0u; TIM_ARR(TIM1_BASE)=PWM_ARR; TIM_RCR(TIM1_BASE)=1u;
    TIM_CCR1(TIM1_BASE)=PWM_ZERO_CCR; TIM_CCR2(TIM1_BASE)=PWM_ZERO_CCR; TIM_CCR3(TIM1_BASE)=PWM_ZERO_CCR; TIM_CCR4(TIM1_BASE)=ADC_TRIGGER_CCR;
    TIM_CCMR1(TIM1_BASE)=(6u<<4)|(1u<<3)|(6u<<12)|(1u<<11); TIM_CCMR2(TIM1_BASE)=(6u<<4)|(1u<<3)|(7u<<12)|(1u<<11);
    TIM_CCER(TIM1_BASE)=ADC_CCER_MASK; TIM_BDTR(TIM1_BASE)=DEADTIME_DTG|TIM_BDTR_OSSI|TIM_BDTR_OSSR|TIM_BDTR_MOE;
    TIM_EGR(TIM1_BASE)=TIM_EGR_UG; TIM_SR(TIM1_BASE)=0u; TIM_CR1(TIM1_BASE)=TIM_CR1_CMS_0|TIM_CR1_ARPE|TIM_CR1_CEN;
}

#if POWER_STAGE_ARM_ALLOWED
static uint32_t arm_preconditions_ok(void) {
    if(g_ms<ARM_BOOT_DELAY_MS||g_adc_samples<ARM_MIN_ADC_SAMPLES||g_safety_latched)return 0u;
    if((uint32_t)(g_ms-g_adc_last_ms)>ADC_STALE_MS||g_last_abs_current>ARM_IDLE_CURRENT_COUNTS)return 0u;
    if(g_adc_raw[3]<50u||g_adc_raw[3]>4050u)return 0u; return 1u;
}
static uint32_t power_stage_arm_zero_vector(void) {
    if(!arm_preconditions_ok())return 0u;
    TIM_CCR1(TIM1_BASE)=PWM_ZERO_CCR; TIM_CCR2(TIM1_BASE)=PWM_ZERO_CCR; TIM_CCR3(TIM1_BASE)=PWM_ZERO_CCR;
    gate_pins_to_tim1_af(); TIM_CCER(TIM1_BASE)|=GATE_CCER_MASK; delay_cycles(SYSCLK_HZ/1000u);
    if(g_last_abs_current>ARM_IDLE_CURRENT_COUNTS||g_safety_latched){power_stage_force_disarm();return 0u;}
    g_power_armed=1u; GPIO_BSRR(GPIOB_BASE)=(1u<<1); if(!gate_safety_check())return 0u; return 1u;
}
#endif

void Reset_Handler(void) {
    /* Do not depend on a specific stock-bootloader VTOR handoff. */
    SCB_VTOR=0x08001000u;
    __asm volatile("dsb" ::: "memory");
    __asm volatile("isb" ::: "memory");
    uint32_t *src=&_sidata; for(uint32_t *dst=&_sdata;dst<&_edata;)*dst++=*src++;
    for(uint32_t *dst=&_sbss;dst<&_ebss;)*dst++=0u; (void)main(); for(;;){}
}
void Default_Handler(void){g_safety_latched=0xDEAD0001u;power_stage_force_disarm();for(;;){}}
void SysTick_Handler(void){g_ms++;}
void USART2_IRQHandler(void){ninebot_link_irq();}

void ADC1_2_IRQHandler(void) {
    uint32_t t0=DWT_CYCCNT; if(!(ADC_SR&ADC_SR_JEOC))return;
    uint16_t s0=(uint16_t)ADC_JDR1,s1=(uint16_t)ADC_JDR2,s2=(uint16_t)ADC_JDR3,s3=(uint16_t)ADC_JDR4; ADC_SR&=~ADC_SR_JEOC;
    uint32_t now=t0; if(g_adc_samples){uint32_t dt=now-g_last_sample_cycle;if(dt<g_sample_interval_min)g_sample_interval_min=dt;if(dt>g_sample_interval_max)g_sample_interval_max=dt;}
    g_last_sample_cycle=now;g_adc_last_ms=g_ms;g_adc_raw[0]=s0;g_adc_raw[1]=s1;g_adc_raw[2]=s2;g_adc_raw[3]=s3;

    if(g_offset_cal_active && !g_power_armed){
        g_offset_cal_sum[0]+=s0;g_offset_cal_sum[1]+=s1;g_offset_cal_sum[2]+=s2;g_offset_cal_count++;
        if(g_offset_cal_count>=OFFSET_CAL_SAMPLES){
            g_adc_offset[0]=(uint16_t)(g_offset_cal_sum[0]/OFFSET_CAL_SAMPLES);
            g_adc_offset[1]=(uint16_t)(g_offset_cal_sum[1]/OFFSET_CAL_SAMPLES);
            g_adc_offset[2]=(uint16_t)(g_offset_cal_sum[2]/OFFSET_CAL_SAMPLES);
            g_offset_cal_active=0u;g_last_action_status=ACT_OK;
        }
    }

    int32_t ia=(int32_t)s0-(int32_t)g_adc_offset[0],ib=(int32_t)s1-(int32_t)g_adc_offset[1],ic=(int32_t)s2-(int32_t)g_adc_offset[2];
    uint16_t aa=abs16s(ia),ab=abs16s(ib),ac=abs16s(ic),peak=aa;if(ab>peak)peak=ab;if(ac>peak)peak=ac;
    g_last_abs_current=peak;if(peak>g_peak_abs_current)g_peak_abs_current=peak;
    if(g_power_armed&&peak>HARD_OC_COUNTS){g_overcurrent_trips++;g_safety_latched=0x0C01u;power_stage_force_disarm();}
    if(++g_control_div4>=4u){
        g_control_div4=0u;phase_current_counts_t i={(int16_t)ia,(int16_t)ib,(int16_t)ic};uint32_t c0=DWT_CYCCNT;
        sensorless_control_step(&ctrl,i,s3,PWM_ARR,g_power_armed);uint32_t cc=DWT_CYCCNT-c0;g_last_control_cycles=cc;if(cc>g_max_control_cycles)g_max_control_cycles=cc;if(cc>CONTROL_HARD_CYCLES)g_control_hard_overruns++;g_control_ticks++;
#if SENSORLESS_RUN_ALLOWED
        if(g_power_armed&&ctrl.drive_request&&ctrl.state!=SENSORLESS_FAULT){TIM_CCR1(TIM1_BASE)=ctrl.ccr1;TIM_CCR2(TIM1_BASE)=ctrl.ccr2;TIM_CCR3(TIM1_BASE)=ctrl.ccr3;}
        else{TIM_CCR1(TIM1_BASE)=PWM_ZERO_CCR;TIM_CCR2(TIM1_BASE)=PWM_ZERO_CCR;TIM_CCR3(TIM1_BASE)=PWM_ZERO_CCR;}
#else
        if(g_power_armed){TIM_CCR1(TIM1_BASE)=PWM_ZERO_CCR;TIM_CCR2(TIM1_BASE)=PWM_ZERO_CCR;TIM_CCR3(TIM1_BASE)=PWM_ZERO_CCR;}
#endif
    }
    g_adc_samples++;if((g_adc_samples&0x3Fu)==0u)(void)gate_safety_check();uint32_t isr=DWT_CYCCNT-t0;g_last_isr_cycles=isr;if(isr>g_max_isr_cycles)g_max_isr_cycles=isr;
}

static void put_u16(uint8_t *p,uint16_t v){p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);} 
static void put_i16(uint8_t *p,int16_t v){put_u16(p,(uint16_t)v);} 
static void put_u32(uint8_t *p,uint32_t v){put_u16(p,(uint16_t)v);put_u16(p+2,(uint16_t)(v>>16));}
static uint16_t get_u16(const uint8_t *p){return (uint16_t)p[0]|((uint16_t)p[1]<<8);} 
static int16_t get_i16(const uint8_t *p){return (int16_t)get_u16(p);} 
static uint32_t get_u32(const uint8_t *p){return (uint32_t)get_u16(p)|((uint32_t)get_u16(p+2)<<16);} 
static uint16_t current_fault_code(void){if(g_safety_latched)return (uint16_t)g_safety_latched;return (uint16_t)ctrl.fault;}

static uint8_t status_flags(void){
    uint8_t f=0u;
#if POWER_STAGE_ARM_ALLOWED
    f|=0x01u;
#endif
#if SENSORLESS_RUN_ALLOWED
    f|=0x02u;
#endif
    if(g_power_armed)f|=0x04u;if(ctrl.observer_valid)f|=0x08u;if(g_offset_cal_active)f|=0x10u;if(g_dash_seen)f|=0x20u;if(g_cfg_dirty)f|=0x40u;
    if(ctrl.motor_params_valid)f|=0x80u; /* physical R/L/flux tuple active */
    return f;
}

static uint16_t diag_flags(void){
    uint16_t f=0u;if(g_overcurrent_trips)f|=1u;if(g_control_hard_overruns)f|=2u;if((uint32_t)(g_ms-g_adc_last_ms)>ADC_STALE_MS)f|=4u;
    if(ninebot_link_rx_overflows())f|=8u;if(g_last_action_status==ACT_UNSUPPORTED)f|=16u;if(g_cfg_dirty)f|=32u;if(!g_phase_map_valid)f|=64u;f|=128u;if(g_shu_handoff_refused)f|=256u;return f;
}

static const uint8_t g_esc_identity[14]={'D','E','L','T','A','E','S','C','-','G','3','0','D','0'};

static void app_read_response(const ninebot_frame_t *req){
    uint8_t cmd=req->arg;uint8_t requested=req->payload_len?req->payload[0]:0u;
    uint8_t p[32];uint8_t n=0u;
    for(uint8_t i=0u;i<sizeof p;i++)p[i]=0u;
    switch(cmd){
    case 0x10u: for(uint8_t i=0u;i<14u;i++)p[i]=g_esc_identity[i];n=14u;break;
    case 0x1Au: put_u16(p,FW_BUILD);n=2u;break;
    case 0xB0u: put_u16(p+8,50u);put_u16(p+10,0u);put_i16(p+22,0);n=32u;break;
    case 0xD0u: p[0]='D';p[1]='E';p[2]='S';p[3]='C';p[4]=PROTO_MAJOR;p[5]=PROTO_MINOR;put_u16(p+6,FW_BUILD);p[8]=ctrl.state;p[9]=status_flags();put_u16(p+10,current_fault_code());put_u16(p+12,PWM_HZ);put_u16(p+14,CONTROL_HZ);n=16u;break;
    case 0xD1u: put_u16(p,g_adc_offset[0]);put_u16(p+2,g_adc_offset[1]);put_u16(p+4,g_adc_offset[2]);put_u16(p+6,g_adc_raw[0]);put_u16(p+8,g_adc_raw[1]);put_u16(p+10,g_adc_raw[2]);put_u16(p+12,g_adc_raw[3]);n=14u;break;
    case 0xD2u: p[0]=g_phase_map[0];p[1]=g_phase_map[1];p[2]=g_phase_map[2];p[3]=g_phase_signs;p[4]=g_phase_direction;n=5u;break;
    case 0xD3u: put_u32(p,g_cfg_r_uohm);n=4u;break;
    case 0xD4u: put_u32(p,g_cfg_l_nh);n=4u;break;
    case 0xD5u: put_u32(p,g_cfg_flux_uwb);n=4u;break;
    case 0xD6u: put_u16(p,ctrl.control_phase);put_u16(p+2,ctrl.observer_phase);put_i16(p+4,ctrl.phase_error);put_i16(p+6,(int16_t)sensorless_counts_to_ma(ctrl.iq));put_i16(p+8,(int16_t)sensorless_counts_to_ma(ctrl.id));put_u32(p+10,ctrl.bemf_mv);n=14u;break;
    case 0xD7u:{uint16_t conf=0u;if(ctrl.observer_valid){int32_t e=ctrl.phase_error;if(e<0)e=-e;if(e>5461)e=5461;conf=(uint16_t)(1000-(e*1000)/5461);}p[0]=ctrl.state;p[1]=ctrl.observer_valid;put_u16(p+2,ctrl.lock_ticks);put_u16(p+4,ctrl.lost_ticks);put_u16(p+6,conf);n=8u;break;}
    case 0xD8u: put_u32(p,g_last_control_cycles);put_u32(p+4,g_max_control_cycles);put_u32(p+8,CONTROL_BUDGET_CYCLES);n=12u;break;
    case 0xD9u: put_u16(p,current_fault_code());put_u16(p+2,diag_flags());put_u16(p+4,HARD_OC_COUNTS);n=6u;break;
    default: n=0u;break;
    }
    if(requested!=0u&&requested<n)n=requested;ninebot_send_app_response(req,NINEBOT_READ_ACK,cmd,p,n);
}

static uint8_t has_magic(const ninebot_frame_t *f){return f->payload_len>=2u&&get_u16(f->payload)==MAGIC_UNLOCK;}
static void action_ack(const ninebot_frame_t *req,uint8_t cmd,uint8_t st){uint8_t p[1]={st};g_last_action_status=st;ninebot_send_app_response(req,NINEBOT_WRITE,cmd,p,1u);}

static void start_offset_cal(void){
    irq_disable();g_offset_cal_sum[0]=0u;g_offset_cal_sum[1]=0u;g_offset_cal_sum[2]=0u;g_offset_cal_count=0u;g_offset_cal_active=1u;irq_enable();
}

static void app_write_action(const ninebot_frame_t *f){
    uint8_t cmd=f->arg;
    if(cmd==0xE6u){power_stage_force_disarm();g_offset_cal_active=0u;action_ack(f,cmd,ACT_OK);return;}
    if(!has_magic(f)){action_ack(f,cmd,ACT_BAD_MAGIC);return;}
    if(cmd==0xE0u){if(g_power_armed){action_ack(f,cmd,ACT_UNSAFE);return;}if(g_offset_cal_active){action_ack(f,cmd,ACT_BUSY);return;}start_offset_cal();action_ack(f,cmd,ACT_OK);return;}
    if(cmd>=0xE1u&&cmd<=0xE4u){action_ack(f,cmd,ACT_UNSUPPORTED);return;}
    if(cmd==0xE5u){
        if(f->payload_len<4u){action_ack(f,cmd,ACT_BAD_RANGE);return;}uint16_t ma=get_u16(f->payload+2);
        if(!sensorless_control_set_run_current_ma(&ctrl,ma)){action_ack(f,cmd,ACT_BAD_RANGE);return;}
        g_cfg_test_current_ma=ma;
#if POWER_STAGE_ARM_ALLOWED
        if(g_offset_cal_active){action_ack(f,cmd,ACT_BUSY);return;}
        if(!g_power_armed&&!power_stage_arm_zero_vector()){action_ack(f,cmd,ACT_UNSAFE);return;}
  #if SENSORLESS_RUN_ALLOWED
        sensorless_control_set_drive(&ctrl,1u);
  #endif
        action_ack(f,cmd,ACT_OK);return;
#else
        action_ack(f,cmd,ACT_UNSUPPORTED);return;
#endif
    }
    action_ack(f,cmd,ACT_UNSUPPORTED);
}

static void app_write_config(const ninebot_frame_t *f){
    uint8_t cmd=f->arg;
    if(cmd==0xF0u){if(f->payload_len<4u){action_ack(f,cmd,ACT_BAD_RANGE);return;}uint32_t v=get_u32(f->payload);if(v<1000u||v>2000000u){action_ack(f,cmd,ACT_BAD_RANGE);return;}g_cfg_r_uohm=v;g_cfg_dirty=1u;if(g_cfg_l_nh&&g_cfg_flux_uwb)(void)sensorless_control_set_motor_params(&ctrl,g_cfg_r_uohm,g_cfg_l_nh,g_cfg_flux_uwb);action_ack(f,cmd,ACT_OK);return;}
    if(cmd==0xF1u){if(f->payload_len<4u){action_ack(f,cmd,ACT_BAD_RANGE);return;}uint32_t v=get_u32(f->payload);if(v<1000u||v>5000000u){action_ack(f,cmd,ACT_BAD_RANGE);return;}g_cfg_l_nh=v;g_cfg_dirty=1u;if(g_cfg_r_uohm&&g_cfg_flux_uwb)(void)sensorless_control_set_motor_params(&ctrl,g_cfg_r_uohm,g_cfg_l_nh,g_cfg_flux_uwb);action_ack(f,cmd,ACT_OK);return;}
    if(cmd==0xF2u){if(f->payload_len<4u){action_ack(f,cmd,ACT_BAD_RANGE);return;}uint32_t v=get_u32(f->payload);if(v<100u||v>1000000u){action_ack(f,cmd,ACT_BAD_RANGE);return;}g_cfg_flux_uwb=v;g_cfg_dirty=1u;if(g_cfg_r_uohm&&g_cfg_l_nh)(void)sensorless_control_set_motor_params(&ctrl,g_cfg_r_uohm,g_cfg_l_nh,g_cfg_flux_uwb);action_ack(f,cmd,ACT_OK);return;}
    if(cmd==0xF3u){if(f->payload_len<2u){action_ack(f,cmd,ACT_BAD_RANGE);return;}g_cfg_phase_offset=get_i16(f->payload);sensorless_control_set_phase_offset(&ctrl,g_cfg_phase_offset);g_cfg_dirty=1u;action_ack(f,cmd,ACT_OK);return;}
    if(cmd==0xF4u){if(f->payload_len<2u){action_ack(f,cmd,ACT_BAD_RANGE);return;}uint16_t v=get_u16(f->payload);if(!sensorless_control_set_run_current_ma(&ctrl,v)){action_ack(f,cmd,ACT_BAD_RANGE);return;}g_cfg_test_current_ma=v;g_cfg_dirty=1u;action_ack(f,cmd,ACT_OK);return;}
    if(cmd==0xF5u){if(!has_magic(f)){action_ack(f,cmd,ACT_BAD_MAGIC);return;}action_ack(f,cmd,ACT_RAM_ONLY);return;}
    action_ack(f,cmd,ACT_UNSUPPORTED);
}

static uint8_t handle_stock_dashboard(const ninebot_frame_t *f){
    uint8_t throttle=0u,brake=0u;
    if(dashboard_decode_adc(f,&throttle,&brake)){
        g_dash_throttle=throttle;g_dash_brake=brake;
        return 1u;
    }
    if(dashboard_is_status_request(f)){
        uint8_t p[G30_DASH_STATUS_BYTES];
        dashboard_safe_status_payload(p);
        ninebot_send_app_response(f,G30_DASH_CMD_STATUS,0x00u,p,G30_DASH_STATUS_BYTES);
        return 1u;
    }
    return 0u;
}

static void process_frame(const ninebot_frame_t *f){
    if(f->format==NINEBOT_FMT_5AA5&&f->src==G30_DASH_ADDR&&f->dst==G30_ESC_ADDR){
        g_dash_seen=1u;g_dash_frames++;g_dash_last_ms=g_ms;
        if(handle_stock_dashboard(f))return;
    }
    if(f->dst==0x20u&&(f->cmd==NINEBOT_READ||f->cmd==NINEBOT_WRITE)){
        if(f->cmd==NINEBOT_READ)app_read_response(f);
        else if(f->arg>=0xE0u&&f->arg<=0xE6u)app_write_action(f);
        else if(f->arg>=0xF0u&&f->arg<=0xF5u)app_write_config(f);
        else action_ack(f,f->arg,ACT_UNSUPPORTED);
        return;
    }
}

static void reset_stats(void){g_sample_interval_min=0xFFFFFFFFu;g_sample_interval_max=0u;g_max_isr_cycles=0u;g_max_control_cycles=0u;g_peak_abs_current=0u;g_control_hard_overruns=0u;}
static void report(void){
    uart_puts("v0.7.0 MOTOR arm=");uart_u32(g_power_armed);uart_puts(" state=");uart_puts(sensorless_state_name(ctrl.state));uart_puts(" obs=");uart_u32(ctrl.observer_valid);
    uart_puts(" ctrl=");uart_u32(g_last_control_cycles);uart_putc('/');uart_u32(g_max_control_cycles);uart_puts(" I=");uart_u32(g_last_abs_current);uart_putc('/');uart_u32(g_peak_abs_current);
    uart_puts(" dash=");uart_u32(g_dash_frames);uart_puts(" fmt=");uart_u32(ninebot_link_last_format());uart_puts(" thr/brk=");uart_u32(g_dash_throttle);uart_putc('/');uart_u32(g_dash_brake);uart_puts(" rxov=");uart_u32(ninebot_link_rx_overflows());
    uart_puts(" action=");uart_u32(g_last_action_status);uart_puts(" fault=");uart_u32(current_fault_code());uart_puts("\r\n");
}

static void handle_debug_command(int ch){
    if(ch=='d'||ch=='D'){power_stage_force_disarm();uart_puts("DISARMED\r\n");}
    else if(ch=='c'||ch=='C'){reset_stats();uart_puts("stats cleared\r\n");}
    else if(ch=='?'||ch=='h'||ch=='H'){uart_puts("commands: ? status, D disarm, C clear stats; active control via authenticated BLE E5 only\r\n");report();}
}

int main(void){
    irq_disable();clock_64mhz_hsi();dwt_init();power_hold_init();gate_enable_gpio_init();gate_pins_to_safe_inputs();uart1_debug_init();sensorless_control_init(&ctrl);
    adc1_injected_init();tim1_pwm_and_adc_trigger_init();ninebot_link_init();iap_update_init();systick_init();irq_enable();
    uart_puts("DeltaESC G30D v0.7.0 motor-bench core\r\n");
#if SENSORLESS_RUN_ALLOWED
    uart_puts("BUILD: SENSORLESS BENCH; BLE E5 may arm/start only after safety preconditions.\r\n");
#elif POWER_STAGE_ARM_ALLOWED
    uart_puts("BUILD: OBSERVER ZERO-VECTOR; BLE E5 arms zero-vector only, motor run compiled out.\r\n");
#else
    uart_puts("BUILD: BLE SYNC-SAFE; bridge arming and motor run compiled out.\r\n");
#endif
    uart_puts("PA2 USART2 115200 half-duplex; D0-D9/E0-E6/F0-F5 retained; motor bring-up is the active development target.\r\n");
    uart_puts("Motor path: D-axis ALIGN -> open-loop rotation -> optional BEMF observer handover; E1-E4 auto-ID still locked.\r\n");
    uint32_t next=1000u;
    for(;;){
        int ch=uart_getc_nonblock();if(ch>=0)handle_debug_command(ch);
        uint8_t iap_owned=(uint8_t)(iap_update_pending()||iap_update_active());
        if(iap_owned){power_stage_force_disarm();g_offset_cal_active=0u;}
        iap_update_poll();
        if(iap_owned||iap_update_active()) ninebot_link_discard_rx();
        else { ninebot_frame_t f;while(ninebot_link_get_frame(&f))process_frame(&f); }
        if((int32_t)(g_ms-next)>=0){next+=1000u;report();if((uint32_t)(g_ms-g_adc_last_ms)>ADC_STALE_MS){g_safety_latched=0xA002u;power_stage_force_disarm();}if(g_max_control_cycles>CONTROL_WARN_CYCLES)uart_puts("WARN: 4kHz control reserve below 25%\r\n");}
        if(!gate_safety_check())uart_puts("FAULT: PWM safety envelope violated; DISARMED\r\n");
        __asm volatile("wfi");
    }
}
