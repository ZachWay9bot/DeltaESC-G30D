#!/usr/bin/env python3
from pathlib import Path
import hashlib,struct,re
root=Path(__file__).resolve().parents[1]
main=(root/'src/main.c').read_text(); ctl=(root/'src/sensorless_control.c').read_text(); mk=(root/'Makefile').read_text()
assert '#define FW_BUILD 0x0700u' in main
assert "g_esc_identity[14]={'D','E','L','T','A','E','S','C','-','G','3','0','D','0'}" in main
assert 'src/dashboard_runtime.c' in mk
assert 'sensorless_control_set_motor_params' in main
assert 'int32_t cm = sum / 3' in ctl and '(ib - ic) * 18919' in ctl
assert 's->state == SENSORLESS_ALIGN) ? s->run_iq_counts : 0' in ctl
assert 's->state == SENSORLESS_ALIGN) ? 0 : s->run_iq_counts' in ctl
assert 'fast_atan2_u16(s->bemf_beta_q8, s->bemf_alpha_q8) - 16384u' in ctl
assert 'E_mV * 2608 / flux_uWb' in ctl and 's->motor_flux_uwb' in ctl
assert 'speed_flux_ok' in ctl
assert '#if MOTOR_VOLTAGE_BENCH' in ctl and 'VOLTAGE_BENCH_MOD          700' in ctl
assert 'MOD_LIMIT                 3277' in ctl and 'OPEN_LOOP_BENCH_TICKS   12000u' in ctl
assert '#define HARD_OC_COUNTS                250u' in main
# Keep G30 Bench BLE v0.1.1 D0-D9 wire contract stable.
lengths={'D0':16,'D1':14,'D2':5,'D3':4,'D4':4,'D5':4,'D6':14,'D7':8,'D8':12,'D9':6}
for reg,n in lengths.items():
    m=re.search(rf'case 0x{reg}u:(.*?)(?=case 0xD[0-9]u:|default:)',main,re.S)
    assert m and f'n={n}u;break;' in m.group(1),(reg,n)
items=[
 ('DeltaESC_G30D_v0_7_0_syncsafe.bin',False),
 ('DeltaESC_G30D_v0_7_0_voltage_spin_bench.bin',True),
 ('DeltaESC_G30D_v0_7_0_openloop_foc_bench.bin',True),
 ('DeltaESC_G30D_v0_7_0_sensorless_candidate.bin',True),
]
for name,active in items:
    b=(root/'build'/name).read_bytes(); sp,reset=struct.unpack_from('<II',b,0); adc=struct.unpack_from('<I',b,(16+18)*4)[0]
    assert sp==0x20005000
    assert 0x08001001<=reset<0x0800E000
    assert 0x08001001<=adc<0x0800E000
    assert len(b)<=0xD000
    assert b'DeltaESC G30D v0.7.0 motor-bench core' in b
    if active: assert b'BLE E5 may arm/start' in b
    else: assert b'bridge arming and motor run compiled out' in b
    print(name,len(b),hashlib.sha256(b).hexdigest())
print('v0.7.0 app-contract/motor preflight: PASS')
