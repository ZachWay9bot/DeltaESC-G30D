#!/usr/bin/env python3
from pathlib import Path
import os, subprocess
root=Path(__file__).resolve().parents[1]
cc=os.environ.get('HOST_CC','clang')
for name,defs in [
    ('voltage',['-DMOTOR_VOLTAGE_BENCH=1','-DSENSORLESS_CLOSED_LOOP_ALLOWED=0']),
    ('foc',['-DMOTOR_VOLTAGE_BENCH=0','-DSENSORLESS_CLOSED_LOOP_ALLOWED=0']),
    ('sensorless',['-DMOTOR_VOLTAGE_BENCH=0','-DSENSORLESS_CLOSED_LOOP_ALLOWED=1']),
]:
    out=root/'build'/('motor_core_host_'+name)
    cmd=[cc,'-std=c11','-Wall','-Wextra','-Werror','-Isrc',*defs,
         'tools/motor_core_host_test.c','src/sensorless_control.c','-o',str(out)]
    subprocess.run(cmd,cwd=root,check=True)
    subprocess.run([str(out)],check=True)
print('v0.7.0 motor core host tests: PASS')
